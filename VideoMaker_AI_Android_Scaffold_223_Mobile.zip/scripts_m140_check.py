from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=Path('app/build.gradle.kts').read_text(encoding='utf-8')
checks={
 'Studio hero present':'Transformă ideea într-un videoclip' in html,
 'Auto quick launch present':'homeQuickAuto' in html and 'Începe cu Auto Inteligent' in html,
 'guided launch present':'homeQuickGuided' in html,
 'professional launch present':'homeQuickPro' in html,
 'mode launch function selects mode':'function launchHomeMode(mode)' in html and 'selectedMode=mode' in html,
 'new version code 97':'versionCode = 97' in gradle,
 'new version name 0.98':'0.98-build-candidate' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
