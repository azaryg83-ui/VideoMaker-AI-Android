from pathlib import Path
import re
html=Path('app/src/main/assets/web/index.html').read_text()
checks={
 'bundle import control exists':'importProjectBundle' in html and 'projectBundleImportFile' in html,
 'single JSON import retained':'importProjectIntoLibrary(file)' in html,
 'bulk export creates bundle format':'VideoMakerAI-project-bundle-v1' in html,
 'bulk export uses one download':'VideoMakerAI_bundle_' in html,
 'bulk export includes selected projects':'const ids=[...selectedProjectIds]' in html,
 'bundle checksum created':'bundle.bundleIntegrity={algorithm:' in html,
 'bundle checksum validated':'backupChecksum(check)!==expected' in html,
 'per-project checksum validated':'backupChecksum(cp)!==expectedP' in html,
 'import projects as new ids':'project-bundle-' in html,
 'import confirmation included':'Importă toate ca proiecte noi?' in html,
 'refresh dashboard after import':'await refreshProjectDashboard();$(' in html,
 'version bumped to 95':'versionCode = 95' in Path('app/build.gradle.kts').read_text(),
 'version name candidate 0.96':'0.96-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
