from pathlib import Path
p=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
assert 'projectLibrarySearch' in p and 'projectLibraryTypeFilter' in p and 'projectLibraryStatusFilter' in p
assert 'homeQuickAuto' in p and 'homeQuickGuided' in p and 'homeQuickPro' in p
assert 'sharedEditorModePanel' in p and 'autoProductionPlanEditor' in p
print('PASS | project dashboard filters')
print('PASS | three mode launch controls')
print('PASS | shared editor mode panel')
print('PASS | Auto Intelligent plan panel')
