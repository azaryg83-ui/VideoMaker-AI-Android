from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
kt=Path('app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'segment preview button': 'data-segplay' in html and 'Ascultă segmentul' in html,
 'stop TTS control': 'vcStopTts' in html and 'stopLocalTts' in kt,
 'native TTS API': 'speakLocalSegment' in kt and 'TextToSpeech' in kt,
 'language compatibility check': 'LANG_NOT_SUPPORTED' in kt,
 'voice fallback': 'voices.firstOrNull()' in kt,
 'version updated': 'versionCode = 129' in gradle and '1.30-local-tts-preview' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
assert all(checks.values())
