from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
'bulk rename button exists':'id="projectBulkRename"' in html,
'bulk rename handler exists':"projectBulkRename').onclick=async()=>{" in html,
'no-selection guard present':'Selectează mai întâi proiecte.' in html,
'mode validation present':"mode!=='1'&&mode!=='2'" in html,
'empty text guard present':'if(!addition)' in html,
'confirmation present':'Aplici '+"'" in html and 'la '+"'" in html,
'index name updated':'it.name=next;' in html,
'stored project record updated':'project.name=next;' in html,
'autosave copy updated':'autos.name=next;' in html,
'index saved and library refreshed':'await saveIndex(items);await refreshProjectDashboard();' in html,
'completion count reported':'Prefix/sufix aplicat la '+"'" in html,
'code version 94':'versionCode = 94' in gradle,
'version name 0.95':'versionName = "0.95-build-candidate"' in gradle,
'milestone file present':Path('MILESTONE_137.md').exists(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
