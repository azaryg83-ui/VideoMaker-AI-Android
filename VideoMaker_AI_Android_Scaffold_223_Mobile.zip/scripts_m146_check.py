from pathlib import Path
root=Path(__file__).parent
checks=[]
g=(root/'app/build.gradle.kts').read_text()
w=(root/'.github/workflows/android-build.yml').read_text()
m=(root/'scripts/create_build_manifest.sh').read_text()
d=(root/'STABLE_APK_SIGNING_SETUP.md').read_text()
checks.append(('versionCode 103', 'versionCode = 103' in g))
checks.append(('versionName 1.04 candidate', '1.04-signing-audit-candidate' in g))
checks.append(('CI stable signing flag true', 'STABLE_SIGNING_ENABLED=true' in w))
checks.append(('CI stable signing flag false', 'STABLE_SIGNING_ENABLED=false' in w))
checks.append(('manifest includes signing mode', 'Stable signing configured: $SIGNING_MODE' in m))
checks.append(('manifest includes signer fingerprint', 'Signer certificate SHA-256: $CERT_INFO' in m))
checks.append(('signing setup docs secrets', all(x in d for x in ['VIDEOMAKER_KEYSTORE_BASE64','VIDEOMAKER_KEYSTORE_PASSWORD','VIDEOMAKER_KEY_ALIAS','VIDEOMAKER_KEY_PASSWORD'])))
checks.append(('transition warning documented', 'one-time uninstall/reinstall may be required' in d))
for name,ok in checks: print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(ok for _,ok in checks)}/{len(checks)} PASS')
if not all(ok for _,ok in checks): raise SystemExit(1)
