
// Scaffold 201 — Timeline markers, range selection and quick navigation
(function(){
 const anchor=document.getElementById('sceneTrack'); if(!anchor)return;
 const card=document.createElement('section');card.className='card';card.style.marginTop='10px';card.id='timelineMarkerStudio';
 card.innerHTML=`<h3>📍 Markere & selecție temporală</h3><p class="muted">Marchează momente importante, setează intervale In/Out și navighează rapid în montaj. Marcajele se salvează local separat de scene.</p>
 <div class="row"><button id="tmAdd">📍 Marker la cursor</button><button id="tmIn">⏮ Setează IN</button><button id="tmOut">⏭ Setează OUT</button><button id="tmClearRange">✖ Șterge IN/OUT</button><button id="tmJumpIn">↩ Salt la IN</button><button id="tmJumpOut">↪ Salt la OUT</button></div>
 <div class="scene-grid"><div><label>Marker label</label><input id="tmLabel" placeholder="Ex. Început capitol / moment important"></div><div><label>Tip marker</label><select id="tmType"><option value="note">Notă</option><option value="chapter">Capitol</option><option value="cut">Punct de tăiere</option><option value="audio">Audio</option><option value="visual">Cadru vizual</option></select></div></div>
 <div id="tmRangeInfo" class="muted" style="margin:8px 0">IN/OUT: neselectat</div><div id="tmList"></div><div class="row"><button id="tmExport">📤 Exportă markerii</button><button id="tmImport">📥 Importă markerii</button><input type="file" id="tmImportFile" accept="application/json,.json" hidden><button id="tmClear" class="danger">🗑️ Șterge toți markerii</button></div><div id="tmStatus" class="muted"></div>`;
 anchor.parentElement.insertBefore(card,anchor.nextSibling);
 const $=id=>card.querySelector('#'+id), storage='vm_timeline_markers_v201';let markers=[],range={in:null,out:null};
 const colors={note:'#9aa8b7',chapter:'#60a5fa',cut:'#f87171',audio:'#fbbf24',visual:'#a78bfa'};
 function current(){try{return Math.max(0,Number(sceneStart(cur))+Number(elapsed||0))}catch(e){return Math.max(0,Number(document.getElementById('playhead')?.value)||0)}}
 function total(){try{return scenes.reduce((n,x)=>n+Math.max(0,Number(x.duration)||0),0)}catch(e){return 0}}
 function fmt(t){let n=Math.max(0,Number(t)||0);return Math.floor(n/60)+':'+(n%60).toFixed(1).padStart(4,'0')}
 function save(){try{localStorage.setItem(storage,JSON.stringify({markers,range}))}catch(e){}}
 function seek(t){try{seekToTime(Math.max(0,Math.min(total(),Number(t)||0)));}catch(e){let p=document.getElementById('playhead');if(p){p.value=Math.max(0,Math.min(total(),t));p.dispatchEvent(new Event('input',{bubbles:true}))}}}
 function render(){markers.sort((a,b)=>a.time-b.time);$('tmRangeInfo').textContent=range.in===null&&range.out===null?'IN/OUT: neselectat':`IN: ${range.in===null?'—':fmt(range.in)}   OUT: ${range.out===null?'—':fmt(range.out)}   ${range.in!==null&&range.out!==null&&range.out>range.in?'Durată selecție: '+(range.out-range.in).toFixed(1)+' sec':''}`;
 $('tmList').innerHTML=markers.length?markers.map((m,i)=>`<div class="scene" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;border-left:4px solid ${colors[m.type]||colors.note}"><button class="small" data-tm-jump="${i}">▶ ${fmt(m.time)}</button><strong>${escapeHtml(m.label||('Marker '+(i+1)))}</strong><span class="muted">${m.type||'note'}</span><button class="small" data-tm-edit="${i}">✏️</button><button class="small danger" data-tm-del="${i}">✕</button></div>`).join(''):'<p class="muted">Nu există markere. Adaugă un marker la poziția cursorului.</p>';
 $('tmList').querySelectorAll('[data-tm-jump]').forEach(b=>b.onclick=()=>{let m=markers[+b.dataset.tmJump];seek(m.time);$('tmStatus').textContent='Cursor mutat la '+fmt(m.time)+'.'});
 $('tmList').querySelectorAll('[data-tm-del]').forEach(b=>b.onclick=()=>{markers.splice(+b.dataset.tmDel,1);save();render();});
 $('tmList').querySelectorAll('[data-tm-edit]').forEach(b=>b.onclick=()=>{let i=+b.dataset.tmEdit,m=markers[i],label=prompt('Nume marker:',m.label||'');if(label===null)return;let time=prompt('Timp marker (sec):',String(m.time));if(time===null)return;let n=Number(time);if(!Number.isFinite(n)||n<0){$('tmStatus').textContent='Timp invalid.';return;}m.label=label.trim();m.time=Math.min(total(),n);save();render();});}
 function escapeHtml(v){return String(v||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
 $('tmAdd').onclick=()=>{let t=current(),label=$('tmLabel').value.trim()||('Marker '+(markers.length+1)),type=$('tmType').value;markers.push({id:'tm_'+Date.now(),time:t,label,type});$('tmLabel').value='';save();render();$('tmStatus').textContent='Marker adăugat la '+fmt(t)+'.'};
 $('tmIn').onclick=()=>{range.in=current();save();render();$('tmStatus').textContent='IN setat la '+fmt(range.in)};
 $('tmOut').onclick=()=>{range.out=current();if(range.in!==null&&range.out<range.in){let x=range.in;range.in=range.out;range.out=x;}save();render();$('tmStatus').textContent='OUT setat la '+fmt(range.out)};
 $('tmClearRange').onclick=()=>{range={in:null,out:null};save();render();};
 $('tmJumpIn').onclick=()=>{if(range.in===null){$('tmStatus').textContent='IN nu este setat.';return;}seek(range.in)};
 $('tmJumpOut').onclick=()=>{if(range.out===null){$('tmStatus').textContent='OUT nu este setat.';return;}seek(range.out)};
 $('tmExport').onclick=()=>{let data={schema:1,exportedAt:new Date().toISOString(),markers,range};let blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='videomaker_timeline_markers.json';a.click();};
 $('tmImport').onclick=()=>$('tmImportFile').click();$('tmImportFile').onchange=e=>{let f=e.target.files?.[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let d=JSON.parse(String(r.result));if(!Array.isArray(d.markers))throw Error('format');markers=d.markers.filter(m=>Number.isFinite(Number(m.time))).map(m=>({...m,time:Math.max(0,Math.min(total(),Number(m.time)))}));range=d.range&&typeof d.range==='object'?{in:d.range.in===null?null:Number(d.range.in),out:d.range.out===null?null:Number(d.range.out)}:{in:null,out:null};save();render();$('tmStatus').textContent='Markerii au fost importați.'}catch(err){$('tmStatus').textContent='Fișier JSON invalid sau format incompatibil.'}};r.readAsText(f)};
 $('tmClear').onclick=()=>{if(!markers.length)return;if(!confirm('Ștergi toți markerii?'))return;markers=[];save();render();};
 document.addEventListener('keydown',e=>{if(e.ctrlKey||e.metaKey||e.altKey)return;let tag=e.target?.tagName;if(tag==='INPUT'||tag==='TEXTAREA'||tag==='SELECT'||e.target?.isContentEditable)return;if(e.key.toLowerCase()==='m'){$('tmAdd').click();e.preventDefault()}if(e.key.toLowerCase()==='i')$('tmIn').click();if(e.key.toLowerCase()==='o')$('tmOut').click();});
 try{let d=JSON.parse(localStorage.getItem(storage)||'null');if(d){markers=Array.isArray(d.markers)?d.markers:[];range=d.range||range;}}catch(e){}render();
})();
