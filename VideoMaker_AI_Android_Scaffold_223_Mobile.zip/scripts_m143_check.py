from pathlib import Path
import re
html=Path('app/src/main/assets/web/index.html').read_text()
checks={
 'Auto production plan editor panel present':'autoProductionPlanEditor' in html and 'autoPlanEditorChecklist' in html,
 'Checklist completion state persists in brief':'autoBriefRuntime.productionPlan[i].done=el.checked' in html,
 'Auto brief included in project serialization':'autoBrief:autoBriefRuntime' in html,
 'Checklist reset control implemented':'autoPlanReset' in html and 'forEach(x=>x.done=false)' in html,
 'Checklist rendered after project creation':'renderAutoProductionPlanEditor();updateProductionWorkflow();' in html,
 'Brief restored on imported/local projects':'autoBriefRuntime=p.autoBrief||null' in html,
 'Version code advanced to 101':'versionCode = 101' in Path('app/build.gradle.kts').read_text(),
 'Version name 1.02 candidate':'1.02-update-ready-candidate' in Path('app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
if not all(checks.values()): raise SystemExit(1)
