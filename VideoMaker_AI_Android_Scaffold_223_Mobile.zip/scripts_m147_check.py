from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'Readiness panel UI':'autoPlanReadiness' in html,
 'Manual check button':'autoPlanReadinessCheck' in html,
 'Readiness function':'function checkAutoPlanReadiness()' in html,
 'Scenario check':'label:\'Scenariu\'' in html,
 'Voiceover check':'label:\'Voiceover\'' in html,
 'Visual assets check':'label:\'Materiale vizuale\'' in html,
 'Subtitle check':'label:\'Subtitrări\'' in html,
 'Export settings check':'label:\'Setări export\'' in html,
 'Version code 104':'versionCode = 104' in gradle,
 'Version name 1.05':'versionName = "1.05-auto-readiness-candidate"' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' — '+k)
assert all(checks.values())
print(f'{len(checks)}/{len(checks)} PASS')
