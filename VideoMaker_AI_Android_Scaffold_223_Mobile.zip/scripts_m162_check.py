from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text(encoding='utf-8')
checks={
'per-scene copy continuity control':'data-continuity-copy-prev="${i}"' in s,
'first-scene copy disabled':'${i===0?\'disabled\':\'\'}' in s,
'copy continuity note':'sc.continuityNote=prev.continuityNote||\'\'' in s,
'copy lock state':'sc.continuityLock=prev.continuityLock!==false' in s,
'copy camera style':'sc.cameraStyle=prev.cameraStyle||sc.cameraStyle' in s,
'copy lighting':'sc.lighting=prev.lighting||sc.lighting' in s,
'copy frame type':'sc.frameType=prev.frameType||sc.frameType' in s,
'audit button':'id="auditContinuity"' in s,
'audit reports unlocked scenes':'Continuity Lock dezactivat' in s,
'audit reports missing continuity notes':'nu are note de continuitate explicite' in s,
'audit flags character changes':'personaj diferit față de scena precedentă' in s,
'audit disclaimer':'nu poate confirma identitatea vizuală din imagini generate' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' | '+k)
assert all(checks.values())
