from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
'bulk clear tags button added':'id="projectBulkClearTags"' in html,
'bulk clear handler exists':"projectBulkClearTags').onclick=async()=>{" in html,
'selection required guard':'Selectează mai întâi proiecte.' in html,
'confirmation required before clearing':'if(!confirm(\'Ștergi toate etichetele proiectelor selectate?\'))return;' in html,
'only selected index items affected':'for(const it of items)if(ids.includes(it.id)' in html,
'tags reset to empty array':'it.tags=[];' in html,
'index save and dashboard refresh included':'await saveIndex(items);await refreshProjectDashboard();' in html,
'completion message reports changed count':'aveau etichete' in html,
'code version 93':'versionCode = 93' in gradle,
'version name 0.94':'versionName = "0.94-build-candidate"' in gradle,
'milestone file present':Path('MILESTONE_136.md').exists(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
