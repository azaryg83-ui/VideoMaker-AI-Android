from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'export button appears in project cards':'data-export="${escapeHtml(x.id)}"' in s,
 'export handler wired':'querySelectorAll(\'[data-export]\').forEach(b=>b.onclick=()=>exportProjectBackup(b.dataset.export))' in s,
 'export function exists':'async function exportProjectBackup(id)' in s,
 'IndexedDB project retrieval used':'dbGet(\'projects\',id)' in s[s.find('async function exportProjectBackup'):s.find('async function duplicateProject')],
 'JSON Blob download':'new Blob([json],{type:\'application/json;charset=utf-8\'})' in s,
 'export metadata marker':'VideoMakerAI-project-backup-v1' in s,
 'filename sanitization':'replace(/[^a-z0-9ăâîșț _-]/gi,\'\')' in s,
 'status success and failure':'Export nereușit:' in s and 'Backup JSON exportat:' in s,
 'version bumped to 83':'versionCode = 83' in gradle,
 'version name 0.84':'versionName = "0.84-build-candidate"' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' — '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
