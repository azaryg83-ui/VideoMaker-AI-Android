from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'continuity note control rendered per scene':'data-continuity="${i}"' in html,
 'continuity lock checkbox rendered per scene':'data-continuity-lock="${i}"' in html,
 'continuity note saved on input':'continuityNote=el.value' in html,
 'lock saved on change':'continuityLock=el.checked' in html,
 'continuity helper respects disabled lock':'if(sc.continuityLock===false)return' in html,
 'image prompt includes continuity helper':'sceneContinuityPrompt(sc)' in html and 'function aiPromptForScene' in html,
 'video prompt generator includes continuity':'Lighting: '+"'" in html and 'sceneContinuityPrompt(sc)' in html,
 'milestone docs present':Path('MILESTONE_161.md').exists(),
 'versionCode 118':'versionCode = 118' in gradle,
 'versionName 1.19':'versionName = "1.19-scene-continuity-lock"' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' | '+k)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
