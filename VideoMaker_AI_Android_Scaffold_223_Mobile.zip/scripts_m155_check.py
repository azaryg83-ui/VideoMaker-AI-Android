from pathlib import Path
s=Path('app/src/main/assets/web/index.html').read_text()
g=Path('app/build.gradle.kts').read_text()
checks={
 'stop-after-current-scene control present':'id="aiStopBatch"' in s and 'Oprește după scena curentă' in s,
 'retry failed scenes control present':'id="aiRetryBatchFailures"' in s,
 'batch supports stop request flag':'aiBatchStopRequested=false' in s,
 'batch records failed scene indices':'aiBatchFailedIndices=[]' in s and 'aiBatchFailedIndices.push(i)' in s,
 'batch continues after individual failure':'catch(e){failed++;aiBatchFailedIndices.push(i);' in s,
 'batch checks stop between scenes':'if(aiBatchStopRequested)break;' in s,
 'retry action filters missing images':'aiBatchFailedIndices.filter(i=>scenes[i]&&!scenes[i].img)' in s,
 'buttons managed while running':'stopBtn.disabled=false;startBtn.disabled=true;retryBtn.disabled=true;' in s,
 'versionCode 112':'versionCode = 112' in g,
 'versionName 1.13':'versionName = "1.13-ai-batch-control"' in g,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' — '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
