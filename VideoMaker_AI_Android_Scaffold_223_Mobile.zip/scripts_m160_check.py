from pathlib import Path
import re
html=Path('app/src/main/assets/web/index.html').read_text()
checks={
 'scene composition selector present': 'data-camera-style="${i}"' in html,
 'lighting selector present': 'data-lighting="${i}"' in html,
 'composition options present': all(x in html for x in ['low-angle cinematic shot','overhead top-down shot','symmetrical centered composition']),
 'lighting options present': all(x in html for x in ['dramatic chiaroscuro lighting','warm golden-hour light','torch and fire practical lighting']),
 'composition binding saves scene field': "scenes[i].cameraStyle=el.value;scheduleAutosave()" in html,
 'lighting binding saves scene field': "scenes[i].lighting=el.value;scheduleAutosave()" in html,
 'AI image prompt applies composition and lighting': "Camera composition: "+"'" in html and "natural soft daylight" in html,
 'video prompt includes composition and lighting': "Composition: '+(sc.cameraStyle||'natural eye-level documentary framing')" in html,
 'versionCode 117': 'versionCode = 117' in Path('app/build.gradle.kts').read_text(),
 'versionName 1.18': '1.18-scene-composition-lighting' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
if not all(checks.values()): raise SystemExit(1)
