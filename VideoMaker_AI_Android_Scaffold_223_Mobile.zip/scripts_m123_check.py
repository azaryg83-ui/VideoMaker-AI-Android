from pathlib import Path
s=Path('app/src/main/assets/web/index.html').read_text()
b=Path('app/build.gradle.kts').read_text()
checks={
 'manual backup button exists':'id="manualRecoveryBackup"' in s,
 'restore backup button exists':'id="restoreRecoveryBackup"' in s,
 'manual backup uses dedicated reason':"writeRecoveryBackup('manual')" in s,
 'manual backup refuses missing project':'if(!currentProjectId)' in s and 'Deschide sau salvează un proiect înainte de backup.' in s,
 'restore lists stored generations':'history=saved?.history||[]' in s and 'Alege backup-ul de restaurat' in s,
 'restore validates selected generation':'idx<0||idx>=history.length' in s,
 'restore requires confirmation':'Restaurarea va înlocui starea proiectului curent.' in s,
 'restore updates project and autosave':"await dbPut('projects',currentProjectId,project);await dbPut('projects','autosave',project)" in s,
 'restore reloads editor state':"$('restoreLocal').click();showEditor('script')" in s,
 'build version 81':'versionCode = 81' in b and '0.81-build-candidate' in b,
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
if not all(checks.values()):raise SystemExit(1)
