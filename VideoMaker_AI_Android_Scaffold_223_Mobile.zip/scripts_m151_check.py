from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
'queue has copy-all prompts action':'copyAllVisualPrompts' in html and '📋 Copiază toate prompturile' in html,
'queue has JSON prompt-pack export':'exportVisualPromptPack' in html and '📦 Exportă pachetul prompturi JSON' in html,
'pack contains global style and negative prompt':'visualStyle' in html and 'negativePrompt' in html,
'pack contains image and video prompts':'visualPrompt:sc.visualPrompt' in html and 'videoPrompt:sc.videoPrompt' in html,
'pack contains scene duration, narration and frame/motion':'durationSeconds:Number(sc.duration' in html and 'narration:sc.caption' in html and 'frameType:' in html and 'motion:sc.motion' in html,
'pack includes character profiles and variants':'characters:characters.map' in html and 'variants:(c.variants||[])' in html,
'export clearly states no media generation':'No AI media generation is performed by this export.' in html,
'versionCode bumped to 108':'versionCode = 108' in gradle,
'versionName bumped to 1.09':'versionName = "1.09-visual-prompt-pack"' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
