from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'Readiness report export button present':'autoPlanReadinessExport' in html,
 'Export disabled before audit':'autoPlanReadinessExport" disabled' in html,
 'Audit data includes timestamp':'checkedAt:new Date().toISOString()' in html,
 'Audit includes project name':'projectName:String($' in html,
 'Audit includes check list':'checks:checks.map(c=>' in html,
 'Audit disclaimer prevents overclaim':'Nu confirmă funcționarea AI sau succesul exportului.' in html,
 'Audit export JSON':'JSON.stringify(latestAutoReadinessReport,null,2)' in html,
 'Export requires prior audit':'if(!latestAutoReadinessReport)' in html,
 'Version code 105':'versionCode = 105' in gradle,
 'Version name 1.06':'versionName = "1.06-readiness-report"' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' — '+k)
assert all(checks.values()), checks
print(f'{len(checks)}/{len(checks)} PASS')
