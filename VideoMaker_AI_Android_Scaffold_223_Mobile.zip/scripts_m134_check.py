from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text()
checks={
 'bulk status button exists':'id="projectBulkStatus"' in s,
 'bulk status handler exists':"$('projectBulkStatus').onclick=async()=>" in s,
 'selected project ids used':'const ids=[...selectedProjectIds]' in s,
 'status choices mapped':"'1':'draft','2':'progress','3':'ready','4':'archived'" in s,
 'invalid status rejected':'Status invalid. Nu s-a modificat nimic.' in s,
 'status updates selected projects':'if(ids.includes(it.id))it.status=status' in s,
 'save and refresh in handler':'await saveIndex(items);await refreshProjectDashboard();' in s and 'Status actualizat pentru' in s,
 'version code 91':'versionCode = 91' in Path('app/build.gradle.kts').read_text(),
 'version name 0.92':'versionName = "0.92-build-candidate"' in Path('app/build.gradle.kts').read_text(),
 'milestone documentation exists':Path('MILESTONE_134.md').exists(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
