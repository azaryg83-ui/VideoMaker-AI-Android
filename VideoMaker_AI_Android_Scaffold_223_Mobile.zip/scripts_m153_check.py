from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
'filter selector exists with all statuses':'id="visualQueueFilter"' in html and all(f'value="{v}"' in html for v in ['all','pending','prompt-sent','generated','selected','rejected']),
'queue renders only matching statuses':'if(filter!==\'all\'&&(sc.visualProductionStatus||\'pending\')!==filter)return' in html,
'filter change refreshes queue':'$(\'visualQueueFilter\').onchange=refreshVisualQueue' in html,
'summary includes filtered count':"Filtru: '+filtered+' scene" in html,
'empty-filter message implemented':'Nu există scene pentru filtrul selectat.' in html,
'filter does not rewrite production status':'visualQueueFilter' in html and 'scenes[i].visualProductionStatus=el.value' in html,
'versionCode 110':'versionCode = 110' in gradle,
'versionName 1.11':'versionName = "1.11-visual-queue-filter"' in gradle,
}
for n,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+n)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
