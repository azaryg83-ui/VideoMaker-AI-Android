from pathlib import Path
s=Path('app/src/main/assets/web/index.html').read_text()
checks={
 'IndexedDB history persistence key':'timeline-history:' in s,
 'history serialization and media conversion':'serializeScene' in s and 'blobToDataURL(sc.imageBlob)' in s and 'blobToDataURL(sc.videoBlob)' in s,
 'history hydration images/video/overlay':'hydrateHistoryScene' in s and 'overlayImageData' in s,
 'per-project history load':'loadTimelineHistoryPersistence' in s and 'currentProjectId' in s,
 'history load reset stacks':'timelineUndoStack=[];timelineRedoStack=[];timelineHistorySaved=false' in s,
 'persist on push and undo/redo':'persistTimelineHistory()' in s,
 'new project clears history':"await dbDelete('projects','timeline-history:'+currentProjectId)" in s,
 'project delete clears history':'dbDelete(\'projects\',\'timeline-history:\'+id)' in s,
 'version79':'versionCode = 79' in Path('app/build.gradle.kts').read_text() and '0.79-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
