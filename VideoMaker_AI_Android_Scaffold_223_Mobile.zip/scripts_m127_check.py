from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text(encoding='utf-8')
checks={
 'checksum helper exists':'function backupChecksum(obj)' in s,
 'checksum export metadata':'backupIntegrity={algorithm:\'fnv1a32\',checksum:backupChecksum(exportData)' in s,
 'checksum import verification':'actual!==expected' in s and 'importul a fost oprit' in s,
 'corrupt backup import blocked':'Fișierul poate fi corupt sau modificat; importul a fost oprit.' in s,
 'export remains per-project':'async function exportProjectBackup(id)' in s,
 'import preview retained':'IMPORT PROIECT' in s,
 'backup export format retained':'VideoMakerAI-project-backup-v1' in s,
 'project recovery features retained':'checkRecoveryBackup(id,p)' in s,
 'version code 84':'versionCode = 84' in Path('app/build.gradle.kts').read_text(),
 'version name 0.85':'versionName = "0.85-build-candidate"' in Path('app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
