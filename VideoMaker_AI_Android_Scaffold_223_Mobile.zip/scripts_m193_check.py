from pathlib import Path
import re
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
'Preset selector and apply button': 'audioMixPreset' in html and 'applyAudioMixPreset' in html,
'All four presets': all(x in html for x in ['documentary:{','cinematic:{','balanced:{','musicFocus:{']),
'Music solo preview': 'data-audio-solo="music"' in html,
'SFX solo preview': 'data-audio-solo="sfx"' in html,
'Solo preview stop control': 'stopSoloAudioPreview"' in html,
'Preset updates/autosaves': "scheduleAutosave();setStatus('Preset audio aplicat" in html,
'Synchronized preview preserved': 'startPreviewMixAt(sceneStart(cur)+elapsed)' in html,
'Version increment': 'versionCode = 149' in gradle and '1.50-audio-mix-presets-solo-preview' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL'),name)
assert all(checks.values())
