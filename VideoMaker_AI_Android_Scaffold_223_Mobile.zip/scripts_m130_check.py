from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks=[
('Project details placeholder', 'data-project-details=' in html),
('Async project record lookup', 'dbGet(\'projects\',item.id)' in html),
('Scene count', 'ss.length} scene' in html),
('Character count', 'cc.length} personaje' in html),
('Image attachment count', 'imgs}/${ss.length} scene cu imagine' in html),
('Duration summary', 'dur.toFixed(1)' in html),
('Graceful unavailable status', 'Detalii indisponibile' in html),
('Version code 87', 'versionCode = 87' in gradle),
('Version name 0.88', '0.88-build-candidate' in gradle),
]
for n,ok in checks: print(('PASS' if ok else 'FAIL')+' - '+n)
print(f'{sum(ok for _,ok in checks)}/{len(checks)} PASS')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
