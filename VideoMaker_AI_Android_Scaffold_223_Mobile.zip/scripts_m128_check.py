from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text()
checks={
'project search control':'id="projectLibrarySearch"' in s,
'type filter control':'id="projectLibraryTypeFilter"' in s,
'sort control':'id="projectLibrarySort"' in s,
'project count display':'id="projectLibraryCount"' in s,
'name search applied':'toLocaleLowerCase().includes(q)' in s,
'filter by type':'typeFilter===\'all\'||x.type===typeFilter' in s,
'recent sort':'sortMode===\'recent\'' in s or "else items.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0))" in s,
'oldest sort':"sortMode==='oldest'" in s,
'name ascending':"sortMode==='name-asc'" in s,
'name descending':"sortMode==='name-desc'" in s,
'no-results state':'Nu există proiecte care să corespundă căutării și filtrului.' in s,
'events wired':"['projectLibrarySearch','projectLibraryTypeFilter','projectLibrarySort']" in s,
'version bumped':'versionCode = 85' in Path('app/build.gradle.kts').read_text() and '0.86-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
