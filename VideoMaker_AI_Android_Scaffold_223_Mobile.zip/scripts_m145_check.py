from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'Auto plan renders per-step editor navigation buttons':'data-auto-plan-open="${i}"' in html and 'Deschide etapa în editor' in html,
 'Checklist steps still have completion checkboxes':'data-auto-plan-step="${i}"' in html,
 'Navigation handler reads selected plan step':'autoBriefRuntime?.productionPlan?.[i]' in html,
 'Script/voiceover maps to script tab':"let tab='script'" in html,
 'Scene stage maps to scenes tab':"t.includes('scene'))tab='scenes'" in html,
 'Visual/character stage maps to image module':"t.includes('vizual')||t.includes('material')||t.includes('personaj')" in html,
 'Subtitle stage maps to captions':"t.includes('subtitr'))tab='captions'" in html,
 'Edit/export/review maps to edit module':"t.includes('export')||t.includes('verific')" in html,
 'Editor navigation invoked on button action':"showEditor(tab);setStatus('Etapa deschisă" in html,
 'Version code 102':'versionCode = 102' in gradle,
 'Version name 1.03 candidate':'versionName = "1.03-auto-workflow-candidate"' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' | '+k)
print(f'RESULT {sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
