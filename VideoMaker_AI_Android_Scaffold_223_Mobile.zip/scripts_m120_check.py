from pathlib import Path
p=Path('app/src/main/assets/web/index.html');s=p.read_text()
checks={
'Undo control present':'id="timelineUndo"' in s,
'Redo control present':'id="timelineRedo"' in s,
'History bounded to 40':'timelineHistoryLimit=40' in s,
'History snapshot preserves scene refs':'function historyCloneScenes(){return scenes.map(sc=>{let cp=Object.assign({},sc);return cp})}' in s,
'Undo pushes current state to redo':'function timelineUndo(){if(!timelineUndoStack.length)return;timelineRedoStack.push({snapshot:timelineHistorySnapshot()' in s,
'Redo pushes current state to undo':'function timelineRedo(){if(!timelineRedoStack.length)return;timelineUndoStack.push({snapshot:timelineHistorySnapshot()' in s,
'Restore refreshes timeline and autosave':'renderScenes();draw();updateCounter();renderTimeline();loadCosmeticsFromScene();scheduleAutosave();setStatus' in s,
'Group actions create snapshots':all(x in s for x in ["pushTimelineHistory('Duplicare scene')","pushTimelineHistory('Ștergere scene')","pushTimelineHistory('Mutare grup scene')"]),
'Cut paste history recorded':all(x in s for x in ["pushTimelineHistory('Cut scene')","pushTimelineHistory('Paste scene')"]),
'Trim and duration history recorded':all(x in s for x in ["pushTimelineHistory('Trim scenă')","pushTimelineHistory('Durată scenă')"]),
'Zoom-aware trim delta':'let delta=(e.clientX-startX)/timelineZoom;' in s,
'Version 78':'versionCode = 78' in Path('app/build.gradle.kts').read_text() and '0.78-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
print(f'{sum(checks.values())}/{len(checks)}')
raise SystemExit(0 if all(checks.values()) else 1)
