from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text(encoding='utf-8')
checks={
 'tag filter control exists':'projectLibraryTagFilter' in s,
 'single-project tag editor':'data-tags' in s and 'Etichete separate prin virgulă' in s,
 'bulk tag action':'projectBulkTags' in s and 'Etichete comune' in s,
 'tag search':'x.tags.some(t=>String(t).toLocaleLowerCase().includes(q))' in s,
 'tag filter predicate':'x.tags.includes(tagFilter)' in s,
 'tag limits enforced':'slice(0,8)' in s and 'slice(0,24)' in s,
 'duplicate retains tags':'sourceMeta&&Array.isArray(sourceMeta.tags)' in s,
 'favorites preserved':'projectFavoritesOnly' in s,
 'type filter preserved':'typeFilter===\'all\'||x.type===typeFilter' in s,
 'build version updated':'versionCode = 89' in Path('app/build.gradle.kts').read_text() and '0.90-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
