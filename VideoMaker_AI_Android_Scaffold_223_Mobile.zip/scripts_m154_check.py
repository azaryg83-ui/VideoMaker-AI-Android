from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text(encoding='utf-8')
g=Path('app/build.gradle.kts').read_text(encoding='utf-8')
checks={
 'bulk status selector exists':'visualQueueBulkStatus' in s,
 'bulk apply button exists':'applyVisualQueueBulkStatus' in s,
 'bulk status targets filtered scenes':'target=scenes.filter(sc=>filter===\'all\'||(sc.visualProductionStatus||\'pending\')===filter)' in s,
 'confirmation dialog protects bulk update':'confirm(\'Aplic statusul' in s,
 'empty target handled':'Nu există scene în filtrul selectat pentru actualizare.' in s,
 'autosave scheduled after bulk update':'target.forEach(sc=>sc.visualProductionStatus=status);refreshVisualQueue();scheduleAutosave();' in s,
 'versionCode 111':'versionCode = 111' in g,
 'versionName 1.12':'versionName = "1.12-visual-queue-bulk-status"' in g,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' — '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
