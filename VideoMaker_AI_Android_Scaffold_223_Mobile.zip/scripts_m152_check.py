from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
'visual queue renders per-scene production tracker':'data-visualstatus="${i}"' in html and 'data-visualnote="${i}"' in html,
'five production states available':'prompt-sent' in html and 'generated' in html and 'selected' in html and 'rejected' in html and 'pending' in html,
'status changes schedule autosave':'scenes[i].visualProductionStatus=el.value' in html and 'scheduleAutosave()' in html,
'notes persist via scene autosave':'scenes[i].visualProductionNote=el.value' in html,
'project serializer includes tracker status and note':'visualProductionStatus:s.visualProductionStatus||"pending"' in html and 'visualProductionNote:s.visualProductionNote||""' in html,
'prompt-pack JSON includes production status and note':'productionStatus:sc.visualProductionStatus||\'pending\'' in html and 'productionNote:sc.visualProductionNote||\'\'' in html,
'visual-queue TXT report includes tracker data':'Progres materiale: ${visualProductionLabel' in html and 'Notă: ${x.sc.visualProductionNote' in html,
'production summary calculates counts':'counts.selected' in html and 'counts.generated' in html and 'counts.pending' in html,
'versionCode bumped to 109':'versionCode = 109' in gradle,
'versionName bumped to 1.10':'versionName = "1.10-visual-production-tracker"' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
