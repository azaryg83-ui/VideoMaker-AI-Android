
// Milestone 179: use edited audio activity intervals as navigable montage markers.
(function(){
 const editor=document.getElementById('audioIntervalEditor'); if(!editor)return;
 const row=document.createElement('div'); row.className='card'; row.style.marginTop='10px'; row.innerHTML='<h3 style="margin:0 0 8px">🎬 Marcaje audio pentru timeline</h3><p class="muted">Intervalele active editate sunt afișate ca marcaje temporale. Apasă un marcaj pentru a selecta scena aproximativă la acel timp. Marcajele nu schimbă automat durata sau ordinea scenelor.</p><button id="applyAudioMontageMarkers" class="primary">📍 Aplică intervalele ca marcaje de montaj</button><div id="audioMontageMarkersStatus" class="muted" style="margin:8px 0">Nu există marcaje aplicate.</div><div id="audioMontageMarkers" class="row" style="gap:6px"></div>'; editor.appendChild(row);
 const status=document.getElementById('audioMontageMarkersStatus'), markers=document.getElementById('audioMontageMarkers'); let latest=null;
 window.addEventListener('vm-audio-intervals',e=>{latest=e.detail; status.textContent='Analiza a fost încărcată. Editează intervalele mai sus, apoi aplică marcajele.';});
 document.getElementById('applyAudioMontageMarkers').onclick=()=>{
   let saved=null; try{saved=JSON.parse(localStorage.getItem('vm_audio_intervals_v178')||'null')}catch(e){}
   let arr=(saved?.intervals||latest?.intervals||[]).map(x=>({start:Number(x.start),end:Number(x.end)})).filter(x=>Number.isFinite(x.start)&&Number.isFinite(x.end)&&x.end>x.start).sort((a,b)=>a.start-b.start);
   if(!arr.length){status.textContent='Nu există intervale audio valide. Analizează voiceoverul și/sau adaugă intervale manual.';markers.innerHTML='';return;}
   window.__vmAudioMontageMarkers=arr; markers.innerHTML=arr.map((x,i)=>`<button type="button" class="small" data-audiomarker="${i}">📍 ${i+1} · ${x.start.toFixed(2)}–${x.end.toFixed(2)} s</button>`).join('');
   status.textContent=`${arr.length} marcaje de montaj aplicate din intervalele audio editate. Atinge un marcaj pentru a naviga la scena corespunzătoare.`;
   markers.querySelectorAll('[data-audiomarker]').forEach(btn=>btn.onclick=()=>{let m=arr[Number(btn.dataset.audiomarker)],t=m.start,acc=0,idx=0;for(let i=0;i<scenes.length;i++){let d=Math.max(.1,Number(scenes[i].duration)||7);if(t<acc+d){idx=i;break;}acc+=d;idx=Math.min(i,scenes.length-1);}if(scenes.length){cur=idx;elapsed=Math.max(0,t-acc);selectedTimelineScenes=new Set([idx]);renderScenes();draw();updateCounter();renderTimeline();scheduleAutosave();setStatus(`Navigat la marcaj audio ${Number(btn.dataset.audiomarker)+1}, aproximativ ${t.toFixed(2)} secunde.`);}else status.textContent='Creează scenele înainte de a naviga la marcaj.';});
 };
})();
