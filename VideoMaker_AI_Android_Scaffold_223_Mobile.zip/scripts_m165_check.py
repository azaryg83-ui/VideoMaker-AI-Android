from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'runtime short settings variable':'shortVideoSettingsRuntime=null' in html,
 'project serialization includes short settings':'shortVideoSettings:shortVideoSettingsRuntime' in html,
 'project schema version bumped to 8':'return {version:8,projectType:' in html,
 'import restore path restores short settings':html.count('shortVideoSettingsRuntime=p.shortVideoSettings||null')>=2,
 'new short project writes runtime settings':'shortVideoSettingsRuntime={targetDurationSeconds:d' in html,
 'flow version upgraded to 2':'flowVersion:2' in html,
 'Android version code 123':'versionCode = 123' in gradle,
 'Android version name 1.24':'1.24-short-plan-generator' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
if not all(checks.values()): raise SystemExit(1)
