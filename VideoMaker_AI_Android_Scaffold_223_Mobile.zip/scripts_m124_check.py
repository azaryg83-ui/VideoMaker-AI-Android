from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text()
checks={
 'dashboard import button': 'importProjectLibrary' in s,
 'file input accepts JSON': 'projectLibraryImportFile' in s and 'accept=".json,application/json"' in s,
 'new unique imported project ID': 'project-import-' in s,
 'non-destructive import suffix': '(importat)' in s,
 'project format validation': "Array.isArray(p.scenes)" in s and "typeof p.name!=='string'" in s,
 'indexeddb project storage': "await dbPut('projects',id,p)" in s,
 'project index update': 'items.push({id,name:p.name' in s,
 'dashboard refresh': 'await refreshProjectDashboard()' in s,
 'file picker reset': 'e.target.value=\'\'' in s,
 'milestone documentation': Path('MILESTONE_124.md').exists(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' — '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
