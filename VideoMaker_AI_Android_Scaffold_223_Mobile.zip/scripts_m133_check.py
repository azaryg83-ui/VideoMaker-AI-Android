from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text(encoding='utf-8')
g=Path('app/build.gradle.kts').read_text(encoding='utf-8')
checks={
 'status filter control and four values':all(x in s for x in ['projectLibraryStatusFilter','value="draft"','value="progress"','value="ready"','value="archived"']),
 'status filter included in refresh listeners':'projectLibraryStatusFilter' in s and "statusFilter=$('projectLibraryStatusFilter')?.value||'all'" in s,
 'status filter predicate':"(x.status||'draft')===statusFilter" in s,
 'status displayed in project cards':'📌 Status:' in s and all(x in s for x in ['Ciornă','În lucru','Gata','Arhivat']),
 'status cycle handler':'data-status' in s and "statuses=['draft','progress','ready','archived']" in s,
 'status persists to project index':'it.status=next;await saveIndex(items)' in s,
 'legacy projects default draft':"x.status||'draft'" in s,
 'duplicate preserves status':"status:sourceMeta&&sourceMeta.status||'draft'" in s,
 'existing tags and favorite support retained':'projectFavoritesOnly' in s and 'projectLibraryTagFilter' in s and 'data-tags' in s,
 'version bumped':'versionCode = 90' in g and '0.91-build-candidate' in g,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
