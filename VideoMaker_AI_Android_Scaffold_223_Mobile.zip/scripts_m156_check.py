from pathlib import Path
import re
root=Path(__file__).resolve().parent
html=(root/'app/src/main/assets/web/index.html').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'scene cards expose batch-selection checkbox':'data-ai-select' in html and 'Include în batch AI' in html,
 'selection is based on scene object references':'aiSelectedSceneRefs=new Set()' in html,
 'select missing images action exists':'aiSelectMissing' in html and 'scenes.filter(sc=>!sc.img)' in html,
 'select all scenes action exists':'aiSelectAll' in html and 'new Set(scenes)' in html,
 'clear selection action exists':'aiClearSelection' in html and 'aiSelectedSceneRefs.clear()' in html,
 'generate selected scenes action exists':'aiGenerateSelected' in html and 'Generare pentru scene selectate' in html,
 'batch still uses existing runAiBatch pipeline':'runAiBatch(todo,\'Generare pentru scene selectate\')' in html,
 'versionCode bumped to 113':'versionCode = 113' in gradle,
 'versionName bumped to 1.14 candidate':'versionName = "1.14-ai-selected-scenes"' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
print(f'{sum(checks.values())}/{len(checks)} checks PASS')
if not all(checks.values()): raise SystemExit(1)
