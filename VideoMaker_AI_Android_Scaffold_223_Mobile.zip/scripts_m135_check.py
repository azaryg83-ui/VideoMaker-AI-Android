from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
'bulk favorite control added':'id="projectBulkFavorite"' in html,
'bulk favorite action handler exists':"projectBulkFavorite').onclick=async()=>{" in html,
'selection required guard':'Selectează mai întâi proiecte.' in html,
'mixed selection determines toggle direction':'chosen.some(it=>!it.favorite)' in html,
'bulk favorite loop updates selected projects':'for(const it of chosen)it.favorite=makeFavorite' in html,
'index save and refresh included':'await saveIndex(items);await refreshProjectDashboard();' in html,
'completion text included':'Favorite activate pentru' in html and 'Favorite dezactivate pentru' in html,
'code version 92':'versionCode = 92' in gradle,
'version name 0.93':'versionName = "0.93-build-candidate"' in gradle,
'milestone file present':Path('MILESTONE_135.md').exists(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
