from pathlib import Path
import re
root=Path(__file__).resolve().parent
html=(root/'app/src/main/assets/web/index.html').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
'profile selector exists':'aiGenerationProfile' in html,
'economy preset':"economy:{steps:'6',sampler:'Euler'}" in html,
'balanced preset':"balanced:{steps:'8',sampler:'Euler a'}" in html,
'quality preset':"quality:{steps:'12',sampler:'DPM++ 2M'}" in html,
'save custom profile handler':"$('aiSaveProfile').onclick" in html,
'delete custom profile handler':"$('aiDeleteProfile').onclick" in html,
'local custom profiles persistence':'videomaker_ai_generation_profiles_v1' in html,
'custom endpoint captured':'endpoint:$(' in html,
'apply updates steps and sampler':"$('aiSteps').value=String(v.steps||8);$('aiSampler').value=v.sampler||'Euler a'" in html,
'selected profile persisted':'videomaker_ai_generation_profile_selected_v1' in html,
'versionCode incremented':'versionCode = 115' in gradle,
'versionName updated':'1.16-ai-generation-profiles' in gradle,
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()):raise SystemExit(1)
