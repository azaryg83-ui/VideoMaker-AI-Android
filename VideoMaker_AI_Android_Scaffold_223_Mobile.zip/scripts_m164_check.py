from pathlib import Path
p=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
assert "active!=='project'" in p
assert "window.activeVideoMakerTab=tab" in p
assert "window.handleAppBack" in p
print('PASS | Back wizard closes first')
print('PASS | Back non-project editor tab returns to project tab')
print('PASS | Back project tab returns to Home')
print('PASS | active editor tab state exposed')
