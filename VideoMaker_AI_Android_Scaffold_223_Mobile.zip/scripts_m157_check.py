from pathlib import Path
import re
root=Path(__file__).parent
html=(root/'app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text(encoding='utf-8')
checks={
 'batch preflight function exists':'function aiBatchPreflight(todo,label)' in html,
 'preflight counts missing prompts':'Scene fără prompt vizual explicit:' in html,
 'preflight counts missing captions':'Scene fără descriere/narațiune:' in html,
 'preflight reports already-generated images':'Scene care au deja imagine:' in html,
 'selected batch gated by preflight':"aiBatchPreflight(todo,'Generare pentru scene selectate')" in html,
 'missing-image batch gated by preflight':"aiBatchPreflight(todo,'Generare scene fără imagini')" in html,
 'versionCode 114':'versionCode = 114' in gradle,
 'versionName 1.15':'versionName = "1.15-ai-batch-preflight"' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
