from pathlib import Path
import re
p=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
'visual queue UI added':'visualQueueList' in p and 'refreshVisualQueue' in p,
'per-scene status fields':'visualSceneStatus' in p and all(x in p for x in ['prompt:!!String','image:!!(sc.img','video:!!(sc.videoEl','character:!!sc.characterId']),
'jump-to-scene action':'data-visualjump' in p,
'prompt copy action':'data-visualcopy' in p and 'navigator.clipboard.writeText' in p,
'missing-assets TXT export':'coada_materialelor_vizuale.txt' in p and 'exportVisualQueue' in p,
'queue refreshed after scene rendering':'renderStoryboard();refreshVisualQueue();' in p,
'versionCode 107':'versionCode = 107' in gradle,
'versionName 1.08':'versionName = "1.08-visual-queue"' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
assert all(checks.values())
print(f'{sum(checks.values())}/{len(checks)} PASS')
