from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=Path('app/build.gradle.kts').read_text(encoding='utf-8')
checks={
 'production plan preview markup':'id="autoProductionPlanPreview"' in html,
 'plan generator function':'function buildAutoProductionPlan(type,duration)' in html,
 'short-form hook task':'Builds the hook' in html or 'Construiește hook-ul de început' in html,
 'plan task IDs and completion state':"id:'auto-step-'+(i+1),done:false" in html,
 'plan preview generated on review':"$('autoProductionPlanPreview').innerHTML=plan.map" in html,
 'production plan persisted in autoBrief':'productionPlan:buildAutoProductionPlan(selectedType' in html,
 'plan version recorded':'planVersion:1,version:2' in html,
 'version code 99':'versionCode = 99' in gradle,
 'version name 1.00':'versionName = "1.00-build-candidate"' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
