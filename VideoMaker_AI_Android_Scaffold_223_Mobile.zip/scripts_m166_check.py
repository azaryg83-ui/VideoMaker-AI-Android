from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'planner panel present':'shortPlannerCard' in html,
 'preview action present':'shortPlanPreview' in html,
 'separate apply action present':'shortPlanApply' in html,
 'planner reads short-video target settings':'targetDurationSeconds' in html and 'settings.hook' in html and 'settings.cta' in html,
 'preview builds plan without applying':'renderShortPlan(buildShortPlan())' in html,
 'apply creates editable scene objects':'scenes=shortPlanDraft.items.map' in html,
 'scene duration totals target with correction':'rounded[rounded.length-1]=+(rounded[rounded.length-1]+diff).toFixed(2)' in html,
 'apply triggers autosave':'scheduleAutosave();$(\'shortPlanStatus\')' in html,
 'versionCode updated to 123':'versionCode = 123' in gradle,
 'versionName updated to 1.24':'1.24-short-plan-generator' in gradle,
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' - '+k)
if not all(checks.values()):raise SystemExit(1)
