from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=Path('app/build.gradle.kts').read_text(encoding='utf-8')
checks={
 'three step Auto wizard markup':'id="autoStep1"' in html and 'id="autoStep2"' in html and 'id="autoStep3"' in html,
 'step navigation controls':'id="autoStepNext"' in html and 'id="autoStepBack"' in html,
 'step indicator':'id="autoStepIndicator"' in html,
 'required idea validation':'Descrie mai întâi ideea videoclipului.' in html,
 'brief review summary':'id="autoBriefReview"' in html,
 'project name synced from Auto wizard':"$('homeProjectName').value=$('homeProjectNameAuto').value" in html,
 'wizard reset when launching mode':'autoStep=1;renderAutoStep();' in html,
 'transparent AI status':'generarea completă AI nu este încă conectată' in html,
 'version code 98':'versionCode = 98' in gradle,
 'version name 0.99':'0.99-build-candidate' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
