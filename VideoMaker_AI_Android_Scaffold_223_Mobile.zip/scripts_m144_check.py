from pathlib import Path
import re
root=Path(__file__).parent
app=(root/'app/build.gradle.kts').read_text()
wf=(root/'.github/workflows/android-build.yml').read_text()
guide=(root/'UPDATE_SIGNING_GUIDE_144.md').read_text()
checks={
 'package id preserved': 'applicationId = "com.videomakerai.app"' in app,
 'versionCode increased to 101': 'versionCode = 101' in app,
 'versionName updated': 'versionName = "1.02-update-ready-candidate"' in app,
 'stable signing credentials read from environment': all(x in app for x in ['VIDEOMAKER_STABLE_KEYSTORE','VIDEOMAKER_STABLE_KEYSTORE_PASSWORD','VIDEOMAKER_STABLE_KEY_ALIAS','VIDEOMAKER_STABLE_KEY_PASSWORD']),
 'stable signing assigned to debug build when configured': 'if (hasStableSigning) signingConfig = signingConfigs.getByName("ciStable")' in app,
 'workflow uses keystore secret': 'secrets.VIDEOMAKER_KEYSTORE_BASE64' in wf,
 'workflow uses all four signing secrets': all(x in wf for x in ['VIDEOMAKER_KEYSTORE_PASSWORD','VIDEOMAKER_KEY_ALIAS','VIDEOMAKER_KEY_PASSWORD']),
 'fallback warning present': 'will not be update-stable' in wf,
 'guide warns about first signature migration': 'may require uninstalling the current app once' in guide,
 'keystore not committed': 'must never be committed' in guide,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
