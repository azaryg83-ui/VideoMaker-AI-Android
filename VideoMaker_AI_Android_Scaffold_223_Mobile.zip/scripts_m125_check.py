from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text()
checks={
 'Import preview analysis function':'async function analyzeImportedProject(p,file)' in s,
 'Scene and character counts':'sceneCount:(p.scenes||[]).length' in s and 'characterCount:' in s,
 'File size preview':'fileSize:file?file.size:0' in s,
 'Warnings surfaced in preview':'Atenționări:' in s,
 'Confirmation before import':'if(!confirm(preview))return' in s,
 'Malformed scene filtering':'p.scenes=p.scenes.filter(sc=>sc&&typeof sc===\'object\')' in s,
 'Metadata defaults':'p.projectType=p.projectType||\'documentary\'' in s and 'p.projectMode=p.projectMode||\'auto\'' in s,
 'Import remains new-project':'project-import-' in s and '(importat)' in s,
 'Version bumped':'versionCode = 82' in Path('app/build.gradle.kts').read_text() and '0.83-build-candidate' in Path('app/build.gradle.kts').read_text(),
 'Documentation present':Path('MILESTONE_125.md').exists(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
