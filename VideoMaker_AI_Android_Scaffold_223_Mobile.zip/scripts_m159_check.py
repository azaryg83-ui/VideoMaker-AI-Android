from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'CFG control added':'id="aiCfgScale"' in html,
 'seed mode control added':'id="aiSeedMode"' in html and 'value="scene"' in html,
 'fixed seed control added':'id="aiFixedSeed"' in html,
 'profiles store CFG and seed':'cfgScale:String($(\'aiCfgScale\').value||7)' in html and 'seedMode:$ (\'aiSeedMode\')' not in html,
 'built-in presets have CFG and seed':'economy:{steps:\'6\',sampler:\'Euler\',cfgScale:' in html and 'quality:{steps:\'12\',sampler:\'DPM++ 2M\',cfgScale:' in html,
 'request payload uses configurable CFG':'cfg_scale:Math.max(1,Math.min(30,Number($(\'aiCfgScale\').value)||7))' in html,
 'request payload includes seed strategy':'let seedMode=$(\'aiSeedMode\').value||\'random\'' in html and 'seed,width,height,batch_size:1' in html,
 'scene seed deterministic':'Math.imul(h,16777619)' in html,
 'legacy profile defaults supported':'$(\'aiCfgScale\').value=String(v.cfgScale||7)' in html,
 'version code 116':'versionCode = 116' in gradle,
 'version name 1.17':'versionName = "1.17-ai-generation-controls"' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
print(f'{sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
