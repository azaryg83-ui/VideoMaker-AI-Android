from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text()
checks={
 'recovery backup IndexedDB key':'recovery-backup:' in s,
 'two backup generations retained':'history=history.slice(0,2)' in s,
 'periodic 60-second backup':'periodic-60s' in s and '60000' in s,
 'backup before hidden/pagehide lifecycle':'app-hidden' in s and 'pagehide' in s,
 'recovery offered when backup newer':'Am găsit o copie de recuperare mai recentă' in s,
 'recovery restored into project and autosave':'await dbPut(\'projects\',id,latest.project)' in s and "await dbPut('projects','autosave',latest.project)" in s,
 'open project checks backup':'checkRecoveryBackup(id,p)' in s,
 'delete removes recovery backup':"recovery-backup:'+id" in s,
 'new project removes stale recovery backup':"recovery-backup:'+currentProjectId" in s,
 'build version 80':'versionCode = 80' in Path('app/build.gradle.kts').read_text() and '0.80-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
if not all(checks.values()): raise SystemExit(1)
