from pathlib import Path
import re
html=Path('app/src/main/assets/web/index.html').read_text()
checks={
 'favorite-only toggle present':'projectFavoritesOnly' in html,
 'favorite state filter':'(!projectFavoritesOnly||!!x.favorite)' in html,
 'favorite sorting before others':'items.sort((a,b)=>(b.favorite?1:0)-(a.favorite?1:0))' in html,
 'favorite badge in card':'${x.favorite?' in html,
 'favorite action button':'data-favorite=' in html,
 'favorite toggles index item':'it.favorite=!it.favorite' in html,
 'search and type filter retained':'typeFilter===\'all\'||x.type===typeFilter' in html,
 'filter status includes favorite mode':'projectFavoritesOnly?' in html,
 'version code bumped':'versionCode = 88' in Path('app/build.gradle.kts').read_text(),
 'version name bumped':'0.89-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
