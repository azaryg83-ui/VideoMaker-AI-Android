#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HTML="$ROOT/app/src/main/assets/web/index.html"
WEB="$ROOT/app/src/main/assets/web"
command -v node >/dev/null 2>&1 || { echo "ERROR: Node.js is required for frontend syntax check" >&2; exit 2; }
test -f "$HTML" || { echo "ERROR: web editor HTML missing" >&2; exit 2; }
python3 - "$HTML" "$WEB" <<'PY'
from pathlib import Path
import re, sys
html=Path(sys.argv[1]).read_text(encoding='utf-8')
web=Path(sys.argv[2])
# Basic structure/assets check, deliberately not a replacement for Android WebView runtime testing.
if '<!doctype html' not in html.lower():
    raise SystemExit('ERROR: HTML doctype missing')
if '<title>' not in html or '</title>' not in html:
    raise SystemExit('ERROR: document title missing')
for asset in ('manifest.json', 'icon.svg', 'sw.js'):
    if not (web/asset).is_file():
        raise SystemExit(f'ERROR: expected web asset missing: {asset}')
ids=set(re.findall(r'\bid=["\']([^"\']+)["\']', html))
required=('projectName','ratio','script','splitBtn','preview','playBtn','pauseBtn','sceneTrack','subtitleFont','autoCaptions','exportSrt')
missing=[x for x in required if x not in ids]
if missing:
    raise SystemExit('ERROR: required editor controls missing: '+', '.join(missing))
scripts=re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',html,re.S)
if not scripts:
    raise SystemExit('ERROR: no inline JavaScript found')
for i, script in enumerate(scripts):
    if not script.strip():
        raise SystemExit(f'ERROR: empty script block {i}')
print(f'HTML_STRUCTURE_PASS: {len(ids)} IDs, {len(scripts)} inline script block(s), required controls/assets present')
PY
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 - "$HTML" "$TMP" <<'PY'
from pathlib import Path
import re, sys
html=Path(sys.argv[1]).read_text(encoding='utf-8')
tmp=Path(sys.argv[2])
for i, script in enumerate(re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',html,re.S)):
    (tmp/f'script-{i}.js').write_text(script,encoding='utf-8')
PY
for js in "$TMP"/*.js; do node --check "$js"; done
# Static Android WebView bridge safety checks. These do not replace Kotlin compilation or runtime testing.
KOTLIN="$ROOT/app/src/main/java/com/videomakerai/app/MainActivity.kt"
python3 - "$KOTLIN" <<'CHECK_KOTLIN'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
checks={
  'external navigation blocked': 'return !url.startsWith(trustedEditorPrefix)' in s,
  'universal file access disabled': 'allowUniversalAccessFromFileURLs = false' in s,
  'file-origin access disabled': 'allowFileAccessFromFileURLs = false' in s,
  'content access disabled': 'allowContentAccess = false' in s,
  'Safe Browsing enabled': 'safeBrowsingEnabled = true' in s,
}
failed=[name for name,ok in checks.items() if not ok]
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if failed: raise SystemExit('ERROR: Android WebView hardening checks failed: '+', '.join(failed))
print(f'ANDROID_WEBVIEW_STATIC_CHECK_PASS: {len(checks)} checks')
CHECK_KOTLIN
python3 "$ROOT/scripts/bridge_contract_check.py"
# Offline-first privacy check: app must not request network access unless deliberately reintroduced.
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
if grep -q 'android.permission.INTERNET' "$MANIFEST"; then
  echo "ERROR: INTERNET permission present; offline-first build must not request network access." >&2
  exit 2
fi
if ! grep -q 'android:usesCleartextTraffic="false"' "$MANIFEST"; then
  echo "ERROR: cleartext network traffic must remain disabled." >&2
  exit 2
fi
echo "OFFLINE_PRIVACY_STATIC_CHECK_PASS: no INTERNET permission; cleartext traffic disabled."
# Model-library integrity metadata checks: checksum is calculated while streaming import and stored beside model.
python3 - "$KOTLIN" "$HTML" <<'MODEL_CHECK'
from pathlib import Path
import sys
kotlin=Path(sys.argv[1]).read_text(encoding='utf-8')
html=Path(sys.argv[2]).read_text(encoding='utf-8')
checks={
  'SHA-256 streaming digest': 'MessageDigest.getInstance("SHA-256")' in kotlin and 'digest.update(buffer, 0, read)' in kotlin,
  'checksum sidecar write': '.sha256' in kotlin and 'checksumTarget' in kotlin,
  'model inventory exposes checksum': 'sha256' in kotlin and 'm.sha256' in html,
  'checksum deletion constrained to private models directory': 'sidecar.parentFile == modelsDirectory().canonicalFile' in kotlin and 'sidecar.delete()' in kotlin,
  'checksum write is synced': 'checksumOutput.fd.sync()' in kotlin,
  'failed checksum removes imported model': 'target.delete()' in kotlin and 'Import anulat: nu am putut salva verificarea SHA-256' in kotlin,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()): raise SystemExit('MODEL_INTEGRITY_STATIC_CHECK_FAIL')
print('MODEL_INTEGRITY_STATIC_CHECK_PASS: '+str(len(checks))+' checks')
MODEL_CHECK
python3 - "$KOTLIN" <<'SAFE_MODEL_CHECK'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
checks={
  'model filename/path validation helper': 'private fun safeModelFile' in s,
  'canonical model path constrained to private library': 'candidate.parentFile != dir' in s,
  'severe thermal state blocks native generation': 'THERMAL_STATUS_SEVERE' in s,
  'thermal block reports status to editor': 'THERMAL_BLOCKED' in s,
}
for name,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+name)
if not all(checks.values()): raise SystemExit('NATIVE_MODEL_SAFETY_CHECK_FAIL')
print('NATIVE_MODEL_SAFETY_CHECK_PASS: 4 checks')
SAFE_MODEL_CHECK
echo "FRONTEND_CHECK_PASS: HTML structure/assets and inline JavaScript syntax validated; Android WebView security settings statically checked (runtime test pending)."

# Native generated-image payload validation: dimensions, channel count, base64, byte size and canvas context.
python3 - <<'PY'
from pathlib import Path
html = Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
checks = {
    'payload dimensions bounded to 512': 'width>512||height>512' in html,
    'channel count constrained': '![3,4].includes(channels)' in html,
    'base64 decode guarded': 'payload base64 invalid' in html,
    'decoded bytes size validated': 'bytes.length!==width*height*channels' in html,
    'canvas context guarded': 'context canvas indisponibil' in html,
}
for label, ok in checks.items():
    print(('PASS: ' if ok else 'FAIL: ') + label)
if not all(checks.values()):
    raise SystemExit(1)
print('NATIVE_IMAGE_PAYLOAD_GUARD_PASS: 5 checks')
PY
# Experimental WebM export should mix imported voiceover audio and extend duration when audio is longer.
python3 - <<'PY'
from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
checks={
  'export decodes imported voiceover': 'ctx.decodeAudioData(await uploadedAudio.arrayBuffer())' in html or 'audioCtx.decodeAudioData(await uploadedAudio.arrayBuffer())' in html,
  'audio routed to recorder stream': 'audioDest.stream.getAudioTracks()' in html,
  'voiceover starts with recording': 'if(audioSource)audioSource.start(0)' in html,
  'export duration includes voiceover': 'Math.max(sceneTotal,audioDuration)' in html,
  'last scene held after scene timeline': 'cur=scenes.length-1;elapsed=scenes[cur].duration' in html,
  'export cleanup stops stream tracks': 'mixedStream.getTracks().forEach(t=>t.stop())' in html,
}
for label,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+label)
if not all(checks.values()): raise SystemExit('WEBM_AUDIO_EXPORT_STATIC_CHECK_FAIL')
print('WEBM_AUDIO_EXPORT_STATIC_CHECK_PASS: '+str(len(checks))+' checks')
PY
# Scene motion recommendation heuristic: distinct motion categories are assigned by text context.
python3 - <<'PY'
from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
checks={
 'motion heuristic function exists':'function estimateMotion(text)' in html,
 'landscape context suggests pan':'return \'pan right\'' in html,
 'urban context suggests zoom out':'return \'slow zoom out\'' in html,
 'scene splitting assigns estimated motion':'motion:estimateMotion(p)' in html,
}
for label,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+label)
if not all(checks.values()): raise SystemExit('SCENE_MOTION_HEURISTIC_FAIL')
print('SCENE_MOTION_HEURISTIC_PASS: 4 checks')
PY
