# Milestone 179 — Audio activity markers for montage timeline

- Added an editor panel to apply edited audio activity intervals as navigable montage markers.
- Marker buttons show each interval's start/end times.
- Tapping a marker navigates to the approximate scene position in the current scene timeline, selects that scene, and updates preview/timeline.
- Marker application reads the saved edited interval list (`vm_audio_intervals_v178`) when available.
- Markers do **not** automatically alter scene duration or scene order; this avoids destructive auto-editing.
- VersionCode 136, VersionName 1.37-audio-montage-markers.
- Source-level validation only; APK build/device testing not performed.
