# Scaffold 153 — Filtrare coadă materiale vizuale

- Adăugat filtru pentru toate scenele / neînceput / prompt trimis / material generat / selectat / respins.
- Coadă afișează doar scenele care corespund filtrului, păstrând indicii originali pentru acțiuni.
- Sumarul de producție afișează numărul de scene pentru filtrul ales.
- Mesaj clar când filtrul nu are scene.
- Filtrarea este doar de afișare; nu modifică statusurile, notele sau exporturile.
- VersionCode 110; VersionName 1.11-visual-queue-filter.
