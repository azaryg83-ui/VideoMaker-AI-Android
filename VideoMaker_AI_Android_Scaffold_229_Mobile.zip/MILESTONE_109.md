# Milestone 109 — Timeline video și trim sursă

- Scenele au durată de timeline editabilă cu increment 0.1 sec.
- Pentru scenele cu clip video importat, utilizatorul poate seta trim-in și trim-out pe fișierul sursă.
- Trim-in/out este păstrat în proiect și restaurat la import/recuperare.
- Previzualizarea folosește intervalul video selectat, repetând în interiorul intervalului dacă durata timeline depășește fragmentul.
- Exportul realtime folosește același interval sursă.
- Timeline-ul existent permite click pentru selectarea scenei și drag-and-drop pentru reordonare; tooltip afișează trim-ul sursă.
- Durata scenei timeline este separată de trim-ul sursă, pentru flexibilitate de montaj.

Verificare statică JavaScript și arhivă ZIP: urmează rularea.
Build Android și test pe dispozitiv: neefectuate.
