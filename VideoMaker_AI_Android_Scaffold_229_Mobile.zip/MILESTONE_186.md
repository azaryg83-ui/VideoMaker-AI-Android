# Milestone 186 — Shared draft preview timeline

Added a shared draft-preview timeline control: pause/resume for the draft animation and native merged WAV playback, a seek slider, elapsed/total display, and native seek support for the merged voiceover player.

Native bridge additions: pauseMergedVoiceover(), resumeMergedVoiceover(), seekMergedVoiceover(seconds), getMergedVoiceoverDurationSeconds(). The preview UI synchronizes its elapsed cursor with native WAV seeking when voiceover mode is enabled.

Limitations: synchronization remains approximate and relies on browser animation timing and native MediaPlayer seek; not frame-accurate, no actual video frame decode/compose pipeline, and no build/device test in this milestone.

Version: versionCode 143, versionName 1.44-shared-preview-timeline.
