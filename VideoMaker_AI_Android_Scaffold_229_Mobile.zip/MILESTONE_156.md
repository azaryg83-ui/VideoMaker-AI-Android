# Scaffold 156 — AI batch generation for selected scenes

Based on the extracted Scaffold 155 source.

## Change
- Scene cards have an `Include în batch AI` checkbox.
- Scene selection tracks scene object references (not just numeric indexes), so selection survives scene reordering.
- Added actions: select scenes without images, select all, clear selection, and generate for selected scenes.
- Selected-scene generation reuses the existing `runAiBatch` path and the same connected AUTOMATIC1111/Forge-compatible server; no AI engine is newly bundled.

## Verification
- Static feature checker: 9/9 PASS.
- All 4 inline JS scripts passed `node --check`.
- ZIP integrity checked after packaging.
- APK build and phone test not performed.

VersionCode 113; VersionName 1.14-ai-selected-scenes.
