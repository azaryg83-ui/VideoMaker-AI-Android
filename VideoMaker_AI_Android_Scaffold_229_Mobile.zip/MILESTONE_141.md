# Scaffold 141 — Auto Intelligent brief wizard in 3 steps

- Replaced the single long Auto Intelligent brief form with a phone-friendly 3-step flow: idea, audience/tone, duration/project name and review.
- Added step indicator, Back/Continue controls, required idea validation, and review summary before confirming.
- Auto mode remains transparent: the app stores/prepares the brief; full AI scenario generation is not yet connected.
- Existing project creation and short-video configuration remain in place; Auto name is synchronized into project name.
- Version Code 98; Version Name 0.99-build-candidate.
- APK build and device testing not performed.
