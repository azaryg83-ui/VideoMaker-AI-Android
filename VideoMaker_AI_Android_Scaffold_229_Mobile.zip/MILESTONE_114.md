# Milestone 114 — Drag-to-position audio clips on timeline

- Added direct touch/pointer dragging for music and SFX clips on their timeline lanes.
- Drag movement converts pixels to seconds using the timeline scale (8 px/sec).
- Clip start position is clamped to non-negative time and the project timeline bounds.
- On release, the start position is written to the track settings, timeline is rerendered, and autosave is scheduled.
- Existing scene drag/reorder and scene-duration controls are retained.
- Version: 0.72-build-candidate (versionCode 72).

Verification is static/source-based; Android APK build and device testing not performed.
