# Scaffold 138 — Bundle de backup/import pentru proiecte

- Exportă proiectele selectate într-un singur fișier JSON bundle, în loc de descărcări individuale.
- Pachetul include proiectele și backup-integrity per proiect, plus checksum la nivel de pachet.
- Importă bundle în bibliotecă drept proiecte noi, cu ID-uri noi; verifică checksum-ul pachetului și al fiecărui proiect.
- Confirmare înainte de import; proiectele invalide sunt ignorate.
- Version Code 95; Version Name 0.96-build-candidate.
- Validări: checker, syntaxă JS, ZIP integrity. APK-ul nu este compilat/testat aici.
