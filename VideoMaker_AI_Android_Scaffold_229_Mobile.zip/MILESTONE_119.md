# Milestone 119 — Clipboard scene operations

Implemented:
- Copy selected scenes into an in-app scene clipboard.
- Cut selected scenes (copy then remove from timeline).
- Paste clipboard scenes after the current selection/playhead area.
- Multi-scene clipboard support, preserving scene settings and embedded image/overlay data via JSON cloning.
- New pasted scenes receive fresh IDs.
- Clipboard scene count shown in the timeline controls.
- Timeline, scene editor, preview, counter, and autosave refreshed after cut/paste.

Notes: transient video element/object URL references are excluded from clipboard cloning; video source files may need re-import after paste. This milestone is source/static-verified; APK build and phone runtime test have not been performed.

Version: 0.77 / versionCode 77.
