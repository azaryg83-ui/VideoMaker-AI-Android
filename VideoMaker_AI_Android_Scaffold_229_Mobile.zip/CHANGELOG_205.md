# Scaffold 205 — Chapter Coverage Audit

- Added scene coverage audit for chapter organization.
- Reports uncovered scene ranges and overlapping chapter ranges.
- Added automatic creation of chapters for uncovered scene ranges, with editable names and colors.
- Does not change scene order, duration, or existing chapter boundaries.
- VersionCode 162 / VersionName 1.63-chapter-coverage-audit.
