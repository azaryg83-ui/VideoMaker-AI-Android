# Milestone 192 — Multitrack preview integration

VersionCode: 148  
VersionName: 1.49-multitrack-preview

## Implemented
- Added a `Previzualizează multitrack` control on the multitrack card. It launches the draft preview when a draft is available.
- Draft preview reads saved multitrack data (`vm_multitrack_timeline_v191`) while playing and while seeking.
- Enabled image-track clips can overlay the preview timeline; image data/URL is resolved from clip source or linked scene image data.
- Enabled subtitle-track clips display their text while their time range is active.
- Voiceover track enabled/unmuted state controls whether the merged WAV voiceover starts with the draft preview.
- Multitrack preview status copy clarifies that music and SFX tracks remain metadata and are not played in this milestone.

## Validation
- Inline JavaScript syntax checks: 10/10 passed with Node `--check`.
- Static feature checks: passed (preview button, track read, image overlay, subtitle overlay, voiceover track gating, seek update, limitations text, version bump).
- ZIP integrity: checked after packaging.
- APK build: not performed.
- Device test: not performed.

## Limitations
- Music and sound-effect audio playback/mixing is not yet integrated.
- Voiceover track volume control is metadata; native merged-WAV player volume is not changed here.
- Image overlay uses URL/data-image or scene image references; arbitrary prompt text is not itself rendered as an image.
- Preview remains draft-level; no MP4 export is performed.
