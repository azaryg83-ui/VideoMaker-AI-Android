# Scaffold 131 – Favorite projects

Implemented in the project library:
- Toggle favorite/unfavorite per project; persists in the project index metadata.
- Favorite projects receive a star marker and favorite action label.
- Favorites are sorted before non-favorites while preserving the chosen secondary sort order.
- Toggle to show only favorites; works together with search and type filters.
- Filtering does not mutate/delete project data.

Version: 88 / 0.89-build-candidate.
Verification: source checker, JavaScript syntax check, ZIP integrity. APK not compiled/device-tested.
