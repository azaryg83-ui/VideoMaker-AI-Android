# Scaffold 122 — Recovery backups

- Version: 80 / `0.80-build-candidate`
- Added per-project recovery backup records in IndexedDB (`recovery-backup:<projectId>`).
- Retains the two newest backup snapshots per project.
- Creates periodic recovery snapshots every 60 seconds while a project is open.
- Attempts an additional snapshot when the web app becomes hidden or receives `pagehide`.
- On project open, offers recovery when a backup is newer than the project's saved record; accepting restores the project and the autosave copy.
- Project deletion removes recovery records; creating a new project clears its stale recovery record.

Validation: `scripts_m122_check.py` 10/10 PASS; inline JavaScript syntax checked with `node --check`; archive integrity checked. Android APK build/device test not performed in this environment. Lifecycle backup is best-effort; Android/browser may terminate before asynchronous writes finish.
