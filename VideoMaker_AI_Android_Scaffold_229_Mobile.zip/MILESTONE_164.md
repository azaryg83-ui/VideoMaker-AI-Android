# Milestone 164 — Navigare Back Android logic

## Implementat
- Back în Guided Wizard îl închide și revine la editor.
- Back dintr-un tab editor diferit de Proiect revine la tab-ul Proiect.
- Back din tab-ul Proiect revine la Home/Biblioteca de proiecte.
- Tab-ul activ este expus ca stare `window.activeVideoMakerTab` pentru verificare și integrare.
- Nu schimbă autosave sau conținutul proiectului.

## Limitări/testare
- Verificare statică și sintaxă JavaScript; nu testat pe dispozitiv.
- Nu este build APK.

Versiune: 1.22-navigation-back; versionCode 121.
