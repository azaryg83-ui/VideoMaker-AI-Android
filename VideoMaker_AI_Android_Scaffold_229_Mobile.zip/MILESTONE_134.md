# Scaffold 134 — Bulk project status update

Implemented:
- New library toolbar action: **Status pentru selectate**.
- Applies one chosen status (Draft, In progress, Ready, Archived) to all currently selected projects.
- Validates the choice; invalid input changes nothing.
- Refreshes the project library after saving.
- Version Code 91 / Version Name 0.92-build-candidate.

Validation: see scripts_m134_check.py. APK build/device testing not performed.
