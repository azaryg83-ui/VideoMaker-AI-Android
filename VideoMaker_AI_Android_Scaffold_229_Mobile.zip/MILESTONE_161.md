# Milestone 161 — Scene Continuity Lock

Added per-scene continuity controls in the scene editor:
- Optional continuity notes for location, period, palette, weather, wardrobe, props, architecture, etc.
- Continuity lock checkbox (enabled by default for scenes without a saved false value).
- Image-generation prompt now includes continuity instructions when lock is enabled.
- Video prompt generation also includes continuity instructions.
- Scene continuity settings are saved with scene/project data through the existing project serialization.
- Storyboard TXT export includes continuity state and notes.

This is prompt-level guidance only. It does not guarantee identical AI outputs and does not add a new AI engine.

Version: 1.19; versionCode: 118.
