# Milestone 103 — Animații pentru text overlay

- Added text overlay animation presets: no animation, fade-in, slide-up, subtle pulse.
- Animation is rendered over the selected scene using elapsed preview time.
- Animation choice is stored with each scene and persists in project JSON/autosave/recovery.
- This is an initial canvas animation set; keyframe-based custom motion and per-letter animation remain future work.
