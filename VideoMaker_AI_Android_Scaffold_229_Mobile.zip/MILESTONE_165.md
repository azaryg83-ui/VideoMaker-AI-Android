# Milestone 165 — Short Video Settings Persistence Repair

## Verified source change
- Added a runtime holder for Short Video project settings.
- Project serialization now stores `shortVideoSettings` together with project data.
- Imported JSON and local/autosave restoration paths restore the Short Video settings into runtime state.
- New Shorts/TikTok/Reels projects retain target duration, hook, CTA, vertical flag, and flow version 2.
- Project data schema version advanced to 8.

## Why
The prior source stored short-video configuration when a project was first created, but the shared project serialization/autosave path did not consistently include it. This could cause settings to be lost after reopening or autosave.

## Verification
- Static checks: 8/8 PASS.
- JavaScript syntax: 4/4 scripts PASS.
- ZIP integrity: to be verified after packaging.
- Android APK build/device test: not performed.

## Android update
- versionCode: 122
- versionName: 1.23-short-video-persistence
