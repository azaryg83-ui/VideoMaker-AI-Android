#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
workflow=(ROOT/'.github/workflows/android-build.yml').read_text(encoding='utf-8')
checks=[]
def check(name, condition):
    checks.append((name, bool(condition)))
check('least-privilege contents read permission', re.search(r'permissions:\s*\n\s*contents:\s*read', workflow) is not None)
check('build concurrency group with cancellation', 'group: android-build-${{ github.ref }}' in workflow and 'cancel-in-progress: true' in workflow)
check('workflow manual dispatch present', 'workflow_dispatch:' in workflow)
check('runtime opt-in input present', 'link_sd_cpp_runtime' in workflow and 'default: false' in workflow)
check('standard build branch present', 'gradle --no-daemon --stacktrace --warning-mode all :app:assembleDebug' in workflow)
check('AI runtime build branch present', '-PvideomakerLinkSdcpp=true :app:assembleDebug' in workflow)
check('diagnostics uploaded even after failure', 'if: always()' in workflow and 'videomaker-ai-build-diagnostics' in workflow)
check('APK verification step exists', 'scripts/verify_apk.sh' in workflow)
check('manifest and checksums created', 'scripts/create_build_manifest.sh' in workflow and 'SHA256SUMS.txt' in (ROOT/'scripts/create_build_manifest.sh').read_text(encoding='utf-8'))
version=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
check('current version 0.60 candidate for milestone 101', 'versionCode = 64' in version and 'versionName = \"0.64-build-candidate\"' in version)
failed=[name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL')+': '+name)
print(f'MILESTONE_91_CHECKS: {len(checks)-len(failed)}/{len(checks)} passed')
sys.exit(1 if failed else 0)
