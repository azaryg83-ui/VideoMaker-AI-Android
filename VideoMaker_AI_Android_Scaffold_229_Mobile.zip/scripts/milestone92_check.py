#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text(encoding='utf-8')
checks={
 'home dashboard starts app flow':'id="homeScreen"' in html and 'showHome();' in html,
 'continue saved project action':'id="homeContinue"' in html and "$('restoreLocal').click()" in html,
 'new project wizard':'id="newProjectWizard"' in html and 'id="startNewProject"' in html,
 'six project types':'data-type="documentary"' in html and 'data-type="youtube"' in html and 'data-type="shorts"' in html and 'data-type="tiktok"' in html and 'data-type="reels"' in html and 'data-type="custom"' in html,
 'three modes':'data-mode="auto"' in html and 'data-mode="guided"' in html and 'data-mode="pro"' in html,
 'aspect ratio assigned for vertical formats':"selectedType==='shorts'||selectedType==='tiktok'||selectedType==='reels'" in html and "?'9:16'" in html,
 'project metadata included in JSON':'projectType:currentProjectType,projectMode:currentProjectMode' in html,
 'project metadata restored from import/autosave':'currentProjectType=p.projectType||\'documentary\'' in html and 'currentProjectMode=p.projectMode||\'auto\'' in html,
 'editor home button':'id="editorHome"' in html and "$('editorHome').onclick=showHome" in html,
 'warning before autosave overwrite':'Un proiect nou va înlocui salvarea automată curentă' in html,
 'candidate version 59':'versionCode = 59' in gradle and '0.59-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'MILESTONE_92_CHECKS: {sum(checks.values())}/{len(checks)} passed')
if not all(checks.values()): raise SystemExit(1)
