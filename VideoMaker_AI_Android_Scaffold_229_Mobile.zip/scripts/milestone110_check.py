from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
'Web Audio preview context':'previewMixContext' in html and 'startPreviewMixAt' in html,
'Preview schedules voiceover':'label:\'voice\'' in html or 'label:\"voice\"' in html,
'Preview schedules music':'label:\'music\'' in html or 'label:\"music\"' in html,
'Preview schedules SFX':'label:\'sfx\'' in html or 'label:\"sfx\"' in html,
'Audio preview uses timeline seek':'startPreviewMixAt(sceneStart(cur)+elapsed)' in html,
'Pause stops preview sources':'stopPreviewMix()' in html,
'Playhead seek stops prior preview':'function seekToTime(time){playing=false;cancelAnimationFrame(anim);stopPreviewMix()' in html,
'Build version 68':'versionCode = 68' in gradle and '0.68-build-candidate' in gradle,
}
for name,ok in checks.items():print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
