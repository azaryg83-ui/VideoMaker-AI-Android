from pathlib import Path
p=Path(__file__).resolve().parents[1]
h=(p/'app/src/main/assets/web/index.html').read_text()
g=(p/'app/build.gradle.kts').read_text()
checks={
 'left trim handle exists':'scene-trim-handle left' in h,
 'right trim handle exists':'scene-trim-handle right' in h,
 'pointer-driven handle interaction':'handle.onpointerdown' in h and 'handle.onpointermove' in h and 'handle.onpointerup' in h,
 'right trim adjusts duration':'origDur+delta' in h,
 'video trim-start adjusted':'s.videoTrimStart=+next.toFixed(2)' in h,
 'trim completion refreshes scene/timeline':'renderTimeline();renderScenes();draw();updateCounter();scheduleAutosave()' in h,
 'version bumped to 75':'versionCode = 75' in g and '0.75-build-candidate' in g,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
