from pathlib import Path
s=Path('app/src/main/assets/web/index.html').read_text()
g=Path('app/build.gradle.kts').read_text()
checks={
 'pointer drag handler attached': 'attachAudioClipDrag(clip' in s,
 'touch pointerdown capture': 'clip.onpointerdown' in s and 'setPointerCapture' in s,
 'pointer move updates visual position': 'clip.onpointermove' in s and 'clip.style.left=(next*8)' in s,
 'pointer release persists start': 'musicTrackSettings.start=next' in s and 'sfxTrackSettings[index].start=next' in s,
 'nonnegative and project bound': 'Math.max(0,Math.min(limit,origin+delta))' in s,
 'autosave after move': 'scheduleAutosave();setStatus(\'Clip audio mutat' in s,
 'version 72': 'versionCode = 72' in g and '0.72-build-candidate' in g,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
