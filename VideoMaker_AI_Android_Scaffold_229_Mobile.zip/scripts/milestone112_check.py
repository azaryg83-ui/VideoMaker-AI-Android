from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'Audio lanes use shared timeline width':'timelineWidth=Math.max(320,total*8)' in html,
 'Voiceover clip proportional duration':'className=\'timeline-audio-clip\'' in html and 'Math.min(total,dur)*8' in html,
 'Music clip positioned by start':'className=\'timeline-audio-clip music\'' in html and 'startPos*8' in html,
 'SFX clips positioned by start':'className=\'timeline-audio-clip sfx\'' in html,
 'Audio clip styling':'timeline-audio-clip' in html and 'timeline-audio-lane' in html,
 'Build version 70':'versionCode = 70' in gradle and '0.70-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
