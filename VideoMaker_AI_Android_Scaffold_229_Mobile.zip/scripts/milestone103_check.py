from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'Overlay animation control present':'id="overlayAnimation"' in html,
 'Fade animation uses elapsed time':"animation==='fade'?animProgress" in html,
 'Slide-up animation implemented':"animation==='slide-up'" in html,
 'Pulse animation implemented':"animation==='pulse'" in html,
 'Animation saved in scene project data':'overlayAnimation:s.overlayAnimation||"none"' in html,
 'Build version 63':'versionCode = 64' in gradle and '0.64-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} milestone 103 checks passed')
if not all(checks.values()): raise SystemExit(1)
