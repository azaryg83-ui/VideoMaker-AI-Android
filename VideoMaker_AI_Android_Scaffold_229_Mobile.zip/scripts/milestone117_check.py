from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text()
checks={
'zoom slider 4-32': 'min="4" max="32" step="1" value="8"' in html,
'zoom plus/minus controls': 'timelineZoomOut' in html and 'timelineZoomIn' in html,
'reset zoom': 'timelineZoomReset' in html,
'center playhead button': 'timelineCenterPlayhead' in html and 'centerTimelineOnPlayhead' in html,
'ruler uses zoom scale': 'let scale=timelineZoom,width=Math.max(320,total*scale)' in html,
'scene track width scales': "track.style.width=Math.max(320,total*timelineZoom)+'px'" in html,
'audio lanes scale': 'total*timelineZoom' in html,
'audio drag uses zoom conversion': '(e.clientX-startX)/timelineZoom' in html,
'playhead marker uses zoom': '(now*timelineZoom)' in html,
'build version 75': 'versionCode = 75' in (root/'app/build.gradle.kts').read_text() and '0.75-build-candidate' in (root/'app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} passed')
if not all(checks.values()): raise SystemExit(1)
