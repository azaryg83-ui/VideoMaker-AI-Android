from pathlib import Path
p=Path(__file__).resolve().parents[1]/'app/src/main/assets/web/index.html'
s=p.read_text()
checks={
'copy cut paste buttons': all(x in s for x in ['timelineCopySelected','timelineCutSelected','timelinePasteScenes']),
'clipboard state': 'var sceneClipboard=[]' in s,
'scene deep-copy helper': 'function cloneSceneForClipboard(sc)' in s,
'copy operation': 'function copyTimelineSelection(cut)' in s,
'cut removes selected scenes': 'inds.slice().reverse().forEach(function(i){scenes.splice(i,1)})' in s,
'paste operation': 'function pasteTimelineScenes()' in s,
'paste inserts after current selection': 'Math.max.apply(null,Array.from(selectedTimelineScenes))+1' in s,
'paste refreshes and autosaves': 'renderScenes();draw();updateCounter();renderTimeline();scheduleAutosave();setStatus(clones.length+\' scene lipite după selecția curentă.\')' in s,
'clipboard info label': 'timelineClipboardInfo' in s,
'version 77': 'versionCode = 77' in (Path(__file__).resolve().parents[1]/'app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
