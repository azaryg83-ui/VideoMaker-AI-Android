from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text()
checks={
 'duration control renderer present':'sceneDurationControls' in s,
 'duration range 1-30':'min=\\\"1\\\" max=\\\"30\\\"' in s or 'min="1" max="30"' in s,
 'duration step 0.1':'step=\\\"0.1\\\"' in s or 'step="0.1"' in s,
 'scene duration update handler':'data-scene-duration' in s and 'scenes[i].duration=' in s,
 'timeline refresh after change':'renderTimeline();scheduleAutosave()' in s,
 'version 71':'versionCode = 72' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
