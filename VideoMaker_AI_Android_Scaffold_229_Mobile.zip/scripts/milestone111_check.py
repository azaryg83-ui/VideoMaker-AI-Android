from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'Timeline ruler element':'id="timelineRuler"' in html,
 'Timeline ruler CSS':'timeline-ruler' in html and 'playhead-marker' in html,
 'Ruler tick labels':'tick.textContent=t+\'s\'' in html,
 'Ruler click seeks':'ruler.onclick=e=>' in html and 'seekToTime(t)' in html,
 'Playhead marker updates':'marker.style.left=' in html and 'sceneStart(cur)+elapsed' in html,
 'Build version 69':'versionCode = 69' in gradle and '0.69-build-candidate' in gradle,
}
for name,ok in checks.items():print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
