from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text(encoding='utf-8')
checks={
 'touch pointer handlers': 'b.onpointerdown' in s and 'b.onpointermove' in s and 'b.onpointerup' in s,
 'drag threshold': 'Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)' in s,
 'shared reorder helper': 'function reorderScene(from,to)' in s,
 'pointer target calculation': 'others=blocks.filter((x,j)=>j!==i)' in s and 'target=e.clientX>nearest.center' in s,
 'autosave after reorder': 'scheduleAutosave()' in s and 'function reorderScene(from,to)' in s,
 'desktop drag drop retained': 'b.ondragstart' in s and 'b.ondrop' in s,
 'version 75': 'versionCode = 75' in Path('app/build.gradle.kts').read_text() and '0.75-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' — '+k)
print(f'{sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
