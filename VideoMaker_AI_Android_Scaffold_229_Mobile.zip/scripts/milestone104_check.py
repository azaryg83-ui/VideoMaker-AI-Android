from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'Scene transition choices expanded':'wipe-left' in html and 'wipe-right' in html and 'dissolve' in html,
 'Wipe-left render branch':"transition==='wipe-left'" in html,
 'Wipe-right render branch':"transition==='wipe-right'" in html,
 'Fade/flash/dissolve render branch':"['fade','flash','dissolve'].includes(transition)" in html,
 'Storyboard transition options expanded':"['cut','fade','dissolve','wipe-left','wipe-right']" in html,
 'Build version 63':'versionCode = 64' in gradle and '0.64-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} milestone 104 checks passed')
if not all(checks.values()): raise SystemExit(1)
