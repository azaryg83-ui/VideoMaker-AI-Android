#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
workflow=(root/'.github/workflows/android-build.yml').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
script=(root/'scripts/collect_android_build_diagnostics.sh').read_text()
checks={
 'Android build log captured with tee': 'tee build-evidence/android-build.log' in workflow,
 'pipeline failure propagation enabled': 'set -o pipefail' in workflow,
 'diagnostics collected regardless of build outcome': 'Collect build diagnostics' in workflow and 'if: always()' in workflow,
 'diagnostic artifact uploaded': 'videomaker-ai-build-diagnostics' in workflow and 'build-evidence/diagnostics/' in workflow,
 'diagnostics include runtime pin and submodule state': 'submodule status --recursive' in script and 'SDCPP_RUNTIME_LOCK.txt' in script,
 'diagnostics capture native CMake cache': 'CMakeCache.txt' in script,
 'diagnostics capture Android tool versions': 'java -version' in script and 'gradle --version' in script and 'cmake --version' in script,
 'current build version updated for milestone 102': 'versionCode = 64' in gradle and '0.64-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
if not all(checks.values()): raise SystemExit(1)
