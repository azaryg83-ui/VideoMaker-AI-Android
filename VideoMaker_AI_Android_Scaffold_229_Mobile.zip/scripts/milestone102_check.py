from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'Sticker selector present':'id="sceneSticker"' in html,
 'Sticker drawn in canvas':'let sticker=String(s.sticker||' in html,
 'PIP image import present':'id="overlayImageFile"' in html,
 'PIP overlay drawn':'if(s.overlayImg&&s.overlayImg.complete' in html,
 'PIP/sticker settings serialized':'overlayImageData:s.overlayImageData||null' in html and 'sticker:s.sticker||""' in html,
 'Imported PIP restored from project':'scenes[i].overlayImageData' in html,
 'Build version 63':'versionCode = 64' in gradle and '0.64-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} milestone 102 checks passed')
if not all(checks.values()): raise SystemExit(1)
