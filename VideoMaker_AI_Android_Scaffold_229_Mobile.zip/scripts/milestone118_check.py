from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text()
checks={
 'toolbar select all': 'timelineSelectAll' in s,
 'toolbar deselect': 'timelineClearSelection' in s,
 'group duplicate control': 'timelineDuplicateSelected' in s,
 'group delete control': 'timelineDeleteSelected' in s,
 'group move left/right controls': 'timelineMoveSelectedLeft' in s and 'timelineMoveSelectedRight' in s,
 'modifier-click selection': 'e.ctrlKey||e.metaKey' in s,
 'selection Set state': 'selectedTimelineScenes=new Set()' in s,
 'duplicate function': 'function duplicateTimelineSelection()' in s,
 'delete group function': 'function deleteTimelineSelection()' in s,
 'move group function': 'function moveTimelineSelection(dir)' in s,
 'autosave wired': 'scheduleAutosave()' in s,
 'version 76': 'versionCode = 76' in Path('app/build.gradle.kts').read_text() and '0.76-build-candidate' in Path('app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
if not all(checks.values()): raise SystemExit(1)
