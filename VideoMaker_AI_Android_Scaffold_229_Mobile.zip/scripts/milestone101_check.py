from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'Cosmetizare nav tab exists':'data-tab="cosmetics"' in html,
 '8 mobile tab identifiers configured':"const tabs=['project','script','scenes','edit','cosmetics','images','captions','ai']" in html,
 'Cosmetization panel exists':'id="cosmeticsPanel"' in html,
 'Overlay text is drawn on canvas':"let overlay=String(s.overlayText||'').trim()" in html,
 'Scene filter applies to draw pipeline':"ctx.filter=s.filter||'none'" in html,
 'Cosmetization settings serialized':'overlayText:s.overlayText||""' in html and 'filter:s.filter||"none"' in html,
 'Apply/reset/preview controls wired':"$('applyCosmetics').onclick=applyCosmetics" in html and "$('resetCosmetics').onclick=resetCosmetics" in html,
 'Build version 63':'versionCode = 64' in gradle and '0.64-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} milestone 101 checks passed')
if not all(checks.values()): raise SystemExit(1)
