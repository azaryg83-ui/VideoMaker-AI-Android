from pathlib import Path
s=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
checks={
 'Timeline duration editable with tenths':'data-dur="${i}" type="number" min="0.1" step="0.1"' in s,
 'Video source trim-in control':'data-vtrimstart="${i}"' in s,
 'Video source trim-out control':'data-vtrimend="${i}"' in s,
 'Trim-in updates scene source range':'sc.videoTrimStart=Math.min(max,Math.max(0,Number(el.value)||0))' in s,
 'Trim-out updates scene source range':'sc.videoTrimEnd=val===0?0:Math.min(max,Math.max(sc.videoTrimStart||0,val))' in s,
 'Trim values persist in project object':'videoTrimStart:Number(s.videoTrimStart)||0,videoTrimEnd:Number(s.videoTrimEnd)||0' in s,
 'Preview respects selected video trim range':'srcStart+(elapsed%srcSpan)' in s,
 'Realtime export respects selected video trim range':'srcStart+(elapsed%srcSpan)' in s,
 'Timeline tooltip displays source trim':'s.videoTrimStart' in s and 's.videoTrimEnd' in s,
 'Build version incremented to 68':'versionCode = 68' in Path('app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
