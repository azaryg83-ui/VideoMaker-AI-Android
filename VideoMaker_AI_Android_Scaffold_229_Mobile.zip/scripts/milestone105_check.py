from pathlib import Path
p=Path('app/src/main/assets/web/index.html')
s=p.read_text(encoding='utf-8')
checks={
 'music import control':'id="musicFile"' in s,
 'multiple SFX import control':'id="sfxFiles"' in s and 'multiple' in s[s.find('id="sfxFiles"')-80:s.find('id="sfxFiles"')+80],
 'separate voice/music/SFX volumes':all(f'id="{x}"' in s for x in ['voiceVolume','musicVolume','sfxVolume']),
 'fade in and fade out controls':all(f'id="{x}"' in s for x in ['audioFadeIn','audioFadeOut']),
 'remove music and SFX controls':all(f'id="{x}"' in s for x in ['clearMusic','clearSfx']),
 'mix tracks into export':"mixTracks.push({file:uploadedMusic" in s and "uploadedSfx.forEach" in s,
 'audio gain applied':"gain=audioCtx.createGain()" in s and "gain.gain.value=tr.volume" in s,
 'audio fade automation':"linearRampToValueAtTime" in s,
 'audio assets persisted in project':all(x in s for x in ['musicData','sfxData','audioMix']),
 'audio mix restored from saved project':'function restoreAudioMix(p)' in s,
 'build version bumped to 64':'versionCode = 64' in Path('app/build.gradle.kts').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
if not all(checks.values()): raise SystemExit(1)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
