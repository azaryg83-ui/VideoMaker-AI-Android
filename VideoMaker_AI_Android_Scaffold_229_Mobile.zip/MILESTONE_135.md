# Scaffold 135 — Bulk favorites

Implemented:
- New library action **Favorite pentru selectate**.
- When any selected project is not a favorite, action marks all selected as favorites; when all selected are favorites, action removes favorite from all.
- Saves favorite metadata in project index and refreshes library.
- Requires selection; otherwise reports a clear message without changing anything.
- Version Code 92 / Version Name 0.93-build-candidate.

Validation: checker and JavaScript syntax checks run for this milestone. APK build/device testing not performed.
