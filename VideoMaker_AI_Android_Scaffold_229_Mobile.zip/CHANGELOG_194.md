# Scaffold 194 — Audio preview integration

Added a music/SFX preview toggle in the montage draft player. Imported music and sound effects are decoded locally and scheduled according to track position, trims, volume and fade parameters. Music loops within the draft preview; SFX play at their assigned timeline positions. Preview controls are connected to pause, resume, seek and stop. This is approximate synchronization in WebView.
