# Milestone 120 — Undo / Redo pentru timeline

- Added Undo and Redo controls in the timeline toolbar.
- Keeps up to 40 scene-history snapshots, including scene order, durations, trim values, visual/audio-related scene metadata, current scene, selection and playhead elapsed state.
- Snapshots preserve image object references by shallow-cloning scene objects (avoids JSON serialization losing image/video element references).
- History is recorded before timeline reorder, scene trim, scene-duration changes, group duplicate/delete/move, cut/paste and cosmetic apply/reset.
- Restoring a snapshot refreshes scene list, preview, counter, timeline, cosmetics controls and autosave.
- Corrected trim-handle delta conversion to use current timeline zoom, not fixed 8 px/s.
- Version 0.78 / versionCode 78.
- Static checks only; Android APK not built/tested in this environment.
