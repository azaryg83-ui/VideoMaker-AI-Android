# Milestone 98 — Manual Ghidat

Implemented a guided workflow panel for projects created in Manual Ghidat mode.

- 7 steps: project settings; script/voiceover; scenes/storyboard; characters/images; subtitles; montage/preview; export.
- Step counter and contextual instructions.
- Previous/Next navigation changes editor tab to the relevant section.
- Final step closes the guide; a skip/close action lets users access the editor directly.
- Guide starts when a new Guided-mode project is created. Other modes do not show it.

Validation: inline JavaScript syntax checked with Node; archive integrity checked. Android Gradle build not run in this milestone.
