# Scaffold 151 — Visual Prompt Pack

Added two batch actions to the Visual Material Queue: copy all scene image/video prompts in a readable scene-by-scene block, and export a structured JSON prompt pack. The JSON pack includes project/style/negative prompt, scene narration, duration, image/video prompt, frame/motion hints, character IDs/variants, asset-presence flags, and a clear notice that exporting the pack does not generate media.

VersionCode 108 / VersionName 1.09-visual-prompt-pack.
