# Milestone 175 — Merge saved WAV voice segments

- Added native WAV parser that reads RIFF chunks and extracts format/data chunks.
- Added ordered merge for saved segment IDs into `voice_segments/merged_voiceover.wav`.
- Merge validates PCM format and matching channel/sample-rate/bit-depth/format chunk before concatenating audio payloads.
- Added UI action to merge currently saved segments in script order and export the merged WAV to Downloads/VideoMakerAI.
- Added native export bridge for merged WAV.
- Android versionCode 132, versionName 1.33-merged-voiceover-wav.

## Verification
- Static native bridge/UI wiring checks: PASS (performed in packaging script).
- JavaScript syntax: checked with Node for extracted inline scripts.
- WAV merge algorithm: test fixture verification performed in packaging script (PCM payload order and header sizes).
- ZIP integrity: checked after packaging.
- APK build: not performed (Android SDK/build environment not verified).
- Device test: not performed.
