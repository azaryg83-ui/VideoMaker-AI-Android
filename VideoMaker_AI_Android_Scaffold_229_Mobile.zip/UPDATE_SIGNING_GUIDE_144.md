# Stable APK update signing — Scaffold 144

## Important status

The current CI workflow may produce APKs signed with a runner-generated Android debug key. That key is not guaranteed to remain the same between builds. A new stable keystore is needed for dependable in-place APK updates.

## One-time GitHub Actions secrets

Create four repository secrets under Settings → Secrets and variables → Actions:

- `VIDEOMAKER_KEYSTORE_BASE64` — Base64 text of a private `.jks` keystore
- `VIDEOMAKER_KEYSTORE_PASSWORD` — keystore password
- `VIDEOMAKER_KEY_ALIAS` — alias of the signing key
- `VIDEOMAKER_KEY_PASSWORD` — key password

The workflow checks for all four secrets and uses the keystore only when all are supplied. Otherwise it falls back to runner debug signing and warns that the APK is not update-stable. The keystore and passwords must never be committed to the repository.

## Existing installation transition

Because earlier APKs may have been signed by temporary CI keys, the first installation using the newly created stable key may require uninstalling the current app once. This can erase local app data; back up/export projects first. After that one-time transition, builds using the same keystore, package name, and increasing versionCode should install as updates.

## Scaffold 144 status

This scaffold adds the signing configuration and workflow support but does not generate or store a private keystore. GitHub secrets must be configured by the repository owner. APK build/device installation has not been performed in this scaffold.
