# Milestone 173 — Local TTS WAV generation and app-private save

- Added native Android TextToSpeech `synthesizeToFile` bridge for voice segments.
- Added per-segment button to generate and save a WAV file.
- WAV files are stored in app-private `files/voice_segments/` and named by segment index.
- Added synthesis completion/error callbacks to the WebView and segment status display.
- Added native lookup for saved segment path; JSON export includes segment status/path metadata when available.
- Language support remains dependent on the Android TTS engine and installed voices.

## Verification status
- Source-level targeted checks: 7/7 PASS
- JavaScript syntax: 4/4 inline scripts PASS (Node check)
- ZIP integrity: pending (checked after packaging)
- Android APK build: not performed in this environment
- Device test: not performed
