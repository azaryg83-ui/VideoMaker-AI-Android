# Scaffold 160 — Scene composition and lighting controls

- Added per-scene composition/camera-angle selector: documentary eye-level, low angle, high angle, top-down, subtle Dutch tilt, macro, and symmetrical composition.
- Added per-scene lighting/atmosphere selector: soft daylight, chiaroscuro, golden hour, moonlight, diffuse overcast, torch/fire, low-key, and bright studio.
- Settings persist as scene fields through the existing project serialization/autosave paths.
- AI image prompt assembly now appends the scene frame type, composition, and lighting modifiers; old projects use safe defaults.
- Video prompt generation includes composition and lighting text.
- These are prompt controls only; no live video generation integration was added.
- Version: 1.18, versionCode 117.
- APK not compiled; not device-tested.
