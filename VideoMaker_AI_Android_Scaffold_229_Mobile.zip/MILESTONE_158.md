# Scaffold 158 — AI generation profiles

- Added built-in Economy, Balanced, and Quality generation profiles (steps + sampler).
- Added save/delete for custom local profiles, including endpoint, steps, and sampler.
- Profiles are stored in localStorage and the selected profile is remembered locally.
- Applying a profile updates the AI connector settings; it does not connect to or generate on an AI server by itself.
- Version: 1.16, versionCode 115.
- Validation: source checks, inline JavaScript syntax, and ZIP integrity checked.
- Not compiled as APK; not tested on device or against live AI server.
