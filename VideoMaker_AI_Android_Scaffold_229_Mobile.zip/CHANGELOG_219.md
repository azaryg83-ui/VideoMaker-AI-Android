# Scaffold 219 — Native render memory hardening & audit checkpoint

- Replaced full-resolution image validation decode with bounds-only image validation to avoid unnecessary bitmap allocation during preflight.
- Added sampled image decoding for render based on target output dimensions, reducing peak memory use for oversized source images.
- Kept per-scene bitmap lifecycle scoped and recycled after frame generation.
- This checkpoint does not expand render capability: MP4 remains image-scene-only, silent, and bounded to 60 seconds / 30 FPS / approximately 720p.
- Static JavaScript syntax checks and ZIP integrity checks performed. Android Gradle compilation and device/encoder tests are still unavailable in this environment.
- VersionCode 176 / VersionName 1.77-native-render-memory-hardening.
