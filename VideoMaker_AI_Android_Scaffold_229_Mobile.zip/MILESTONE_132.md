# Scaffold 132 – Project tags

Implemented in project library:
- User-defined tags per project (up to 8; each capped at 24 characters).
- Tag editing from each project card.
- Search matches project name or tag text.
- Dynamic tag filter in the library, combined with type/favorite/search filters.
- Bulk assignment of tags to selected projects.
- Duplicate project copies its library tags.
- Tags are stored in library index metadata; filtering/editing does not alter project content.

Version: 89 / 0.90-build-candidate.
Verification: source checker, JavaScript syntax check, ZIP integrity. APK not compiled/device-tested.
