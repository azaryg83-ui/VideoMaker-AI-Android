# Milestone 183 — Editable montage draft

Added a draft montage builder to the editor based on existing scenes and storyboard montage links.

- Builds an editable draft entry per scene, carrying storyboard link timing/transition/duration when present.
- Editable per entry: draft duration, transition type, media type, visual description/source note, caption.
- Preview summary reports draft frame count and estimated runtime.
- Explicit confirmation stores draft metadata (`montageDraft`) on scenes and autosaves the project.
- JSON export of the draft.
- Draft confirmation does not reorder scenes or change original scene durations.

Version: `versionCode 140`, `versionName 1.41-editable-montage-draft`.

Validation: source/static and JavaScript syntax checks only; Android APK build and device testing were not performed.
