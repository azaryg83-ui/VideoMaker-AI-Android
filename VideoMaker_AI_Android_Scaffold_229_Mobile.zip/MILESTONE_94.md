# Milestone 94 — Navigare Android Back

- JS exposed `window.handleAppBack()` for app-level navigation.
- Back from new-project wizard closes the wizard and returns to Home.
- Back from editor returns to Home rather than exiting immediately.
- Back from Home exits Activity using Android's default behavior.
- Kotlin `onBackPressed` routes system Back and Android Back gesture to the JS handler, then exits only if JS reports no screen handled it.

Checks: JS syntax and source-level checks passed. Android Gradle build is not run in this environment; validate via GitHub Actions.
