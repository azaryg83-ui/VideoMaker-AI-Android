# Scaffold 127 – Backup integrity check

## Implemented
- Per-project JSON backup export now includes integrity metadata (`fnv1a32` checksum).
- Import verifies checksum when the metadata is present.
- If checksum mismatch or missing checksum is detected in a tagged integrity block, import is blocked with a clear error instead of importing a potentially damaged file.
- Legacy JSON backups without integrity metadata remain importable.
- Existing import preview, project-new-ID behavior, media serialization, and recovery-backup behavior are retained.

## Validation
- `scripts_m127_check.py`: 10/10 PASS.
- Inline JavaScript syntax check via Node: PASS (4 scripts extracted).
- ZIP integrity: to be verified after archive creation.

## Version
- `versionCode = 84`
- `versionName = 0.85-build-candidate`

## Limits
- FNV-1a is a corruption-detection checksum, not cryptographic authentication. It helps detect accidental changes/corruption, not malicious tampering.
- APK build and device test were not performed in this environment.
