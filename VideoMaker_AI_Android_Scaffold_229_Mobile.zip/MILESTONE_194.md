# Scaffold 194 — Draft Music/SFX Synchronized Preview

- VersionCode: 150
- VersionName: 1.51-draft-music-sfx-sync-preview
- Builds on Scaffold 193.

## Added
- Draft preview toggle for music and sound effects, independent of voiceover toggle.
- Web Audio decoding/cache for imported music and SFX files.
- Timeline-aware scheduling using each track's start, trim, volume, fade-in and fade-out settings.
- Music loops across the draft preview duration when its trimmed segment is shorter than the draft.
- SFX are scheduled at their timeline positions and play once.
- Preview music/SFX pause/resume, stop and seek rescheduling are connected to the draft preview controls.
- Audio nodes are stopped and cleaned on preview stop/pagehide.

## Verification
- JavaScript syntax: all 10 embedded scripts checked with Node `--check`.
- Static source assertions: toggle, schedule, pause/resume, seek, stop/cleanup and version checks.
- ZIP integrity check.
- APK build and on-device test were not performed.

## Limitations
- Browser/WebView audio scheduling and synchronization are approximate, not frame-perfect.
- This is preview playback; final export mix remains handled by the existing export path.
- Imported audio preview may depend on Android WebView's Web Audio support and device performance.
