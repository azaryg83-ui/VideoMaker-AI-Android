# Milestone 121 — Persist Undo/Redo history

- Undo/Redo stacks now persist in IndexedDB per project (`timeline-history:<projectId>`).
- Persistence is debounced and limited to the existing 40-entry history cap.
- History snapshots serialize scene media data when available and hydrate image/video/overlay references when restored after reopening.
- Loading a project resets in-memory history first and loads that project's stored history; new projects clear their history record; deleting a project deletes its history record.
- Undo/Redo refresh controls and status, then autosave the restored project state.
- Version 0.79 / versionCode 79.
- Static tests and JavaScript syntax check; APK not built.
