# Milestone 124 — Import JSON backups into Project Library

- Added a Home dashboard control to import a previously exported project JSON directly into the local project library.
- Import is non-destructive: it creates a new project ID and adds an `(importat)` suffix instead of overwriting existing projects.
- Validates the JSON shape (`name` and `scenes` array), stores it in IndexedDB, updates project index, and refreshes the dashboard.
- File picker accepts JSON; selected input is reset after use to allow re-importing the same file.
- Version: 0.82 build candidate (versionCode 81).
- APK/device testing not performed.
