
(function organizeEditorModules(){
 const main=document.getElementById('editorMain');if(!main)return;
 const cards=[...main.querySelectorAll('section.card')];
 cards.forEach((card,index)=>{const h=card.querySelector(':scope > h2');if(!h||card.dataset.moduleOrganized)return;card.dataset.moduleOrganized='1';card.classList.add('module-organized');
  const heading=document.createElement('button');heading.type='button';heading.className='module-card-heading';heading.setAttribute('aria-expanded','true');
  const chevron=document.createElement('span');chevron.className='module-chevron';chevron.textContent='⌄';chevron.setAttribute('aria-hidden','true');
  heading.appendChild(h);heading.appendChild(chevron);card.insertBefore(heading,card.firstChild);
  const content=document.createElement('div');content.className='module-card-content';content.dataset.moduleContent='';
  let node=heading.nextSibling;while(node){const next=node.nextSibling;content.appendChild(node);node=next;}
  card.appendChild(content);
  heading.addEventListener('click',()=>{const collapsed=content.classList.toggle('module-collapsed');heading.setAttribute('aria-expanded',String(!collapsed));chevron.textContent=collapsed?'›':'⌄';});
 });
 const expand=document.getElementById('expandModules'),collapse=document.getElementById('collapseModules');
 function setAll(collapsed){main.querySelectorAll('.module-card-content').forEach(c=>c.classList.toggle('module-collapsed',collapsed));main.querySelectorAll('.module-card-heading').forEach(h=>{h.setAttribute('aria-expanded',String(!collapsed));const ch=h.querySelector('.module-chevron');if(ch)ch.textContent=collapsed?'›':'⌄';});}
 if(expand)expand.addEventListener('click',()=>setAll(false));if(collapse)collapse.addEventListener('click',()=>setAll(true));
})();
