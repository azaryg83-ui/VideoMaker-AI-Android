# Scaffold 217 — Portable Render Package & Prepared Job Queue

- Added portable render-package generation from the current Export Studio render plan.
- Packages include the render plan, local project-state snapshot (`vm_`/`videomaker*` localStorage keys), and binary media assets referenced by the plan encoded as Data URLs.
- Added persistent prepared-job queue with summary metadata, package export, per-job removal, and queue export/clear.
- Added package import validation and media restoration into IndexedDB. Imported project-state snapshot is retained inside the package but does not overwrite the active project.
- Jobs are explicitly marked PREPARED / NOT RENDERED; no MP4 engine or video encoding is connected.
- VersionCode 174 / VersionName 1.75-portable-render-package-queue.
- Static JS syntax and ZIP integrity checks performed. APK/device testing not performed.
