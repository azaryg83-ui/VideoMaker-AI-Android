# Milestone 93 — Proiecte independente

## Implementat în sursă
- Dashboard „Proiectele mele” pe Home.
- Proiectele sunt salvate separat în IndexedDB după projectId, cu salvare automată compatibilă (`autosave`).
- Creare proiect nou fără avertisment de suprascriere a proiectului anterior.
- Deschidere proiect din listă.
- Redenumire proiect și sincronizarea numelui în salvare.
- Duplicare proiect (copie a datelor de proiect salvate).
- Ștergere proiect cu confirmare.
- Metadata listă: tip, mod, dată actualizare.
- Compatibilitate/migrare de bază pentru salvarea autosave veche.

## Verificări
- ZIP sursă 92 deschis și integritatea arhivei verificată anterior.
- Toate cele 3 scripturi inline JavaScript: `node --check` trecut.
- Teste statice ale elementelor CRUD și stocării: trecute.

## Limitări / următoarele teste
- Build Android/GitHub Actions nu este executat aici.
- Test CRUD în runtime Android WebView trebuie verificat după build.
- Media inclusă în duplicate este copiată prin clonarea datelor serializate; testul de volum/memorie pe telefon rămâne.
