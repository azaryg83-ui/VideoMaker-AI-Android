# Scaffold 204 — 1.62 Chapter Timeline Integration
- Added chapter list actions: jump to chapter end, set chapter IN/OUT range, create chapter boundary markers.
- Chapter boundary markers are added to the existing marker storage and duplicate chapter markers at matching time/label are avoided.
- Chapter range selection writes to existing IN/OUT marker range storage.
- VersionCode 161; VersionName 1.62-chapter-timeline-integration.
