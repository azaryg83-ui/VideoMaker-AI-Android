# Scaffold 154 — Bulk status updates for filtered visual scenes

- Adds a bulk-status selector and action to the Visual Materials Queue.
- Applies selected status to only the currently filtered scene set (or all scenes when filter is All).
- Confirmation dialog previews the affected count; empty target set is handled.
- Updates queue display and schedules autosave.
- VersionCode: 111; VersionName: 1.12-visual-queue-bulk-status.
- This is project-management functionality only; it does not generate AI images/video.
