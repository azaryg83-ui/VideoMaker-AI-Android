# Scaffold 136 – Bulk clear project tags

Added a new library toolbar action to remove all tags from selected projects. It asks for confirmation, updates only project index tag metadata, saves the index, refreshes the library, and reports how many selected projects previously had tags.

Version Code 93; Version Name 0.94-build-candidate. APK not built or device-tested.
