# Milestone 174 — Saved WAV playback and Downloads export

- Added native playback of a saved per-segment WAV using MediaPlayer.
- Added native export of saved WAV segments to public Downloads/VideoMakerAI/VoiceSegments using MediaStore.
- Segment UI now shows saved-file playback and export controls, disabled until the segment reports saved.
- Stop control stops both local TTS preview and saved-file playback.
- Android versionCode 131, versionName 1.32-saved-wav-play-export.

## Verification
- Web JavaScript syntax: 4/4 scripts PASS (Node --check).
- Source checks: verify native playback/export bridge and UI control wiring.
- ZIP integrity: checked after packaging.
- APK build: not performed (Android build environment not verified).
- Device test: not performed.
