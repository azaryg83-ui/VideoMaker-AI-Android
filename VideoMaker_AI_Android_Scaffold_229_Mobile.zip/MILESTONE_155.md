# M7 — Editor / Montaj (în lucru)

## Scaffold 200 / actualizare 1.58
- Ripple insert: introduce timp la cursor și mută clipurile ulterioare pe toate pistele.
- Ripple remove: elimină interval temporal transversal, ajustează clipurile care îl intersectează și compactă materialul ulterior.
- Ripple delete pe pistă: elimină clipurile selectate de pe o singură pistă și compactează clipurile ulterioare.
- Operațiunile fac checkpoint pentru Undo și salvează local.

## Limite
Timeline-ul rămâne un editor de metadate/draft. Nu este încă un motor de randare MP4. APK și test fizic Android nu au fost realizate în acest scaffold.
