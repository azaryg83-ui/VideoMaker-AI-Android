# Scaffold 150 — Visual Material Queue

Added a scene-by-scene visual-material queue in the storyboard workflow. It reports whether each scene has a visual prompt, image, video clip, and character assignment; provides jump-to-scene and prompt-copy actions; and exports a TXT missing-assets report. It is a local project-review utility, not AI media generation.

VersionCode 107 / VersionName 1.08-visual-queue.
