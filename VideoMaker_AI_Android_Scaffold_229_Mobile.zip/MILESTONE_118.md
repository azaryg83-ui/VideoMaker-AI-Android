# Milestone 118 — Selecție multiplă și operații în grup pe timeline

- Selectarea scenelor individuale și Ctrl/Meta pentru adăugare/eliminare din selecție.
- Selectează toate / Deselectează.
- Duplică selecția în bloc, păstrând ordinea scenei și datele vizuale, fără referințe directe la elementele video DOM.
- Șterge selecția multiplă.
- Mută grupul selectat un pas la stânga/dreapta.
- Indicatorul de selecție și outline vizual pe blocuri selectate.
- Autosave după operațiile de grup.

Verificări statice și sintaxă JS; build APK Android nu este efectuat.
