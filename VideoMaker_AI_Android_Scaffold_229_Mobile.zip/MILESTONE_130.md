# Milestone 130 — Library project detail summaries

Project library cards now load saved project records and display scene count, character count, scenes with attached image data, and approximate total scene duration. The summary is read-only and does not modify project data. It gracefully displays an unavailable status if a project record cannot be loaded.

Version: 0.88 build-candidate (versionCode 87).

Validation: source checks, JS syntax checks, ZIP integrity. No APK/device build performed.
