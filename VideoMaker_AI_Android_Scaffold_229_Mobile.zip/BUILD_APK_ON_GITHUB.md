# Obținerea APK-ului Android (build real)

**Limitarea mediului curent:** în sesiunea de lucru nu există Android SDK/NDK sau Gradle instalate, iar DNS-ul nu poate rezolva domeniile externe (`services.gradle.org`, `dl.google.com`). De aceea, APK-ul nu poate fi compilat local aici.

Workflow-ul GitHub Actions este inclus în `.github/workflows/android-apk-build.yml`. Acesta rulează manual (Run workflow) și automat la push pe main/master.

## Pașii necesari o singură dată

1. Creează un repository GitHub nou (public sau privat), de exemplu `videomaker-ai-android`.
2. Încarcă toate fișierele din acest proiect în repository, păstrând structura.
3. Deschide tab-ul **Actions** și workflow-ul **Android APK build and native checks** (fișierul inclus în Scaffold 220).
4. Apasă **Run workflow** (workflow_dispatch).
5. Așteaptă jobul `assemble-debug`. Dacă trece, descarcă artifact-ul `videomaker-ai-debug-apk-and-evidence` din pagina run-ului.
6. Artifact-ul `videomaker-ai-debug-apk-and-evidence` conține `app-debug.apk`, `SHA256SUMS.txt` și `BUILD_INFO.txt`.

## Ce verifică build-ul

- frontend și contractul JavaScript–Kotlin;
- compilarea JNI pentru verificarea host;
- configurația workflow;
- Gradle 8.9, Java 17, Android SDK Platform 35, Build Tools 35.0.0, NDK 27.2.12479018 și CMake 3.22.1;
- `:app:assembleDebug`;
- structura APK și prezența bibliotecii `arm64-v8a/libvideomaker_native.so` și asset-urilor web.

**Important:** acest APK build candidate este shell/editor Android. Motorul `stable-diffusion.cpp` nu este încă integrat în build-ul standard, iar generarea AI locală nu este funcțională în acest APK.

## Instalare pe telefon

După descărcarea APK-ului, transferă-l pe Redmi Note 14 Pro, deschide fișierul APK și, dacă Android cere, permite temporar instalarea din sursa folosită. Instalează, apoi verifică lansarea, importul de fișiere și interfața. Nu se recomandă instalarea până când artifact-ul nu a trecut build-ul cloud.
