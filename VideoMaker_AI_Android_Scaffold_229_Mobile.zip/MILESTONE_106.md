# Milestone 106 — Subtitle Style System

Implemented in the web editor:
- Expanded font selector (system/browser fonts); custom TTF/OTF/WOFF import with FontFace loading for the current project/session.
- Presets: Cinematic, Documentary, Social/Impact, Karaoke, Minimalist, News.
- Text and background colors with native picker and HEX entry.
- Text size and position; background opacity.
- Outline toggle, color and thickness.
- Effects: none, shadow, glow, strong outline.
- Animations: none, fade-in, pop/zoom, slide-up, subtle pulse.
- Highlight color and modes (off/all; word cue mode is a setting placeholder, not word-by-word karaoke rendering yet).
- Subtitle style stored in project subtitleStyle and restored on project load/autosave.
- Preview canvas uses the selected style/effect/animation.

Validation: extracted inline JavaScript passed `node --check`; archive integrity tested. Android APK build and on-device rendering are not yet tested.
