# Milestone 108 — Audio timeline tracks, timing, trim and per-track mix

Implemented on Scaffold 107 source:
- Music track controls: timeline start offset, trim start/end, per-track volume, fade-in and fade-out.
- Every imported SFX track receives the same individual controls and can be removed independently.
- Timeline shows separate voiceover, music and SFX lanes with track names and timing metadata; visual offset is proportional (display-only).
- Project JSON/local autosave now stores music track settings and each SFX track's settings (version 7).
- Restore/import recreates track metadata and controls.
- Export WebM/MP4 audio scheduling uses start offsets, trim bounds, per-track gain and fades; duration calculation includes delayed tracks.
- Android build candidate bumped to versionCode 66 / versionName 0.66-build-candidate.

Validation:
- Inline JavaScript syntax checked with Node.js `node --check`: PASS.
- Static feature assertions for individual track controls, settings serialization/restoration, track removal, timeline lanes, and scheduled export: PASS.
- ZIP integrity: PASS.

Limitations:
- Timeline lane offsets are a visual approximation; audio tracks are positioned by numeric start-time controls, not drag-and-drop yet.
- Voiceover still starts at zero; voiceover trim/offset controls are not part of this milestone.
- No Android APK build or real-device export test performed.
