# Scaffold 196 — M7 Editor / Montaj

## Block: Multitrack clip operations
- Move clips up/down within a track (ordering operation).
- Duplicate clips, placing the duplicate immediately after the original by timeline start.
- Delete clips from a track.
- Align all clips on a chosen track sequentially without gaps, using each clip's duration.
- Existing start, duration, source, enabled controls remain.
- Local timeline save remains after each operation.

## Validation
- Static checks for UI controls/handlers and version bump.
- JavaScript syntax checks.
- ZIP integrity.
- Android APK build and Redmi Note 14 Pro runtime tests were not performed.

## Limitation
Move up/down changes clip order in the track's editable list; it does not automatically rewrite timeline start times. Use the sequential-align control if the user wants clips laid consecutively.
