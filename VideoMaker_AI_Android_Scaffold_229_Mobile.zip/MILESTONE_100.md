# Milestone 100 — Shared editor and mode switching

- Added shared editor mode panel for Auto Intelligent, Manual Guided, and Professional.
- Explicitly states all modes use the same project/editor, not separate editors.
- Mode switches update current project mode and active label; updates local project/autosave/index when project ID is available.
- Guided mode opens the step guide.
- Professional mode provides direct access to the module area; the dedicated advanced-tools button expands all modules and scrolls to module controls.

Validation: inline JavaScript syntax checked with Node; ZIP integrity checked. Android build not run.
