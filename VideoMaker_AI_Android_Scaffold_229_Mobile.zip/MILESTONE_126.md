# Scaffold 126 — Export backup proiect din bibliotecă

## Implementare
- Adăugat buton **Exportă backup JSON** pe fiecare card de proiect.
- Exportul citește proiectul salvat local din IndexedDB și descarcă un JSON cu structura completă disponibilă (inclusiv media încorporată, când aceasta este salvată în proiect).
- Exportul include metadatele `exportedAt` și `exportFormat` pentru identificarea backup-ului.
- Numele fișierului este sanitizat pentru utilizarea ca nume de fișier.
- Mesaj de status pentru succes și eșec.
- Versiune Android: versionCode 83, versionName 0.84-build-candidate.

## Limite
- JSON-ul poate deveni foarte mare dacă proiectul are multe media încorporate.
- Nu s-a compilat APK-ul și nu s-a testat pe dispozitiv în acest milestone.
