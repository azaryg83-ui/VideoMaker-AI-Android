
(function mobilePageNavigation(){

 const tabs=['project','script','scenes','edit','cosmetics','images','captions','ai'];
 const sectionMap={
  '1. Proiect și format':'project',
  '2. Scenariu / voiceover':'script',
  '3. Previzualizare cinematică':'edit',
  '✨ Cosmetizare video — scena selectată':'cosmetics',
  '👥 Personaje — identitate vizuală persistentă':'images',
  '4. Subtitrări':'captions',
  '5. Storyboard AI — pregătirea imaginilor':'scenes',
  '🎞️ 5A. Storyboard multi-cadru':'scenes',
  '6. Manager producție imagini':'images',
  '7. Profil dispozitiv — Redmi Note 14 Pro':'ai',
  '7. Motor AI pentru imagini — conectare la model local':'ai',
  '10. Generare AI nativă — conectare la storyboard':'ai',
  '9. Bibliotecă locală de modele — Android':'ai',
  '8. Plan automat de producție':'scenes',
  '🎬 56. Planificator cinematic de cadre':'scenes',
  '7. Scenele proiectului':'scenes'
 };
 const cards=[...document.querySelectorAll('main.wrap > section')];
 cards.forEach(card=>{const h=card.querySelector('h2');if(!h)return;const tab=sectionMap[h.textContent.trim()];if(tab){card.dataset.mobileTab=tab;card.classList.add('mobile-tab-card');}});
 const nav=document.getElementById('mobileNav');
 function activate(tab){cards.forEach(card=>{if(card.dataset.mobileTab)card.classList.toggle('page-hidden',card.dataset.mobileTab!==tab);});nav.querySelectorAll('button').forEach(b=>{const active=b.dataset.tab===tab;b.classList.toggle('active',active);b.setAttribute('aria-current',active?'page':'false');});try{sessionStorage.setItem('videomaker-mobile-tab',tab)}catch(e){}window.scrollTo({top:0,behavior:'instant'});}
 nav.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>activate(b.dataset.tab)));
 let start='project';try{const saved=sessionStorage.getItem('videomaker-mobile-tab');if(tabs.includes(saved))start=saved}catch(e){}
 activate(start);
 window.addEventListener('resize',()=>{try{dimensions();draw()}catch(e){}});
})();
