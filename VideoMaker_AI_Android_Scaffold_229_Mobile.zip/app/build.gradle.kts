plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.videomakerai.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.videomakerai.app"
        ndk { abiFilters += listOf("arm64-v8a") }
        minSdk = 28
        targetSdk = 35
        versionCode = 179
        versionName = "1.80-home-step-navigation"
    }

    // CI stable signing is optional until the user configures GitHub Actions secrets.
    // Without those secrets, debug APKs use the runner-generated debug key (not update-stable).
    val stableKeystorePath = System.getenv("VIDEOMAKER_STABLE_KEYSTORE")
    val stableKeystorePassword = System.getenv("VIDEOMAKER_STABLE_KEYSTORE_PASSWORD")
    val stableKeyAlias = System.getenv("VIDEOMAKER_STABLE_KEY_ALIAS")
    val stableKeyPassword = System.getenv("VIDEOMAKER_STABLE_KEY_PASSWORD")
    val hasStableSigning = !stableKeystorePath.isNullOrBlank() &&
        !stableKeystorePassword.isNullOrBlank() && !stableKeyAlias.isNullOrBlank() &&
        !stableKeyPassword.isNullOrBlank() && file(stableKeystorePath).exists()

    signingConfigs {
        if (hasStableSigning) {
            create("ciStable") {
                storeFile = file(stableKeystorePath!!)
                storePassword = stableKeystorePassword
                keyAlias = stableKeyAlias
                keyPassword = stableKeyPassword
            }
        }
    }
    buildTypes {
        getByName("debug") {
            if (hasStableSigning) signingConfig = signingConfigs.getByName("ciStable")
        }
    }

    // Lightweight bridge build: native runtime linking is disabled by default.
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
}
