# Milestone 162 — Continuity Assistant

Built from verified Scaffold 161 source.

## Changes
- Scene cards now offer **Copy continuity from previous scene** (disabled on scene 1).
- Copies continuity note and lock, plus camera composition, lighting, and frame type; it intentionally does not copy narration, scene prompt, media, or character assignment.
- Added a continuity audit button in the storyboard prompt controls.
- Audit reports lock-disabled scenes, later scenes with no explicit continuity note, and adjacent scenes with differing assigned characters (unless a variant is explicitly selected).
- Audit is field-based only and cannot verify generated image identity or visual matching.

Version: 1.20; versionCode: 119.
