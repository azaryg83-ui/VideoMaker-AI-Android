# Milestone 181 — Editable montage plan from accepted audio cut markers

- Builds an editable montage-plan list from accepted audio-cut markers (Milestone 180).
- Resolves each marker to an approximate scene and offset using current scene durations.
- Suggests cut type based on gap duration: hard cut, fade, or dissolve.
- Adds editable transition duration and recommended shot duration.
- Stores plan in localStorage and restores it on page reload.
- Exports JSON (`montage_plan.json`).
- Does not alter/reorder scenes or automatically apply transitions.

## Verification
- Static source checks and JS syntax checks are run in this package.
- APK build/device test not performed.
