# Milestone 116 — Trim vizual direct pe timeline

- Added draggable left/right trim handles to each scene block on the timeline.
- Right handle adjusts scene duration (1–30 seconds) and, for video-backed scenes, updates the source trim-end.
- Left handle adjusts duration for still-image scenes; for video-backed scenes it adjusts source trim-start and shortens the timeline duration while respecting a minimum source range.
- Pointer/touch interaction uses pointer events and stops propagation to avoid triggering scene-selection/reordering.
- On release, timeline and scene panels refresh, preview redraws, counter updates, and autosave is scheduled.
- App version: 0.74 build-candidate (versionCode 74).
- Verification: JavaScript syntax check passed; static milestone checker passed. Android build/device test not run.
