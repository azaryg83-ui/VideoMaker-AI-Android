# Milestone 115 — Touch drag reorder for video scenes

- Added pointer/touch drag interaction to scene blocks in the visual timeline.
- Horizontal drag threshold prevents accidental reordering from taps or vertical scrolling.
- Scene order is calculated from timeline block centers and updated through a shared reorder function.
- Existing desktop HTML drag-and-drop remains supported.
- Reordering updates current scene, preview, scene list, timeline and autosave.
- Android versionCode 73 / versionName 0.73-build-candidate.

## Validation
- Static checker: 7/7 PASS.
- JavaScript syntax check: PASS.
- ZIP integrity: PASS.
- Android build/device test: not performed.
