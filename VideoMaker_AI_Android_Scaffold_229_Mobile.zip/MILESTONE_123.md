# Scaffold 123 — Manual recovery backup and backup chooser

- Added **Creează backup acum** in the scene/project controls.
- Added **Restaurează backup**, showing the retained recovery generations with timestamps and reasons.
- Restore selection is validated and requires a confirmation before replacing the current project.
- Restoring updates the project record and autosave, then reloads the editor.
- Manual backup uses the existing per-project recovery store and retention policy (last two generations).
- Version: `81` / `0.81-build-candidate`.

Validation: `scripts_m123_check.py` — 10/10 PASS. JavaScript syntax and ZIP integrity are checked separately. APK build/device test not performed.
