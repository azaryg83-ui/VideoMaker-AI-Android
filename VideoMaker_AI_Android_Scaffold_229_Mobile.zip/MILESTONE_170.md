# Milestone 170 — Preserve mixed labeled/unlabeled voice lines

## Implemented
- Voice segment preparation now keeps every non-empty script line in original order.
- Explicit `Speaker: text` lines map to the matching cast profile when available.
- Unlabeled lines in mixed scripts are retained and assigned to Narrator rather than silently dropped.
- Narrator voice/tone defaults are used for unlabeled lines; unknown labeled speakers receive neutral/available voice and natural interpretation fallback.
- Segment notes distinguish unlabeled narrator lines.

## Limitation
- This remains segment preparation only; no TTS/audio synthesis is performed.

## Android update
- versionCode 127
- versionName 1.28-mixed-script-voice-segments

## Verification
- Targeted source check and JavaScript syntax verification performed.
- APK build and phone test not performed.
