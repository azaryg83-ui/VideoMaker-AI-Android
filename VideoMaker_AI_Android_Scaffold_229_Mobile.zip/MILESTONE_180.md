# Milestone 180 — Audio cut suggestions

- Heuristic suggestions are generated from edited audio activity intervals.
- Suggestions include active-interval starts and midpoint of gaps >= 0.3 sec.
- Each suggestion can be individually accepted or rejected.
- Accepted suggestions are applied as navigable markers only; no automatic scene splitting/reordering.
- VersionCode 137; versionName 1.38-audio-cut-suggestions.
- APK build and device testing not performed.
