# Scaffold 149 — Readiness report TXT export

- Added a second readiness report export format: human-readable TXT alongside JSON.
- TXT includes project name, localized check timestamp, pass/total count, each check result and detail, and the disclaimer.
- TXT export remains disabled until the audit is run, matching the JSON export gating.
- VersionCode 106; VersionName 1.07-readiness-report-txt.
- No APK build or device test was performed.
