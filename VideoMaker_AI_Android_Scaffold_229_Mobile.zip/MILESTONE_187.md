# Milestone 187 — Video scene preview synchronization

## Added
- Draft preview now renders scene video media when a scene has `videoData`, `videoUrl`, `videoURL`, or `videoFile` with supported data/blob/http/https/file URI source.
- Video playback is aligned to the scene-local draft offset, not reset to the clip start on each preview frame.
- Timeline seeking repositions the active scene video to its local offset.
- Pause, resume, and stop control the preview video player.
- Scene transitions replace the active video element and reset it to the next scene's local offset.
- If video is unavailable, preview falls back to the scene image or visual-description placeholder.

## Verification
- Static source checks and JavaScript syntax checks performed.
- ZIP integrity check performed.
- Android APK build and physical device playback not performed.

## Version
- versionCode: 144
- versionName: 1.45-video-scene-preview-sync
