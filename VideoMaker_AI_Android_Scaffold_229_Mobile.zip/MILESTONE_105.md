# Milestone 105 — Audio mixing controls

- Added local import controls for background music and multiple sound effects.
- Added separate voiceover/music/SFX volume sliders.
- Added fade-in and fade-out duration controls.
- Added remove controls for music and sound effects.
- Video export now mixes imported voiceover, music, and SFX through Web Audio gain nodes; fade automation is applied to imported tracks.
- Audio assets and mix settings are included in project JSON/local autosave and restored when reopening.
- This remains browser/MediaRecorder export: device codec support determines MP4/WebM; native Android build/export has not yet been tested.
- Build candidate version bumped to 0.64 / versionCode 64.
