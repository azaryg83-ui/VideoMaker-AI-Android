# Milestone 168 — Voice Casting Planner (Multilingual)

## Implemented
- Voice casting planning UI for narrator and script speakers.
- Heuristic language detection for several Latin-script languages and basic script-based identification for Arabic, Japanese, Chinese, Korean, Cyrillic (Russian/Ukrainian distinction heuristic).
- Manual language selection list.
- Extracts speaker labels from lines formatted `Speaker:` or `Speaker：`.
- Editable role, voice type, tone/interpretation, and per-speaker language.
- Export/copy voice cast plan as JSON.

## Important limitation
This is a planning/casting helper only. It does not synthesize audio and does not constitute complete multilingual TTS. Detection and speaker extraction are heuristic and must be reviewed.

## Android update
- versionCode 125
- versionName 1.26-voice-casting-planner

## Checks
- HTML has one Voice Casting Planner section and milestone script marker.
- Four inline JavaScript scripts syntax checked with Node.
- ZIP integrity checked.
- APK build and device testing not performed.
