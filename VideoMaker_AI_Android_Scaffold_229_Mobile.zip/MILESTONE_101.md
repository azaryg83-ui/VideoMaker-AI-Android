# Milestone 101 — Cosmetizare video: categorie dedicată și controale pentru scena curentă

- Added a dedicated `Cosmetizare` mobile navigation tab (8 tabs total; four-column two-row bottom navigation on phone, eight columns on wider layouts).
- Added a scene-level cosmetization panel with editable text overlay, overlay position, size, text color, background opacity, and visual filter presets.
- Applying the controls updates the selected scene and the cinematic canvas preview immediately; the existing canvas-based export path uses the same `draw()` rendering function.
- Added reset and scene-preview actions.
- Scene cosmetization settings are included in project serialization, autosave, import, and local project recovery through the existing scene-object persistence.
- This milestone does **not** claim to implement stickers, PIP, keyframes, transition libraries, or a full multi-track professional effects engine; those remain later tasks.
