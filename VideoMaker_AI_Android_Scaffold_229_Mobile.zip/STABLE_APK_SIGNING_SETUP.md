# Stable APK signing setup

The workflow supports signing future APKs with one persistent key. Configure these four GitHub repository Actions secrets:

- `VIDEOMAKER_KEYSTORE_BASE64` — Base64 encoding of the `.jks` file
- `VIDEOMAKER_KEYSTORE_PASSWORD`
- `VIDEOMAKER_KEY_ALIAS`
- `VIDEOMAKER_KEY_PASSWORD`

## Important transition warning

Do not assume an already-installed APK can be updated with this key. Android accepts an update only when package ID and signing certificate match the installed app. The installed app's certificate must be checked first; if it differs, a one-time uninstall/reinstall may be required, which removes app-local data unless backed up. Once the stable key is configured and used, preserve the keystore securely and never regenerate it.

## Generate a key (on a trusted computer)

Use `keytool` to generate a JKS key. Keep the keystore and passwords private. Convert the keystore to Base64 for the GitHub secret using `base64 -w 0 release.jks` on Linux (or equivalent on other systems). Add the four secrets in repository Settings → Secrets and variables → Actions. Do not commit the keystore or passwords.

The build manifest now records whether stable signing secrets were present and, when `apksigner` is available, the signer certificate SHA-256 fingerprint. This is evidence for comparing APK signatures; it does not itself guarantee update compatibility.
