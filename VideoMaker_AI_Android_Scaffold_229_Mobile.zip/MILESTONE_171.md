# Milestone 171 — Editable Voice Casting per Segment

- Added per-segment editable voice preference, interpretation/tone, and language selectors in the voice segment preparation UI.
- Overrides are stored directly on the segment objects and therefore included in JSON export/copy payload.
- This remains casting preparation only; no TTS synthesis/audio output is claimed.
- Android version: versionCode 128; versionName 1.29-editable-voice-segment-casting.
- Validation: 4 inline JavaScript scripts passed Node syntax checks; ZIP integrity passed.
- APK build and device test not performed.
