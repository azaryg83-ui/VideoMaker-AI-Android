# Scaffold 224 — repairs based on Scaffold 223 phone testing

## Repairs implemented in source
- Android Back navigation now handles wizard substeps, mode/type screens, project dashboard, editor tabs, and Home without leaving hidden screens behind.
- If Back is pressed from the Auto Intelligent wizard at step 2 or 3, it moves one wizard step backward. At step 1 it returns to mode selection; then type selection; then Home.
- Back from Project dashboard returns Home; Back from editor tabs returns to the Project tab, then Home.
- Back from Home returns `false` to the native Activity so Android can close the app normally instead of leaving a blank WebView state.
- New project creation now stores the complete project and autosave before adding the project to the library index. Errors are caught and shown to the user; the button is disabled during creation and restored afterward.
- Project library cleanup removes duplicate index IDs and orphaned entries with no saved project data.
- Opening projects now handles errors and removes stale entries when their saved project data is missing.
- Project actions are collapsed under a per-card “More actions” menu; only the primary Open button stays visible.
- Import/export and search/filter controls are grouped into collapsible panels; bulk actions are collapsed by default.
- Removed the redundant configuration Back button; the wizard uses its step-back control and a separately labeled cancel-to-Home control.
- Added top padding to the app header to reduce overlap with Android status-bar icons.

## Verification
- All 16 inline JavaScript blocks extracted and passed `node --check`.
- HTML ID audit found no duplicate IDs.
- Browser/device interaction test could not be run in this environment because the browser navigation is blocked by the environment policy.
- Android build and Redmi Note 14 Pro device test remain pending GitHub Actions and user testing.
