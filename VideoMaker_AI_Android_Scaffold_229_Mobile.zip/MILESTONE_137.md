# Scaffold 137 – Bulk prefix/suffix rename

Added a bulk library rename action for selected projects. The user chooses prefix or suffix, enters text, and confirms. Names are updated in the project index and stored project record; the matching autosave copy is updated too. Empty input, invalid mode, cancellation, or no selection leaves data unchanged. Names are capped at 160 characters and added text at 60 characters.

Version Code 94; Version Name 0.95-build-candidate. APK not built or device-tested.
