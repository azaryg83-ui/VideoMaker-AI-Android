# Scaffold 220 — Build Pipeline Repair & APK Checkpoint

- Added the previously missing GitHub Actions workflow `.github/workflows/android-apk-build.yml`.
- Workflow supports manual dispatch and pushes to main/master.
- Configures Java 17, Android SDK Platform 35, Build Tools 35.0.0, NDK 27.2.12479018, CMake 3.22.1, and Gradle 8.9.
- Extracts inline JavaScript and runs `node --check` before Android assembly.
- Runs `:app:assembleDebug` and uploads APK plus SHA256 and build metadata evidence.
- Build remains unexecuted in this environment; the workflow itself must be run on GitHub Actions.
