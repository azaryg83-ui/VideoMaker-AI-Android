# Milestone 182 — Storyboard linked to montage plan

- Added scene association selector for each accepted audio montage marker.
- Added editable visual-material note, subtitle/text, voice segment number, cut type, transition duration, and shot duration.
- Added apply-to-storyboard action that stores montageLink metadata on the selected project scene and preserves scene order.
- Subtitle text can populate scene subtitle; visual note can populate visualPrompt only if empty.
- Local persistence under `vm_storyboard_plan_v182` and JSON export `storyboard_montage_links.json`.
- VersionCode 139 / VersionName 1.40-storyboard-montage-links.
- Source checks and inline JS syntax checks performed; Android APK build and device testing not performed.
