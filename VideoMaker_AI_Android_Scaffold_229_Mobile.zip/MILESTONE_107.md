# Milestone 107 — Word timing and Karaoke preview

Implemented on Scaffold 106 source:
- Added a button to generate estimated word-level timing for each scene subtitle.
- Word timing records contain text/start/end seconds and are editable in the scene cards.
- Canvas preview highlights the active word when subtitle highlight mode is set to Word.
- Word timing data is included in project serialization and restores with the project.
- SRT export can emit word-level entries when Word highlight mode is selected and word timings exist.
- Android build candidate bumped to versionCode 65 / versionName 0.65-build-candidate.

Validation:
- Inline JavaScript extracted and checked with Node.js `node --check`: PASS.
- Static assertions for new UI, timing generator, editor inputs, serialization, highlight renderer, and SRT branch: PASS.
- ZIP integrity: PASS.

Limitations:
- Timing is estimated from text length and subtitle/scene duration; no speech recognition or waveform alignment is implemented.
- Word highlight preview is canvas-based and currently renders word text as a single centered line; long text may not wrap like standard subtitle lines.
- Android APK build and real-device test not performed (archive has no Gradle wrapper).
