# Milestone 166 — Short Video Scene Plan Generator

## Implemented
- Added a Short Video planner panel in the Script/Voiceover area.
- Uses saved target duration, Hook, and CTA settings.
- Segments script text into sentence/paragraph groups and estimates scene count for the selected duration.
- Generates a preview with scene type and estimated duration.
- Apply is a separate explicit action; preview does not replace existing scenes.
- Applying the plan creates editable scenes, captions/cues, visual prompts, motion/transition suggestions, and distributes total duration to the target.
- Autosave is scheduled after applying.

## Verification
- Scaffold 165 static checks: 8/8 PASS.
- Milestone 166 targeted checks: PASS (see scripts_m166_check.py).
- Inline JavaScript syntax: 4/4 PASS via Node `--check`.
- ZIP integrity: verified after packaging.
- Android APK build and device test: NOT performed.

## Android update
- versionCode: 123
- versionName: 1.24-short-plan-generator
