# Scaffold 125 — Import preview and validation

- Added import preview confirmation with project name, scene count, character count, embedded media estimate, and file size.
- Warns about missing/invalid project metadata and malformed scene entries before import.
- Normalizes missing project type/mode and character list; removes malformed scene entries.
- Imports as a new project and does not overwrite existing library projects.
- Version: 0.83 build candidate (versionCode 82).
- Validation: source checker, JavaScript syntax, and ZIP integrity; APK not built/device-tested.
