# Scaffold 214 — Preview Monitoring & Diagnostics

## Implemented
- Preview master-volume control (0–100%) applied to synchronized preview audio, independent of clip and track gain; persisted locally.
- Configurable synchronization correction tolerance (Strict 0.12 s / Normal 0.25 s / Relaxed 0.45 s), used by video and audio seek correction logic.
- Live text diagnostics for active clips/tracks: track eligibility, target source time, current audio-player time, drift, and playing state.
- Exportable JSON diagnostic report with cursor, monitor settings, track/clip metadata, and audio-player states.
- Public preview-monitor object renamed to `vmSyncedPreview214`.

## Verification
- 14 JavaScript script blocks extracted from HTML; all pass `node --check`.
- Source ZIP integrity checked.
- APK build and device testing not performed.

## Version
- VersionCode: 171
- VersionName: 1.72-preview-monitoring-diagnostics
