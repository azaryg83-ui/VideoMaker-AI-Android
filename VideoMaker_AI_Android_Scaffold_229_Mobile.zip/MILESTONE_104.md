# Milestone 104 — Tranziții suplimentare pentru scene

- Added wipe-left and wipe-right scene-entry masks.
- Expanded scene and storyboard transition selections with wipe presets and simplified dissolve.
- Existing fade and flash remain available.
- Transition values are stored through existing per-scene project serialization.
- These are canvas transition effects; this is not a multi-clip overlap transition engine.
