# Scaffold 195 — M7 Editor UX Foundation: Audio Preset Selector

## Roadmap placement
- **Current roadmap milestone: M7 — Editor / Montaj (ongoing).**
- This scaffold is a UX foundation block inside M7, not a standalone milestone.
- M7 remains incomplete: the shared editor, timeline, media layers, audio integration, and editing controls still require further work and runtime/device testing.

## Baseline
- Scaffold 194, versionCode 150, versionName `1.51-draft-music-sfx-sync-preview`.
- Existing audio mix presets and draft music/SFX preview are preserved.

## Implemented
- Replaced the always-visible preset dropdown/application row with a compact selector opener.
- Added a visual mobile-friendly preset picker with four cards: Documentary, Cinematic, Balanced, and Music Focus.
- Selecting a preset applies it immediately and closes the picker automatically.
- Added a close control for the picker.
- Collapsed advanced volume and fade controls by default; users can reveal or hide them.
- Preset engine, individual track settings, existing preview controls, and autosave logic remain in place.
- Updated Android version: versionCode 151, versionName `1.52-audio-mix-visual-selector`.

## Verification
- Extracted and checked all 10 inline JavaScript blocks with Node `--check`: PASS 10/10.
- Static source assertions: PASS 8/8.
- ZIP integrity check: performed after packaging.
- Android APK build: not performed (Android SDK/build environment not verified).
- Redmi Note 14 Pro runtime/device test: not performed.

## Limitations
- This is an interaction/UI implementation; runtime behavior and touch layout still require Android WebView testing.
- Audio preview synchronization remains approximate as documented in Scaffold 194.
