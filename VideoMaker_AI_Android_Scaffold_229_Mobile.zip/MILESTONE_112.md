# Milestone 112 — Audio tracks aligned to timeline scale

- Audio timeline lanes now share the same width/scale as the scene timeline and ruler.
- Voiceover shows a proportional clip from timeline zero using its detected duration.
- Music and SFX show proportional blocks at configured start positions, using trim duration.
- Removed the previous margin-left-only representation in favor of positioned timeline blocks.
- App version: 0.70-build-candidate (versionCode 70).
- Static checks and JS syntax checks performed; Android APK build/device test not performed.
