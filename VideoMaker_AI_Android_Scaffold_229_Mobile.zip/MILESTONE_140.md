# Scaffold 140 — Redesigned home studio and quick mode launch

- Replaced the basic home header with a visible Studio hero and quick launch cards.
- Added direct launch shortcuts for Auto Intelligent, Guided Manual, and Professional modes.
- Quick launches open the existing new-project wizard and select the requested mode; they do not claim AI generation is connected.
- Kept the project library and existing editor workflow intact.
- Version Code 97; Version Name 0.98-build-candidate.
- APK build/device testing not performed in this environment.
