# Milestone 176 — Voiceover-to-scene duration sync and subtitle preparation

## Added
- Native bridge reports the duration of the merged WAV using parsed PCM format and data size.
- New UI action: fit scene durations to the merged voiceover duration and prepare subtitle cues per scene.
- Scene durations are distributed proportionally by caption/subtitle word count, then rounded while preserving the total duration.
- Subtitle cues are generated with the existing estimated cue timing helper; word-level phonetic/audio alignment is not claimed.
- Scene rendering, timeline reset, counter, and autosave are refreshed after applying.

## Verification
- Source-level checks: native duration bridge, new control, merge enables control, timing distribution, cue generation, autosave, version bump.
- Inline JavaScript syntax: 4/4 PASS (`node --check`).
- ZIP integrity: verified after creation.
- Android APK build: not performed.
- Redmi Note 14 Pro test: not performed.

## Version
- versionCode 133
- versionName 1.34-voiceover-scene-sync
