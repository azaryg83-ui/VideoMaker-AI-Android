# Scaffold 208 — Multitrack Group Editing Block

## Added
- Select all clips active at a chosen timeline time.
- Move selected clips to a chosen timeline position while preserving relative offsets.
- Split selected clips that cross the chosen timeline position, retaining clip source, track and enabled state.
- Apply a shared duration to selected clips.
- Operations use the multitrack undo checkpoint/history and save locally.

## Verification
- JavaScript syntax checks and ZIP integrity check run during packaging.
- APK build and device testing were not performed.
