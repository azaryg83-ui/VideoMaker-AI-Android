# Milestone 190 — Transition controls and separate transition preview

- Added per-draft-frame transition start offset and duration controls.
- Added a dedicated transition preview action for each frame (except the final frame).
- Preview supports dissolve/fade-style opacity blend, whip-pan motion, and match-cut scaling.
- Main draft preview now uses the configured transition start and duration rather than a fixed transition window.
- Saved transition start/duration in each scene's montageDraft metadata.
- Version: versionCode 146, versionName 1.47-transition-controls-preview.

## Validation
- JavaScript syntax checks and source-level assertions run in this milestone.
- ZIP integrity checked.
- APK build and device testing not performed.
