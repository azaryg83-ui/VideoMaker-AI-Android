# Milestone 99 — Auto Intelligent brief

Added a project-creation brief panel for Auto Intelligent mode:
- topic/idea text
- target audience
- tone selection
- approximate target duration in minutes
- metadata persisted in project object (`autoBrief`)
- brief text is placed into the Scenario field when creating an Auto project
- panel visibility follows selected mode

This is a local brief-preparation feature, not an AI script generator. AI generation remains unconnected and is stated clearly in the UI.

Validation: inline JavaScript syntax checked with Node; archive integrity checked. Android Gradle build not run.
