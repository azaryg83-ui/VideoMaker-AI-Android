# Scaffold 145 — Auto Intelligent workflow navigation

- Added a per-step "Deschide etapa în editor" action to the Auto Intelligent production-plan checklist.
- Stage routing: script/voiceover -> Script; scenes -> Scenes; visual materials/characters -> Characters & Images; subtitles -> Captions; editing/synchronization/export/review -> Edit.
- Existing completion checkbox and persisted checklist state remain intact.
- Version: versionCode 102, versionName 1.03-auto-workflow-candidate.

## Validation
- Source-contract checks: 11/11 PASS.
- Inline JavaScript syntax: PASS for all non-empty inline script blocks.
- ZIP integrity: checked after packaging.
- Android APK build and device test: not performed.
