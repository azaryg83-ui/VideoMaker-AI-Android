# Scaffold 159 — AI generation controls in reusable profiles

- Expanded AI generation profiles to include CFG Scale, seed strategy, and fixed seed in addition to endpoint, steps, and sampler.
- Built-in presets now provide distinct CFG/seed defaults.
- Seed strategy supports random (-1), stable per-scene seed, or fixed seed. Per-scene seed is deterministic from the scene ID (or scene index fallback).
- AI request payload now uses the configured CFG scale and seed rather than hard-coded CFG 7.
- Legacy custom profiles remain compatible through default values for missing fields.
- Profile changes are labeled as configuration only; generation still requires the connected compatible server.
- Version: 1.17, versionCode 116.
- Not compiled as APK and not tested against a live AI server or on device.
