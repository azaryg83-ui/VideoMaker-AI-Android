# Milestone 95 — Organizarea editorului și module collapsible

## Implementat
- Adăugat panou de organizare a modulelor în editor.
- Fiecare card de editor cu titlu H2 poate fi extins/restrâns individual.
- Controale globale „Extinde toate” și „Restrânge toate”.
- Titlurile modulelor au indicator vizual și atribut `aria-expanded`.
- Conținutul modulelor este păstrat în DOM; funcțiile și ID-urile existente nu sunt schimbate.
- Stiluri adaptate pentru layout mobil și desktop.

## Verificare
- Scripturile JavaScript din HTML au trecut `node --check`.
- Verificate prezența panoului, controalelor globale, handlerelor individuale și aria state.
- APK/Android build nu a fost executat în acest mediu; necesită GitHub Actions.
