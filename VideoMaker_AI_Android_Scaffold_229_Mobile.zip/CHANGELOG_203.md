# Scaffold 203 — 1.61 Chapter/Sequence Organizer
- Added chapter/sequence grouping by scene range.
- Create/edit/delete, color coding, quick navigation, chapter list reorder.
- Proportional chapter overview based on scene durations.
- JSON import/export with scene-range validation.
- Local persistence.
- VersionCode 160; VersionName 1.61-chapter-sequence-organizer.
