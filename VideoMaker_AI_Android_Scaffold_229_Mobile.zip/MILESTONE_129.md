# Scaffold 129 — Operații în lot în biblioteca de proiecte

## Implementare
- Selectare individuală prin checkbox pentru fiecare proiect afișat.
- Selectează toate proiectele vizibile (respectă căutarea și filtrul curent).
- Deselectează toate.
- Duplică proiectele selectate.
- Exportă backup JSON pentru proiectele selectate, cu confirmare înainte de exportul multiplu.
- Șterge proiectele selectate, cu confirmare; elimină și timeline-history/recovery-backup asociate și autosave dacă aparține unuia dintre proiectele șterse.
- Contor de selecție și actualizare după acțiuni.

## Verificări
- Checker static: 10/10 PASS.
- Sintaxă JavaScript (4 scripturi): PASS (`node --check`).
- Integritate ZIP: verificată la împachetare.
- Version Code 86, Version Name 0.87-build-candidate.

## Limitări
APK-ul nu a fost compilat sau testat pe dispozitiv. Exporturile multiple pot necesita permisiune/confirmare Android sau browser; comportamentul download-urilor multiple depinde de platformă.
