# Scaffold 146 — APK signing evidence and update readiness

- Version bumped to versionCode 103 / versionName 1.04-signing-audit-candidate.
- GitHub Actions now exposes an explicit stable-signing enabled/disabled flag to the build manifest.
- Build manifest records stable-signing configuration and signer certificate SHA-256 fingerprint when available.
- Added stable-signing setup and transition warning documentation.
- No APK build or phone installation was performed.
