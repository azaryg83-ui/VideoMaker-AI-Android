# Milestone 102 — Stickere și overlay/PIP de imagine

- Added selectable sticker/emoji presets with size and placement controls.
- Added image overlay/PIP import, size and placement controls.
- Sticker and image overlay are drawn in the canvas preview and the existing canvas-based export render path.
- Imported PIP image data and sticker settings are serialized with each scene and restored on project import/recovery.
- Reset cosmetization clears sticker and PIP layer settings; it does not alter scene base media.
- This remains a single-overlay prototype, not a multi-layer professional compositor.
