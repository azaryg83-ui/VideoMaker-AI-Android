# Scaffold 157 — AI batch preflight confirmation

- Added a pre-generation confirmation for both selected-scene batches and missing-image batches.
- Preflight reports queue size, scenes lacking explicit visual prompts, scenes lacking captions, and scenes already containing images.
- Explains that missing prompts may use the existing automatic caption fallback and that the connected external AI server consumes resources.
- Generation starts only after user confirmation; cancel leaves the batch unstarted.
- Version: 1.15, versionCode 114.
- Validation: 8/8 source checks passed; all 4 inline JS scripts passed `node --check`; ZIP integrity checked after packaging.
- Not compiled as APK; not tested on device; live AI server behavior not tested.
