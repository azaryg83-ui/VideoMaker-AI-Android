# Milestone 113 — Editare durată scenă pe timeline

- Added per-scene duration sliders directly below the scene timeline.
- Slider values update scene duration (1–30 seconds, 0.1-second steps), refresh preview/scenes/timeline, and autosave.
- Existing drag-and-drop scene reordering remains in place.
- Version: 0.71-build-candidate (versionCode 71).

Verification: static source checks and JavaScript syntax check only; Android APK build/device testing not performed.
