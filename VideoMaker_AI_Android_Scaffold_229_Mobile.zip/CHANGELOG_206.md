# Scaffold 206 — Chapter split & merge
- Added automatic split of a chapter into two scene ranges at the midpoint.
- Added merge with the next chapter only when scene ranges are contiguous.
- Both operations refresh the chapter coverage audit and preserve scene order/durations.
- VersionCode 163 / VersionName 1.64-chapter-split-merge.
