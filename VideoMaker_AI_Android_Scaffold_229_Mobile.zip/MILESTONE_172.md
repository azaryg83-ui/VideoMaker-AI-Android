# Milestone 172 — Local Android TTS segment preview

- Added Android `TextToSpeech` initialization and lifecycle shutdown.
- Added JavaScript bridge for speaking a selected prepared segment, stopping playback, and reporting readiness.
- Segment cards now include a local TTS preview button and stop control.
- Language selection uses the selected segment language; `auto`/`other` currently falls back to Romanian. Unsupported/uninstalled languages return a clear status.
- Voice selection attempts a matching installed voice by gender-name heuristic, then falls back to first voice for the language.
- Tone selection maps limited pitch/speech-rate adjustments (grave/authoritative, energetic, calm/mysterious); this is not expressive neural voice generation.
- No TTS audio file export yet; this milestone is playback preview only.
- Android APK build and device test not performed (no Gradle wrapper/build environment confirmed).

Version: versionCode 129, versionName 1.30-local-tts-preview
