# Scaffold 218 — Native image-scene MP4 render (first real render path)

- Added Android-native H.264/MP4 encoding path using MediaCodec + MediaMuxer for storyboard `sceneDraft` image scenes with Data URL image sources.
- Added asynchronous native render call and JavaScript progress/completion/error callbacks.
- MP4 output is saved through MediaStore under Downloads/VideoMakerAI/Renders.
- Output is bounded for mobile: maximum 60 seconds (1800 frames at 30 FPS), FPS capped at 30, output dimensions downscaled to at most 1280 px long edge and approximately 720p pixel area.
- Image scenes are letterboxed against a black background.
- This first render path does NOT include timeline video clips, multi-track audio, subtitles, effects, transitions, or timeline overlays. APK compilation and on-device encoder validation remain required.
- VersionCode 175 / VersionName 1.76-native-image-scene-mp4-render.
