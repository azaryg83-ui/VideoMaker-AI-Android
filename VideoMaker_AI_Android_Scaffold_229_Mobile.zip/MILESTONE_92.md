# Milestone 92 — Home dashboard and new-project flow (foundation)

- Added a Home dashboard as the app's initial screen.
- Added Continue Saved Project entry (uses existing local autosave restore control).
- Added a new-project wizard with Film/Documentary, YouTube, Shorts, TikTok, Reels and Custom choices.
- Added Auto Intelligent, Guided Manual and Professional/Advanced mode choices.
- New project selection sets project name and aspect ratio (vertical formats use 9:16; landscape defaults to 16:9) and starts the existing editor.
- Added editor-to-Home navigation.
- Project type and mode metadata are included in project JSON/autosave and restored when importing or recovering local autosave.
- Added confirmation before replacing the existing local autosave when starting a new project.
- Version bumped to 0.59 build candidate (versionCode 59).

## Scope / limitations
- This milestone is a foundation UI flow. The three modes do not yet have distinct workflows/behavior.
- Multi-project independent storage and project list management are not implemented yet; starting a new project replaces the current autosave after confirmation. Export a JSON backup first if you need to preserve the previous project.
- APK build remains unverified locally; GitHub Actions build is required for an actual APK.

## Validation
- Frontend static structure and inline JavaScript checks passed.
- Milestone 90 and 91 contract checks passed.
- Milestone 92 static contract check passed.
