# Scaffold 207 — Chapter list sorting
- Added chapter list sort modes: chronological, alphabetical, and duration descending.
- Timeline visualization remains chronological regardless of list sort.
- Sorting preference persists locally.
- Removed ineffective up/down list controls that were undone by chronological sorting.
- Action buttons use chapter identity/index mapping so they remain correct under non-chronological list views.
- VersionCode 164 / VersionName 1.65-chapter-list-sorting.
