# Scaffold 128 – Project library search, filtering and sorting

## Implemented
- Added a project-name search field to the project library.
- Added project-type filtering (all, documentary, film, YouTube, Shorts, TikTok, Reels, custom).
- Added sort modes: recent, oldest, name A–Z and Z–A.
- Added a visible count of displayed projects and filtered state.
- Empty filtered results display a clear message without changing/deleting project data.
- Existing project actions remain attached to rendered cards.

## Validation
- Static source checker: 13/13 PASS.
- JavaScript syntax check (4 inline scripts): PASS.
- ZIP integrity: to be verified after archive creation.

## Version
- versionCode = 85
- versionName = 0.86-build-candidate

## Limits
- APK compilation and device testing not performed in this environment.
