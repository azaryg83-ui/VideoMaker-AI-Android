# Milestone 185 — synchronized-start voiceover draft preview

- Added native playback of the merged `merged_voiceover.wav` using the existing Android `MediaPlayer` slot.
- Added a Voiceover ON/OFF control to the montage draft preview. When enabled, the merged WAV starts at the same time as the draft sequence preview.
- Stopping/finishing the preview calls the existing native stop method, stopping the voiceover player too.
- This is synchronized start, not sample-accurate AV synchronization: draft frame timing remains driven by the WebView preview clock and the WAV is played by native MediaPlayer. Exact synchronization, music and sound-effects mixing remain future work.
- Fixed a preview runtime issue where `pvText` was declared `const` but reassigned when switching preview content.
- versionCode 142, versionName `1.43-synchronized-voiceover-preview`.
- APK build and device test not performed.
