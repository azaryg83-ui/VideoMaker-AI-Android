# Scaffold 133 — Project status workflow

Implemented in the project library:
- Per-project status: Draft (Ciornă), In progress (În lucru), Ready (Gata), Archived (Arhivat).
- Status filter combines with existing search, project type, tags and favorites.
- Each project card displays its current status and includes a cycle-status action.
- Status is stored in library metadata; projects without status default to Draft.
- Duplicated projects inherit status.
- Version Code 90 / Version Name 0.91-build-candidate.

Validation: see scripts_m133_check.py. APK build/device testing not performed.
