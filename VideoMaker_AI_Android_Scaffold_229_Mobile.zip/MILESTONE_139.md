# Scaffold 139 — Bulk add tags without replacing existing tags

- Added library action **Adaugă etichete selectate**.
- Adds comma-separated tags to selected projects while preserving their existing tags.
- Deduplicates tags, trims and sanitizes entries, caps each tag at 24 characters and each project at 8 tags.
- Empty/invalid input or no selection leaves project data unchanged.
- Refreshes the library and reports projects changed and number of new tags.
- Version Code 96; Version Name 0.97-build-candidate.
- APK build and device testing not performed.
