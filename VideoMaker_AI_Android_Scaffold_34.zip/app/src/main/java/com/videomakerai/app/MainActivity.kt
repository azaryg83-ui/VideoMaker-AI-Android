package com.videomakerai.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedInputStream
import java.security.MessageDigest
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private var nativeLibraryLoaded = false
    private val nativeGenerationExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "VideoMakerNativeGeneration").apply { isDaemon = true } }
    private external fun nativeStatus(): String
    private external fun nativeRuntimeInfo(): String
    private external fun nativeGenerateSmokeTest(modelPath: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String
    private external fun nativeGenerateImagePayload(modelPath: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String
    companion object {
        init { try { System.loadLibrary("videomaker_native") } catch (_: Throwable) { } }
    }
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 701
    private val modelPickerRequest = 702
    private val modelExtensions = setOf("gguf", "safetensors", "ckpt", "pt", "pth", "onnx")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nativeLibraryLoaded = try { nativeStatus().isNotBlank() } catch (_: Throwable) { false }
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // This editor is bundled in app assets. Keep file access enabled only for the
        // packaged editor and block navigation away from that trusted origin.
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) webView.settings.safeBrowsingEnabled = true
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = params.acceptTypes.firstOrNull()?.takeIf { it.isNotBlank() } ?: "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, params.acceptTypes.filter { it.isNotBlank() }.toTypedArray())
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (e: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    Toast.makeText(this@MainActivity, "Nu pot deschide selectorul de fișiere.", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            private val trustedEditorPrefix = "file:///android_asset/web/"
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                // Prevent the JavaScript bridge from being exposed to arbitrary pages.
                return !url.startsWith(trustedEditorPrefix)
            }
            @Deprecated("Deprecated on newer Android versions")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return !url.startsWith(trustedEditorPrefix)
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "VideoMakerNative")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/web/index.html")
    }

    @Deprecated("Activity result API retained for compatibility with this minimal scaffold")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == modelPickerRequest) {
            if (resultCode == RESULT_OK && data?.data != null) importModelUri(data.data!!)
            else runOnUiThread { webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Import anulat.');", null) }
            return
        }
        if (requestCode != filePickerRequest) return
        val callback = fileChooserCallback ?: return
        fileChooserCallback = null
        if (resultCode != RESULT_OK || data == null) {
            callback.onReceiveValue(null)
            return
        }
        val uris = data.clipData?.let { clip ->
            Array(clip.itemCount) { index -> clip.getItemAt(index).uri }
        } ?: data.data?.let { arrayOf(it) }
        callback.onReceiveValue(uris)
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun getCapabilities(): String {
            val info = JSONObject()
            info.put("nativeShell", true)
            info.put("diffusionEngine", false)
            info.put("nativeBridgeLibraryLoaded", nativeLibraryLoaded)
            info.put("nativeBridgeStatus", if (nativeLibraryLoaded) nativeStatus() else "native-library-not-loaded")
            info.put("nativeRuntimeInfo", if (nativeLibraryLoaded) nativeRuntimeInfo() else "JNI library unavailable")
            info.put("status", "android-shell-jni-boundary")
            info.put("manufacturer", Build.MANUFACTURER)
            info.put("model", Build.MODEL)
            info.put("androidVersion", Build.VERSION.RELEASE)
            info.put("sdk", Build.VERSION.SDK_INT)
            info.put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown")
            val cpuInfo = try { File("/proc/cpuinfo").readText() } catch (_: Exception) { "" }
            val cpuFlags = Regex("(?im)^\\s*(Features|flags)\\s*:\\s*(.+)$").findAll(cpuInfo)
                .map { it.groupValues[2].lowercase().split(Regex("\\s+")) }.flatten().toSet()
            info.put("cpuDotprod", cpuFlags.contains("asimddp") || cpuFlags.contains("dotprod"))
            info.put("cpuFp16", cpuFlags.contains("fphp") || cpuFlags.contains("asimdhp"))
            info.put("cpuNeon", cpuFlags.contains("asimd") || cpuFlags.contains("neon"))
            info.put("cpuFeatureDetection", if (cpuFlags.isEmpty()) "unavailable" else "read-from-proc-cpuinfo")
            info.put("webViewFilePicker", true)
            val activityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            info.put("totalRamBytes", memoryInfo.totalMem)
            info.put("availableRamBytes", memoryInfo.availMem)
            info.put("lowMemory", memoryInfo.lowMemory)
            info.put("engineStatus", "not-integrated")
            info.put("modelImportSupport", true)
            info.put("modelsStoredPrivately", true)
            info.put("modelImportFormats", "gguf,safetensors,ckpt,pt,pth,onnx")
            val runtime = Runtime.getRuntime()
            info.put("appMaxHeapBytes", runtime.maxMemory())
            info.put("appUsedHeapBytes", runtime.totalMemory() - runtime.freeMemory())
            info.put("appFreeHeapBytes", runtime.freeMemory())
            info.put("processId", Process.myPid())
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.put("thermalStatus", powerManager.currentThermalStatus)
                info.put("thermalStatusLabel", thermalLabel(powerManager.currentThermalStatus))
            } else {
                info.put("thermalStatus", -1)
                info.put("thermalStatusLabel", "unsupported")
            }
            info.put("note", "Native shell diagnostics available; AI engine not integrated")
            return info.toString()
        }

        @JavascriptInterface
        fun engineStatus(): String = if (nativeLibraryLoaded) nativeStatus() else "native-library-not-loaded; diffusion-runtime-not-integrated"

        @JavascriptInterface
        fun nativeInferenceSmokeTest(modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String {
            if (!nativeLibraryLoaded) return "ERROR: native bridge unavailable"
            val model = safeModelFile(modelFileName)
                ?: return "ERROR: invalid model filename or model path outside private library"
            if (!model.exists() || !model.isFile) return "ERROR: model file not found in app-private models folder"
            if (prompt.isBlank()) return "ERROR: prompt is empty"
            if (width !in 256..512 || height !in 256..512 || steps !in 1..20 || threads !in 1..6) return "ERROR: test settings outside safe limits"
            return try { nativeGenerateSmokeTest(model.absolutePath, prompt, width, height, steps, seed, threads) }
            catch (e: Throwable) { "ERROR: ${e.message ?: "native call failed"}" }
        }

        @JavascriptInterface
        fun getThermalStatus(): String {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "unsupported"
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            return thermalLabel(powerManager.currentThermalStatus)
        }

        @JavascriptInterface
        fun nativeGenerateImagePayloadAsync(callbackId: String, modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int) {
            val safeCallbackId = callbackId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64)
            if (safeCallbackId.isBlank()) return
            if (!nativeLibraryLoaded) {
                deliverNativeGenerationResult(safeCallbackId, "NOT_READY|native library not loaded")
                return
            }
            val model = safeModelFile(modelFileName)
            if (model == null || !model.exists() || !model.isFile) {
                deliverNativeGenerationResult(safeCallbackId, "ERROR|invalid model filename or model path outside private library")
                return
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val thermal = (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus
                if (thermal >= PowerManager.THERMAL_STATUS_SEVERE) {
                    deliverNativeGenerationResult(safeCallbackId, "THERMAL_BLOCKED|phone thermal status is severe; cool the device before generating")
                    return
                }
            }
            if (prompt.isBlank()) {
                deliverNativeGenerationResult(safeCallbackId, "ERROR|prompt is empty")
                return
            }
            val safeWidth = width.coerceIn(256, 512)
            val safeHeight = height.coerceIn(256, 512)
            val safeSteps = steps.coerceIn(1, 20)
            val safeThreads = threads.coerceIn(1, 6)
            nativeGenerationExecutor.execute {
                val result = try {
                    this@MainActivity.nativeGenerateImagePayload(model.absolutePath, prompt.take(4000), safeWidth, safeHeight, safeSteps, seed, safeThreads)
                } catch (e: Throwable) {
                    "ERROR|${e.message ?: "native generation failed"}"
                }
                deliverNativeGenerationResult(safeCallbackId, result)
            }
        }

        private fun deliverNativeGenerationResult(callbackId: String, payload: String) {
            runOnUiThread {
                val quotedId = JSONObject.quote(callbackId)
                val quotedPayload = JSONObject.quote(payload)
                webView.evaluateJavascript("window.onNativeGenerationResult && window.onNativeGenerationResult($quotedId,$quotedPayload);", null)
            }
        }

        @JavascriptInterface
        fun nativeGenerateImagePayload(modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String {
            if (!nativeLibraryLoaded) return "NOT_READY|native library not loaded"
            val safeName = modelFileName.replace("/", "").replace("\\", "")
            val model = File(modelsDirectory(), safeName)
            if (!model.exists() || !model.isFile) return "ERROR|model file not found in app-private models folder"
            val safeWidth = width.coerceIn(256, 512)
            val safeHeight = height.coerceIn(256, 512)
            val safeSteps = steps.coerceIn(1, 20)
            val safeThreads = threads.coerceIn(1, 6)
            return try { this@MainActivity.nativeGenerateImagePayload(model.absolutePath, prompt.take(4000), safeWidth, safeHeight, safeSteps, seed, safeThreads) }
            catch (e: Throwable) { "ERROR|${e.message ?: "native generation failed"}" }
        }

        @JavascriptInterface
        fun requestModelImport() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                try { startActivityForResult(intent, modelPickerRequest) }
                catch (e: Exception) { webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Selector de fișiere indisponibil.');", null) }
            }
        }

        @JavascriptInterface
        fun listModels(): String = modelListJson()

        @JavascriptInterface
        fun deleteModel(fileName: String): String {
            val safe = fileName.replace("/", "").replace("\\", "")
            val file = File(filesDir, "models/$safe")
            val deleted = file.exists() && file.isFile && file.delete()
            File(filesDir, "models/$safe.sha256").delete()
            return JSONObject().put("deleted", deleted).put("models", modelListJson()).toString()
        }

        @JavascriptInterface
        fun showMessage(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(180), Toast.LENGTH_SHORT).show() }
        }
    }


    private fun safeModelFile(fileName: String): File? {
        if (fileName.isBlank() || fileName == "." || fileName == ".." ||
            fileName.contains("/") || fileName.contains("\\") ||
            !fileName.matches(Regex("[A-Za-z0-9._() -]{1,180}"))) return null
        val dir = modelsDirectory().canonicalFile
        val candidate = File(dir, fileName).canonicalFile
        if (candidate.parentFile != dir) return null
        return candidate
    }

    private fun modelsDirectory(): File = File(filesDir, "models").apply { if (!exists()) mkdirs() }

    private fun modelListJson(): String {
        val dir = modelsDirectory()
        val files = dir.listFiles()?.filter { it.isFile && !it.name.startsWith(".") && !it.name.endsWith(".sha256") }?.map { f ->
            val checksumFile = File(dir, f.name + ".sha256")
            val checksum = if (checksumFile.exists()) checksumFile.readText().trim().takeIf { it.matches(Regex("[a-fA-F0-9]{64}")) } else null
            JSONObject().put("name", f.name).put("sizeBytes", f.length()).put("extension", f.extension.lowercase())
                .put("sha256", checksum ?: JSONObject.NULL)
        } ?: emptyList()
        val stat = android.os.StatFs(filesDir.absolutePath)
        return JSONObject().put("models", org.json.JSONArray(files)).put("count", files.size)
            .put("freeAppStorageBytes", stat.availableBytes).put("storagePath", "app-private/models")
            .put("engineIntegrated", false).toString()
    }

    private fun importModelUri(uri: Uri) {
        webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Import în curs; copierea se face în spațiul privat al aplicației…');", null)
        Thread {
            var status = "Import eșuat."
            try {
                val name = queryDisplayName(uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in modelExtensions) throw IllegalArgumentException("Format neacceptat. Acceptăm: GGUF, SafeTensors, ONNX, CKPT/PT/PTH.")
                val dir = modelsDirectory()
                val available = android.os.StatFs(filesDir.absolutePath).availableBytes
                val declaredSize = try {
                    contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
                    } ?: -1L
                } catch (_: Exception) { -1L }
                val maxModelBytes = 6L * 1024 * 1024 * 1024
                if (declaredSize > maxModelBytes || (declaredSize > 0 && declaredSize > available))
                    throw IllegalArgumentException("Fișier prea mare pentru importul sigur (limită 6 GB / spațiu disponibil).")
                // Preserve existing models: choose a unique final name and copy to a temporary file first.
                var finalName = name
                var target = File(dir, finalName)
                var suffix = 1
                while (target.exists()) {
                    val stem = name.substringBeforeLast('.', name)
                    val extension = name.substringAfterLast('.', "")
                    finalName = if (extension.isNotBlank()) "$stem ($suffix).$extension" else "$name ($suffix)"
                    target = File(dir, finalName)
                    suffix++
                }
                val temp = File(dir, ".import-${System.currentTimeMillis()}-$finalName.tmp")
                val digest = MessageDigest.getInstance("SHA-256")
                var total = 0L
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        BufferedInputStream(input).use { buffered ->
                            FileOutputStream(temp).use { output ->
                                val buffer = ByteArray(1024 * 1024)
                                while (true) {
                                    val read = buffered.read(buffer)
                                    if (read < 0) break
                                    total += read
                                    val currentAvailable = android.os.StatFs(filesDir.absolutePath).availableBytes
                                    if (total > maxModelBytes || total > available || read > currentAvailable) {
                                        throw IllegalArgumentException("Import oprit: modelul depășește limita sau spațiul liber.")
                                    }
                                    digest.update(buffer, 0, read)
                                    output.write(buffer, 0, read)
                                }
                                output.fd.sync()
                            }
                        }
                    } ?: throw IllegalStateException("Nu pot deschide fișierul ales.")
                    if (declaredSize >= 0 && total != declaredSize) throw IllegalStateException("Dimensiunea copiată nu corespunde fișierului sursă.")
                    if (!temp.renameTo(target)) throw IllegalStateException("Nu pot finaliza importul atomic al modelului.")
                } finally {
                    if (temp.exists()) temp.delete()
                }
                val sha256 = digest.digest().joinToString("") { "%02x".format(it) }
                val checksumTemp = File(dir, ".$finalName.sha256.tmp")
                val checksumTarget = File(dir, "$finalName.sha256")
                try {
                    FileOutputStream(checksumTemp).use { checksumOutput ->
                        checksumOutput.write((sha256 + "\n").toByteArray(Charsets.UTF_8))
                        checksumOutput.fd.sync()
                    }
                    if (!checksumTemp.renameTo(checksumTarget)) {
                        throw IllegalStateException("Nu pot salva fișierul de verificare SHA-256.")
                    }
                } catch (checksumError: Exception) {
                    checksumTemp.delete()
                    checksumTarget.delete()
                    target.delete()
                    throw IllegalStateException("Import anulat: nu am putut salva verificarea SHA-256; modelul a fost șters pentru a evita o bibliotecă incompletă.", checksumError)
                }
                status = "Model importat: $finalName (${formatBytes(target.length())}). SHA-256: $sha256. Fișierul este stocat local; motorul de inferență nu este încă integrat."
            } catch (e: Exception) { status = e.message ?: "Import eșuat." }
            val finalStatus = status
            runOnUiThread { webView.evaluateJavascript("window.onNativeModelImportStatus(${JSONObject.quote(finalStatus)}); window.refreshNativeModels && window.refreshNativeModels();", null) }
        }.start()
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "model.bin"
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "model.bin"
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L*1024*1024 -> "%.2f GB".format(bytes/(1024.0*1024*1024))
        bytes >= 1024L*1024 -> "%.1f MB".format(bytes/(1024.0*1024))
        else -> "$bytes bytes"
    }

    private fun thermalLabel(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "none"
        PowerManager.THERMAL_STATUS_LIGHT -> "light"
        PowerManager.THERMAL_STATUS_MODERATE -> "moderate"
        PowerManager.THERMAL_STATUS_SEVERE -> "severe"
        PowerManager.THERMAL_STATUS_CRITICAL -> "critical"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "emergency"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "shutdown"
        else -> "unknown"
    }

    override fun onBackPressed() {
        // Do not allow Back to navigate the trusted editor into an external page.
        if (webView.canGoBack() && webView.url?.startsWith("file:///android_asset/web/") == true) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        nativeGenerationExecutor.shutdownNow()
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        webView.destroy()
        super.onDestroy()
    }
}
