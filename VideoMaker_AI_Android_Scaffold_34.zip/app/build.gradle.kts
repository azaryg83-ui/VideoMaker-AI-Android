plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.videomakerai.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.videomakerai.app"
        ndk { abiFilters += listOf("arm64-v8a") }
        minSdk = 28
        targetSdk = 35
        versionCode = 34
        versionName = "0.34-build-candidate"
    }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
}
