# Milestone 62 — Device Resource Budget & Thermal-Aware AI Readiness

## Changes
- Android native capability report now includes Android `MemoryInfo.threshold` and available storage in app-private model storage (`StatFs`).
- Local AI readiness panel now estimates a conservative memory budget for a future model using current available RAM and app heap maximum (30% of available RAM, capped at 35% of app heap max).
- Displays physical RAM, currently available RAM, app heap maximum, available private storage, and thermal status.
- Provides cautious guidance based on low-memory state, available RAM, estimated budget, and thermal state.
- Explicitly labels the budget as a planning estimate, not an inference benchmark or proof of model compatibility.

## Safety / limitations
- Native diffusion runtime is still not integrated. No model is downloaded.
- A static memory budget cannot predict runtime memory usage accurately; actual compatibility requires a model/runtime integration and device inference test.
- Android APK/device runtime test not performed.

## Validation performed
- `scripts/frontend_check.sh`
- `scripts/bridge_contract_check.py`
- `scripts/ci_workflow_check.py`
- `scripts/host_native_check.sh`
- `scripts/verify_source.sh`
- Additional source check for new memory-threshold and storage diagnostics and readiness budget logic.
