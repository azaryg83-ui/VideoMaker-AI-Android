# Milestone 53 — Character Scene Coverage

Added a character coverage utility for multi-character documentary projects:
- Shows each saved character's assigned-scene count.
- Counts scenes where the character's exact saved name appears in narration (simple case-insensitive text matching).
- Displays estimated unassigned mentions as a review cue.
- Exports a TXT coverage report.
- Adds optional auto-assignment for unassigned scenes when a saved character name appears in narration; the identity-lock prompt is appended to image and video prompts.
- Existing character assignments are not overwritten by the auto-assign action.

**Limit:** matching is literal text-based and may miss alternate spellings, nicknames, or ambiguous mentions. Review auto-assignments before generation.

Validation: `scripts/frontend_check.sh` and `scripts/verify_source.sh` passed, including JavaScript syntax, WebView static security checks, host-native JNI compilation, CI workflow validation, and build-script syntax. No Android APK/device runtime test was performed.
