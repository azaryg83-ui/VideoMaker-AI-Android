# Milestone 91 — Android build workflow hardening

- GitHub Actions permissions are restricted to repository contents read.
- Builds are grouped by ref and superseded runs are cancelled.
- The source verification workflow validates both standard and optional AI-runtime build branches, diagnostics, APK verification and manifest generation.
- Version bumped to 0.58-build-candidate (versionCode 58).

## Validation
- Milestone 91 contract checks cover workflow dispatch, runtime opt-in, build branches, diagnostics, APK verification and manifest generation.
- Actual Android APK build remains pending execution in GitHub Actions.
