# Milestone 79 — Serialized model import

- Added a process-level reservation for model imports so concurrent import requests are rejected with a clear message instead of overlapping copies and competing for storage.
- Import reservation blocks SHA-256 verification, checksum copy, and deletion while a model import is active; integrity verification also checks the import state before reserving.
- Import worker is named and daemonized, and releases the reservation on completion/error.
- Version: `0.47-build-candidate` (versionCode 47).

Checks: `scripts/milestone79_check.py` validates the concurrency contract and UI-independent bridge behavior. Android APK/device behavior still requires Android SDK/NDK and device testing.
