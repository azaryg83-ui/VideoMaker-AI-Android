# VideoMaker AI — Android native shell scaffold

This is a **starter Android wrapper**, not a finished app and not a diffusion engine.
It packages the current web editor in a WebView and exposes a small JavaScript bridge.

## Target device profile
- Redmi Note 14 Pro (user-confirmed)
- MediaTek Helio G100-Ultra
- 8 GB physical RAM
- Android 16

## What this scaffold currently does
- Android Activity + WebView loads the existing editor from app assets.
- `VideoMakerNative.getCapabilities()` returns a JSON status string.
- `VideoMakerNative.engineStatus()` returns `not-integrated`.
- `showMessage()` is a small native bridge demo.

## What is NOT included yet
- No stable-diffusion.cpp binaries or JNI integration.
- No model files.
- No AI inference or image generation.
- No APK build/test performed in this environment.

## Planned next engineering step
1. Build and install this wrapper to validate the WebView/editor on the exact phone.
2. Benchmark device memory/thermal constraints using a safe, non-model workload.
3. Evaluate stable-diffusion.cpp ARM64 CPU inference and the appropriate quantized SD 1.5 model for Helio G100-Ultra.
4. Integrate JNI/native engine only after the benchmark and compatibility evidence.

## Build requirements
Android Studio, Android SDK 35, Gradle, JDK 17, and Android build tools. This scaffold has not been compiled.

## Scaffold update 0.2 (Android file-import compatibility)

- WebView now handles HTML file-input requests with Android's system document picker (`ACTION_OPEN_DOCUMENT`).
- Single and multi-select are supported according to the input element's `multiple` attribute.
- Selected document URIs are returned to WebView through its `ValueCallback<Array<Uri>>`; files are not copied into app storage by this scaffold.
- Native capability report includes device manufacturer/model, Android release, SDK, ABI, and file-picker support.
- Diffusion/image generation remains **not integrated**.

Build/runtime status: not compiled or tested on a physical Android device in this environment. A Gradle/Android SDK build environment was not detected.

## Scaffold update 0.2 (Android file-import compatibility)

- WebView now handles HTML file-input requests with Android's system document picker (`ACTION_OPEN_DOCUMENT`).
- Single and multi-select are supported according to the input element's `multiple` attribute.
- Selected document URIs are returned to WebView through its `ValueCallback<Array<Uri>>`; files are not copied into app storage by this scaffold.
- Native capability report includes device manufacturer/model, Android release, SDK, ABI, and file-picker support.
- Diffusion/image generation remains **not integrated**.

Build/runtime status: not compiled or tested on a physical Android device in this environment. A Gradle/Android SDK build environment was not detected.

## Scaffold update 0.3 (native diagnostics bridge consistency)

- Fixed the JavaScript diagnostic panel to call the actual Android bridge name (`VideoMakerNative`), matching the Kotlin `addJavascriptInterface` registration.
- Native capability report now includes total and available RAM bytes and Android low-memory flag, useful for future AI-model feasibility checks.
- Added explicit native engine status in the capability JSON.
- This is source-level implementation only; not compiled or device-tested here.

## Scaffold update 0.4 (memory + thermal diagnostics)

- Native capability report now includes app heap maximum, used/free heap, and process ID.
- On Android 10/API 29+, reports current thermal status and a readable label.
- Added `VideoMakerNative.getThermalStatus()` for future UI polling before/after heavy image-generation work.
- This is diagnostic groundwork only; no AI inference engine is included.
- Kotlin source has not been compiled in this environment; Android SDK/Gradle build not verified.

## Scaffold update 0.5 (native model-file library groundwork)

- Added Android document-picker entry point dedicated to model imports.
- Model files are copied in streaming mode (1 MiB buffer) to the app-private `files/models` directory; import does not load the file into RAM.
- Current allowed file extensions: GGUF, SafeTensors, CKPT, PT, PTH, ONNX. Extension acceptance is only file-library groundwork and does not assert runtime compatibility with any inference engine.
- Native bridge exposes model inventory, app-private storage free bytes, and file deletion.
- Web UI includes a local model-library inventory and import/delete controls. Browser-only/PWA mode clearly reports that native model import is unavailable.
- No model download is initiated and no model is required at this stage.
- **Important:** diffusion inference remains unintegrated. This does not generate images yet.
- Kotlin/Android build remains uncompiled in this environment; physical-device testing is still required.

## Scaffold update 0.6 (CPU feature/readiness diagnostics)

- Native capability report now reads `/proc/cpuinfo` feature flags where accessible and reports ARM dot-product, FP16, and NEON/ASIMD support.
- Added a WebView readiness panel that displays ABI, CPU flags, and reported RAM as a **preliminary compatibility screen**, not an inference benchmark.
- The UI recommends only a small image-diffusion test profile (SDXS-512, 384–512 px, CPU) if checks look favorable; it explicitly tells users not to download a model until the engine/model combination is confirmed.
- No native diffusion engine or model is bundled. No APK compilation or physical-device test has been performed.

## Scaffold 0.7 — JNI boundary (24 Nov 2026)

Added an Android CMake native shared library and Kotlin JNI boundary (`videomaker_native`). The native library currently reports status only; it does **not** contain stable-diffusion.cpp or generate images. This provides the integration seam for the future ARM64 CPU runtime. Gradle is configured for CMake 3.22.1 and Android native build. This scaffold has not been compiled in an Android SDK/NDK environment.

Next concrete integration step: vendor or fetch a pinned stable-diffusion.cpp revision and its recursive dependencies, configure an Android ARM64 CPU-only build (OpenCL disabled for the Redmi's Mali GPU), then expose model-load and image-generation functions through JNI. The upstream build documentation confirms Android NDK builds and CPU-only build configuration; OpenCL is described as Adreno-specific.

## Scaffold 0.7 — JNI boundary (24 Nov 2026)

Added an Android CMake native shared library and Kotlin JNI boundary (`videomaker_native`). The native library currently reports status only; it does **not** contain stable-diffusion.cpp or generate images. This provides the integration seam for the future ARM64 CPU runtime. Gradle is configured for CMake 3.22.1 and Android native build. This scaffold has not been compiled in an Android SDK/NDK environment.

Next concrete integration step: vendor or fetch a pinned stable-diffusion.cpp revision and its recursive dependencies, configure an Android ARM64 CPU-only build (OpenCL disabled for the Redmi's Mali GPU), then expose model-load and image-generation functions through JNI. The upstream build documentation confirms Android NDK builds and CPU-only build configuration; OpenCL is described as Adreno-specific.


## Scaffold 0.7 — native inference smoke-test adapter (24 Nov 2026)

- Added a JNI `nativeInferenceSmokeTest` entry point for model path, prompt, dimensions, steps, seed and thread count.
- Added optional CMake integration for a local `stable-diffusion.cpp` checkout (`VIDEOMAKER_LINK_SDCPP`, `SDCPP_SOURCE_DIR`).
- The build remains runtime-not-linked by default. The native call returns `NOT_READY` unless the upstream engine is explicitly linked.
- When linked, it performs one image-inference smoke test and reports completion/image count. Generated pixels are not yet exported to the editor; this is an engine integration test, not a finished image-generation feature.
- CPU-only configuration is forced for the Android/Mali path; OpenCL/CUDA are disabled in this integration option.
- No Android APK compilation or device runtime test was performed in this environment.

## Scaffold 0.8 — checked C API smoke-test path (24 Nov 2026)

- Tightened the optional native inference adapter: every C API setter is checked, errors are returned without continuing with partial options, and resources/string handles are cleaned up.
- Added explicit `sd_ctx_prepare()` before image generation to validate/probe model components before the inference attempt.
- Added explicit Euler sampler selection in the smoke test.
- Runtime is still **not linked by default**. This is source-level preparation based on the current upstream C API; it has not been compiled against a pinned upstream revision, Android NDK, or tested on the Redmi.
- Generated image tensor pixels are still not saved/exported into the WebView editor. That is the next integration milestone after confirming the runtime/API build.


## Scaffold 0.9 — generated image payload extraction (source-level)
- Added a JNI generation entry point that retrieves the first image result tensor.
- Validates U8 tensor type, rank, channels, dimensions and byte size before payload encoding.
- Encodes the raw tensor bytes as Base64 with a compact `OK|width|height|channels|payload` protocol.
- Added a Kotlin bridge method with bounded generation settings and model-path validation.
- This is source integration only: stable-diffusion.cpp remains optional/unlinked, and no Android build or on-device inference has been verified.
- The output tensor's channel-memory interpretation still needs confirmation against a compiled runtime before conversion into a displayable bitmap.


## Scaffold 0.10 — native image-to-storyboard attachment (24 Nov 2026)

- Added a native-generation UI panel with model selector, prompt, image size, steps, and CPU thread controls.
- The model selector populates from the Android private model library.
- Added a source-level payload parser for `OK|width|height|channels|base64`, converts interleaved RGB/RGBA bytes into a PNG data URL, and attaches the generated image to the current storyboard scene.
- Updates image-manager and production progress after attachment and schedules project autosave.
- Upstream C API documentation states U8 image tensor dimensions `[channels,width,height]` and interleaved channel storage; this is used by the parser, but still must be confirmed in a compiled runtime/device test.
- The runtime remains optional/unlinked by default. The UI reports that native inference is not ready in current builds.
- JavaScript syntax checked with Node.js. Android/Kotlin/C++ compilation and device test are not available in this environment.


## Scaffold 0.11 — asynchronous native image generation bridge

- Native generation payload calls now have an asynchronous Android bridge entry point.
- Inference runs on a dedicated single-thread executor rather than the WebView/UI thread.
- Results are delivered to the WebView through a callback using safely quoted JS strings.
- The storyboard generation button disables while a request is active and re-enables when the callback returns.
- Native generation parameters are bounded to 256–512 px, 1–20 steps, and 1–6 CPU threads for this UI test path.
- This reduces UI blocking risk, but does not make the diffusion runtime available: stable-diffusion.cpp remains unlinked in the scaffold, and the Android build/runtime is not verified here.
- Validation performed: JavaScript syntax check passed; ZIP integrity check passed. Kotlin/Android compilation and device test were not performed (Android SDK/NDK build environment unavailable).


## Scaffold update 0.13 — upstream C API compatibility + integration build script (24 Nov 2026)

- Removed calls to `sd_ctx_prepare()`. Upstream's latest C API refactor removed this function and now lazily loads model components during generation; leaving the call would break compilation against current upstream.
- CMake now auto-detects a local checkout at `app/src/main/cpp/vendor/stable-diffusion.cpp`, enables linking when present, and sets CPU-only/minimal options (CUDA/OpenCL/Vulkan/Metal/SYCL/MUSA/HIP/RPC off; examples/WebP/WebM off).
- Added `scripts/fetch_and_build_android.sh`: fetches upstream recursively, checks out the selected upstream commit `0d71f96`, updates submodules, then attempts `gradle :app:assembleDebug`. Requires a developer environment with Android NDK and Gradle.
- **Verification:** source-level inspection and JavaScript syntax check only. No Android SDK/NDK/Gradle build available in this environment; therefore no APK or device inference is claimed.
- The selected upstream C API is changing rapidly; the commit pin is intended to make the build reproducible, not to imply that the Android CPU build is already proven.

## Scaffold 0.14 — native payload safety guardrails

- Native image payload generation now independently enforces the same conservative limits as the Kotlin bridge: 256–512 pixels, 1–20 steps, and 1–6 CPU threads.
- Native output accepts only RGB/RGBA U8 image tensors for the editor payload path, and caps dimensions/bytes to keep transfer memory bounded.
- The fetch/build script now checks for NDK, Git, CMake, and Gradle before running, fetches the exact pinned upstream commit, checks out detached, initializes recursive submodules, and verifies the APK output path.
- The upstream CMake target name `stable-diffusion` and the pinned commit were checked against the upstream CMake source. This is still source-level validation only; no Android build or device generation was performed in this environment.

## Scaffold 0.15 — lifecycle and import safeguards

- Corrected a duplicate `onDestroy()` override in `MainActivity`; the generation executor is now shut down from the single lifecycle cleanup method.
- Aligned synchronous smoke-test limits with the native 512 px / 20-step / 6-thread guardrails.
- Aligned synchronous payload-call limits with native limits (512 px and 20 steps).
- Model import now checks declared and streamed file size, available storage, and uses a 6 GB hard cap; an over-limit partial copy is deleted.
- Build script now prefers a project Gradle wrapper when present, otherwise uses system Gradle.

Static checks performed: Kotlin source brace-balance and duplicate lifecycle override check, JavaScript syntax, shell syntax, and ZIP integrity. Android APK compilation and device execution remain unverified because Android SDK/NDK/Gradle are not available in this environment.


## Scaffold 0.16 (atomic model import audit)

- Model import now copies to a temporary file, flushes it, validates declared-vs-copied size when known, then renames into the model directory.
- Existing imported model names are preserved; collisions receive a numbered suffix.
- Partial temporary imports are removed on failure.
- This remains a source-level change; Android compilation/device testing has not been performed in this environment.


## Scaffold 0.17 — native image tensor layout

The native result export now converts the upstream channel-first image tensor `[C, W, H]` into row-major interleaved RGB/RGBA bytes before Base64 encoding. The WebView image attachment code expects interleaved bytes; passing the tensor's original channel-first memory would produce incorrect color/pixel ordering. This source change has not been Android-compiled or device-tested because this environment lacks Gradle and Android NDK.


## Scaffold 0.18 — native build hardening (24 Nov 2026)

- CMake enables position-independent code globally so upstream static objects can be linked into the JNI shared library.
- Android CPU configuration explicitly disables OpenMP and upstream examples/tests to avoid unnecessary desktop runtime assumptions and reduce build scope.
- Fetch/build script now fails early if the pinned checkout lacks the expected CMake target or required C API symbols, before Gradle starts.
- **Validation:** JavaScript syntax, shell syntax, CMake source structure, and ZIP integrity checked. Full Android build remains unverified because this environment has no Android NDK/Gradle.

## 0.19 — compile path (host native check + CI Android build)

- CMake no longer requires the Android `log` library when performing a host-only bridge check.
- `scripts/host_native_check.sh` configures and compiles `native_engine.cpp` as a host JNI shared library using local JDK headers. This validates native C++ syntax and the bridge link in a host environment; it is **not** an Android ABI build.
- `.github/workflows/android-build.yml` provides a GitHub Actions debug APK build using Android SDK platform 35, NDK 27.2.12479018 and CMake 3.22.1, and uploads the APK as a workflow artifact if the build succeeds.
- The Android build workflow must be run in a GitHub repository. No Android SDK/NDK or Gradle is installed in this current environment, and network access to GitHub is unavailable, so the APK has not yet been produced here.
- stable-diffusion.cpp remains unvendored and not linked; image inference is still not functional in this scaffold.


## Scaffold 0.19 — CI toolchain pin and Android build attempt path
- GitHub Actions now explicitly installs Gradle 8.9 (instead of relying on a Gradle CLI being present).
- CI verifies Java, Gradle, Android NDK, and CMake before the APK build step.
- APK build now emits a stack trace on failure for diagnosable CI logs.
- Android app versionCode/versionName advanced to 19 / 0.19-ci-toolchain-build.
- CMake log library variable normalized to `log_lib`.
- Local environment still lacks Gradle/Android SDK, so Android APK compilation remains unverified here.

## Frontend validation (0.22 hardening)

`scripts/frontend_check.sh` validates the web-editor HTML structure, expected editor controls, bundled web assets, and inline JavaScript syntax with Node.js. CI runs this check alongside the host JNI compile. This is a static check only; Chromium/WebView runtime validation is still pending, and it does not establish Android APK build or on-device inference readiness.

## WebView security hardening (0.23)

The Android shell now limits navigation to the bundled editor asset path, disables content access and file-origin/universal file access, and enables Android Safe Browsing where supported. This is a static source-level check only; Kotlin compilation and on-device WebView runtime validation remain pending. App version metadata is advanced to versionCode 20 / versionName 0.20-webview-security.

## Scaffold 0.24 — consolidated source verification

The repository now has `scripts/verify_source.sh` as one local/CI entry point. It runs frontend structure and JavaScript syntax checks, compiles the JNI bridge as a host shared library, and validates shell script syntax. The GitHub Actions host-check job uses this consolidated script to reduce drift between local and CI checks. This is source verification only; it does not claim an Android APK build or device runtime test.


## Scaffold 0.25 — WebView bridge contract and model-import fix

A static bridge-contract check now verifies the editor's native bridge method references against Kotlin methods exposed with `@JavascriptInterface`, and verifies callback names used by the editor are present in the Android shell. This check caught a real integration defect: `requestModelImport()` was missing `@JavascriptInterface`, so the WebView could not call the native model-picker method. The annotation has been added. The frontend verification now reports six editor bridge methods and two callback names checked. Android Kotlin compilation and device runtime behavior remain unverified until an Android build is available. App metadata advances to versionCode 21 / versionName `0.21-webview-bridge-import-fix`.


## Scaffold 0.22 — Offline-first permission hardening

- Removed the Android INTERNET permission from the scaffold because the current editor and model import workflow are local-first and do not require network access.
- Kept cleartext traffic disabled.
- Added a static source check that fails if INTERNET permission is reintroduced or cleartext traffic is enabled.
- Updated Android version metadata to versionCode 22 / versionName 0.22-offline-first-permissions.
- This is a source-level privacy/security hardening; APK compilation and device runtime verification are still pending.

## Scaffold 0.27 — CI Gradle installation made deterministic

- Replaced the Gradle setup action configuration with an explicit pinned Gradle 8.9 distribution download in CI. This avoids relying on a system Gradle executable being present or on an action input that may not install Gradle.
- Added `scripts/ci_workflow_check.py` to statically verify the pinned distribution, Android SDK/NDK configuration, APK assembly, APK verification and artifact upload steps.
- Consolidated CI workflow check and YAML parsing into `scripts/verify_source.sh`.
- Validation: consolidated source verification passed. Android APK build and device runtime remain unverified because this environment lacks Android SDK/NDK and Gradle.


## Scaffold 0.23 — local model integrity
- Model import now computes SHA-256 incrementally while copying, avoiding a second full-file read.
- The digest is stored as a sidecar in app-private storage and shown abbreviated in the model library.
- Removing a model also removes its checksum metadata.
- Static verification checks the digest flow and UI inventory contract.
- This is source/static verification only; Android Kotlin compilation, APK build, and device runtime remain pending.


## Scaffold 0.29 — model-import integrity and isolated host build cache

- Model SHA-256 sidecar writes are now synced to disk before the import is considered complete.
- If checksum metadata cannot be committed, the copied model is removed so the library cannot silently contain an imported model without its integrity record.
- Host JNI CMake build directories are keyed by source-tree path to prevent stale CMake caches from colliding between archived copies and the main working tree.
- Android app version metadata advanced to `versionCode 24`, `versionName 0.24-import-integrity`.
- Consolidated source verification passed: frontend checks, JNI host compilation, CI workflow checks/YAML parsing, and build-script syntax.
- Android APK build and device runtime tests remain pending; the diffusion engine is not integrated.


## Scaffold 0.30 — Native image payload guards

The editor now validates native generated-image payloads before creating a canvas image: integer dimensions are bounded to 512x512, channel count is restricted to RGB/RGBA, base64 decoding is guarded, decoded byte count must match the tensor dimensions and stays within 2 MiB, and canvas context creation is checked. These are frontend static/source checks only; Android runtime generation remains untested and the diffusion runtime is not integrated by default.

## Scaffold 0.32 — WebM voiceover mixing (static verified)

The experimental WebM export now decodes the imported voiceover with Web Audio,
adds its audio track to the MediaRecorder stream, starts audio with recording,
extends export duration when voiceover is longer than the scene timeline, holds
last scene at the end, and stops recorder stream tracks during cleanup. Static
source checks cover these behaviors. Device/WebView runtime export testing is
still pending; this does not establish successful MP4 export or APK compilation.

## Scaffold 0.33 — native model path and thermal safety

- Model filenames received through the JavaScript bridge are validated against a conservative character set; path separators and traversal names are rejected.
- Model paths are canonicalized and constrained to the app-private model library directory, including protection against path redirection.
- Native image-generation calls return a thermal block response when Android reports a severe thermal status (Android 10+), preventing a new generation from starting while the device is in a severe thermal state.
- Consolidated static checks verify these safeguards.
- Android app version metadata was advanced to versionCode 31 / versionName `0.31-native-model-safety`.


**Verification limits:** the consolidated source verification passed. The Kotlin changes have not been compiled because this environment has no Gradle or Android SDK/NDK installed and outbound DNS/network access is unavailable. No APK or Redmi runtime test was produced.


## Build APK (versiunea 0.34 build candidate)

Vezi `BUILD_APK_ON_GITHUB.md` pentru pașii de a declanșa build-ul Android real în GitHub Actions și descărca artifact-ul APK. Build-ul local din această sesiune este blocat de lipsa Android SDK/NDK/Gradle și de DNS extern indisponibil.


## Scaffold 0.34 — build candidate

- CI now provisions Gradle 8.9 using `gradle/actions/setup-gradle@v4` rather than downloading the distribution with a hand-written curl/unzip block.
- Android SDK, NDK, and CMake versions remain pinned in the CI build job.
- APK verification and artifact upload are configured; artifact retention is 30 days.
- Added `BUILD_APK_ON_GITHUB.md` with the exact workflow steps to obtain the real APK.
- App metadata is set to `versionCode 34`, `versionName 0.34-build-candidate`.

**Build status:** source verification passed, but the actual Android APK build is still pending because this execution environment lacks Android SDK/NDK/Gradle and external DNS is unavailable.

## Milestone 38 update

- Offline subtitle segmentation now respects sentence-ending punctuation and semicolon/colon boundaries before the word-count limit.
- Caption timing weights punctuation pauses slightly, while remaining a heuristic (not speech recognition or exact word-level alignment).
- Validation: `bash scripts/verify_source.sh` passes frontend, JNI host compilation, CI workflow YAML, and shell syntax checks.

## Milestone 43 — imported video clips in scenes (mobile editor)
- Scene cards now accept local MP4/WebM/video imports alongside still images.
- Imported video is rendered to the editor canvas preview and captured in experimental canvas export.
- Clip media is included in project save/autosave serialization; restore rebuilds video elements.
- Clip duration can initialize the scene duration; scene duration remains editable.
- Video clip audio is muted in preview/export; the separate voiceover track is the soundtrack.
- This is imported footage support, NOT AI-generated video. Native AI video inference remains unintegrated and untested on the Redmi MediaTek device.
- Validation: frontend static checks and full source verification passed; runtime Android testing is still pending.

## Milestone 47
Automatic shot type suggestion for scenes is available. It analyzes scene text and recommends wide, close-up, detail, establishing, crowd, atmosphere, action-wide, or medium framing. Suggestions are editable and persisted in the project. This is a planning heuristic, not AI generation.


## Milestone 48 — Character Consistency Foundation
Create a character with a fixed physical description and optional reference image, assign it scene-by-scene, and preserve character identity details in project autosave, JSON, prompts, and storyboard character bible. Exact face consistency still requires a compatible reference-conditioned generation engine; the current feature prepares and preserves identity references but does not guarantee identical generated faces.


## Milestone 49 — Structured character identity profiles
Character profiles now capture physical traits in separate fields (age, height, body build, posture, skin, eyes, hair color/length/style, facial hair, tattoos, scars, marks and baseline clothing), assembled into persistent identity lock prompts and character-bible exports. See `MILESTONE_49.md`.

## Milestone 50 — controlled character evolution

Character Manager now supports named timeline variants (age, body/weight, hair color/length/style, facial hair, clothing and additional notes). Scenes can select a character variant while preserving the base identity lock; variants are stored with the project and included in Character Bible export. See `MILESTONE_50.md`.

## Milestone 51
Existing saved character profiles can now be edited. Edit loads all structured identity fields, saves updates in place, preserves variants and scene assignments, and preserves the existing reference image unless a new one is selected.

## Milestone 52
Character continuity audit and repair: check scene assignments, image/video identity-lock prompts, character name mentions without assignment, missing reference images, stale variant IDs; reapply identity prompts to assigned scenes and export a TXT audit report.


## Milestone 53 — Character Scene Coverage

Character coverage reporting now counts assigned scenes and literal name mentions in narration, flags estimated unassigned mentions, exports a TXT report, and optionally auto-assigns mentioned saved characters to unassigned scenes while adding identity-lock prompts. Auto-assignment is text-based and must be reviewed. See `MILESTONE_53.md`.


## Milestone 54 — Detailed Production Preflight Audit

A deeper pre-export audit now checks scene durations, visual prompts, missing images, subtitle cue boundaries, scene text, advisory character continuity, and format/FPS settings. Results are displayed in the production panel and exportable as a TXT report. Findings are advisory and the character check is heuristic. See `MILESTONE_54.md`.

## Milestone 55
Voiceover duration estimation per scene, with adjustable speaking pace and pause allowance; estimates may be applied to scene durations. See `MILESTONE_55.md`.

## Milestone 57

Multi-shot storyboard editor: auto-create editable shot sequences per scene; change shot type, duration, motion, transition and prompt; add/delete shots; evenly distribute scene duration; export storyboard TXT. This remains a planning feature and does not generate video clips.

## Milestone 58
Storyboard timeline visualization and shot reordering controls added. See `MILESTONE_58.md`.

## Milestone 59
- Video export progress reporting and cancellation; existing recorder pathway retained.


## Milestone 61
- Local model import now performs basic extension/signature/header checks and model inventory reports `formatCheck`. These are preliminary file checks only; model architecture compatibility and AI inference are not yet integrated. See `MILESTONE_61.md`.

## Milestone 62
Device diagnostics now report Android low-memory threshold and available private model storage. The native AI readiness panel estimates a conservative model memory budget using current free RAM and the app heap limit, and shows thermal status. This remains planning guidance only; diffusion runtime is not integrated and no Android device inference test has been performed.

## Milestone 91 — Android build workflow hardening

GitHub Actions now uses read-only repository permissions and cancels superseded runs for the same ref. Source verification checks the standard APK build path, optional stable-diffusion.cpp build path, diagnostics upload, APK structure verification, and build manifest/checksum generation. Actual Android APK compilation remains pending. See `MILESTONE_91.md`.
