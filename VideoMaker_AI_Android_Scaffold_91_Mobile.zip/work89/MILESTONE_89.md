# Milestone 89 — Android runtime build diagnostics

- Android build output is captured to a CI log artifact (with `pipefail`, so failed builds remain failures).
- An always-run diagnostic collection step records Java/Gradle/CMake versions, SDK/NDK paths, runtime pin and submodule state, ABI/version configuration, and any available CMake cache files.
- Diagnostics are uploaded separately even when the build fails, making runtime build failures easier to inspect and fix.
- App version: 0.56-build-candidate (versionCode 56).

## Validation
- Static checks validate log capture, always-run diagnostic collection, artifact upload, and version bump.
- No Android APK/runtime build was executed in this environment.
