# Milestone 70 — Scene-safe asynchronous image attachment

- Captures the scene index and prompt at generation start.
- Attaches a late-arriving generated image to the originally requested scene, even if the user navigates to another scene during generation.
- Captures the prompt used at request time instead of reading the possibly changed prompt field at callback time.
- Adds a dedicated source-contract checker for this behavior.
- Version updated to 0.39-build-candidate / versionCode 39.

Validation: source contract checker passed. This is a source-level check; Android APK build and real model inference remain unavailable in the current environment.
