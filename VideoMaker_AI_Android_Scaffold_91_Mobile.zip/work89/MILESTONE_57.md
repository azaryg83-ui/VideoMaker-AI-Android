# Milestone 57 — Multi-shot Storyboard Editor

Added a scene-level storyboard editor that can split each scene into up to four suggested shot beats based on sentence boundaries (or a two-part split when a scene has one sentence).

Features:
- Generate a storyboard for scenes that do not already have shot sequences; existing shot sequences are preserved.
- Edit each shot's type, duration, camera motion, transition and prompt text.
- Add and delete shots per scene.
- Re-distribute a scene's duration evenly across its shots.
- Export all scenes and shot metadata to a TXT storyboard.
- Shot data is stored on scene objects, so it follows the project's existing scene autosave/persistence path.

Limitations:
- This is a planning/editor feature. It does not generate video clips, perform actual transitions, or render each shot as separate timeline media yet.
- Duration allocation and shot suggestions are heuristic and editable.
- No APK/device runtime test was performed.

Validation: `scripts/verify_source.sh` passed, including frontend/static security checks, bridge contract, privacy checks, model integrity checks, native safety checks, WebM audio export static checks, motion heuristic checks, host JNI compilation, Android CI workflow configuration, and build script syntax.
