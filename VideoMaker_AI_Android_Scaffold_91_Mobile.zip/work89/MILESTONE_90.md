# Milestone 90 — APK build manifest and integrity record

- CI now creates a structured build manifest for each successful debug APK.
- Manifest records APK filename, byte size, SHA-256, version code/name, commit, UTC build timestamp, and build type.
- SHA256SUMS file is emitted alongside the manifest.
- A dedicated script is used by CI and can be run locally against an APK.
- App version: 0.57-build-candidate (versionCode 57).

## Validation
- Static milestone checks and a dummy APK execution test passed.
- Android APK/runtime build was not executed in this environment.
