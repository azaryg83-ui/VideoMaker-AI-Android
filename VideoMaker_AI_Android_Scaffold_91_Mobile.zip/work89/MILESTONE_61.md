# Milestone 61 — Local Model File Validation

## Changes
- Added a quick file-format/header check for imported local AI model files before copying them into app-private storage.
- GGUF: verifies `GGUF` magic bytes.
- SafeTensors: checks that the little-endian header-length field is plausible and within the file / 100 MB limit (not full JSON tensor validation).
- PT/PTH/CKPT: accepts ZIP-container or pickle-protocol signatures as a basic file check.
- ONNX: only checks that the file has a minimum byte length; ONNX protobuf validity is not confirmed.
- Model inventory now includes a `formatCheck` status for previously imported files.
- Import status reports the check level and reminds users that the inference engine remains unintegrated.

## Safety / limitations
- These checks detect obvious extension/content mismatches only. They do not parse model tensors, validate model architecture, certify safety, or prove compatibility with a future inference runtime.
- Native diffusion inference is still not integrated. No model is downloaded automatically.
- Android runtime / device tests were not performed.

## Validation performed
- `scripts/frontend_check.sh`
- `scripts/bridge_contract_check.py`
- `scripts/ci_workflow_check.py`
- `scripts/host_native_check.sh`
- `scripts/verify_source.sh`
- Additional source presence check for the new model format validation helper and import guard.
