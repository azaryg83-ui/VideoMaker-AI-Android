# Milestone 77 — Safe model deletion

- Model deletion now uses the shared canonical-path resolver rather than stripping path separators.
- Rejects deletion while a SHA-256 integrity verification is active.
- Requires an existing regular model file.
- Sidecar checksum deletion is constrained to the canonical private models directory.
- Returns structured status codes and user-readable messages; the WebView displays the actual result instead of assuming success.
- Version: 0.45-build-candidate (versionCode 45).

Android APK/device testing is not performed in this environment.
