# Milestone 68 — Gradle-to-CMake Runtime Link Switch

- Added a Gradle property `videomakerLinkSdcpp` that explicitly controls native runtime linking.
- Normal scaffold builds keep the runtime OFF by default to avoid accidental heavyweight dependency builds.
- The pinned Android runtime build script opts into linking with `-PvideomakerLinkSdcpp=true`.
- CMake retains a hard error when runtime linking is requested but the upstream source tree is missing.
- Android APK build/inference still requires SDK/NDK and has not been executed on a device in this environment.

- Android app version advanced to `0.38-build-candidate` / versionCode 38.
