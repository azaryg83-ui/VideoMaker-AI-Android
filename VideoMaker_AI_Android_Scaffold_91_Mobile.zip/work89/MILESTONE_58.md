# Milestone 58 — Storyboard Shot Timeline & Reordering

Built on Scaffold 57.

## Added
- Storyboard multi-shot timeline strip with proportional shot blocks based on duration.
- Timeline displays scene/shot identifiers and shot duration.
- Per-shot move-up and move-down controls reorder shots within the same scene.
- Reordering updates the underlying scene shot array and uses the existing autosave path.
- Timeline totals aggregate all storyboard shot durations.
- Existing shot edit, add, delete, and equalize controls remain available.

## Limitations
- Timeline is a visual planning timeline, not a full video-media timeline or drag-trim editor.
- Reordering is limited to shots within the same scene.
- No actual clips, rendering, transitions, or Android device runtime test are performed by this milestone.

## Validation
`scripts/verify_source.sh` passed: frontend/static WebView security, bridge contract, offline/privacy checks, model integrity and native safety checks, native image payload guard, WebM audio export static checks, motion heuristic checks, host JNI compilation, Android CI configuration, and build-script syntax.
