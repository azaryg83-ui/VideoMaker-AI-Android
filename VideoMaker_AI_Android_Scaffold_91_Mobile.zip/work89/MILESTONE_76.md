# Milestone 76 — Model SHA-256 copy action

- Added Android bridge action `copyModelSha256(fileName)`.
- Reuses the private-library safe file-name/path validator.
- Validates saved SHA-256 sidecar before copying.
- Copies the full fingerprint to Android clipboard and shows a Toast.
- UI displays the copy button only for models with a saved checksum and handles missing/invalid fingerprints.
- Updated app candidate version to 0.44-build-candidate (versionCode 44).
- Added milestone76_check.py and included it in verify_source.sh.
- Updated milestone 74/75 version assertions to follow the candidate version.

Verification: frontend static checks, WebView checks, bridge contract, JNI host compilation, CI workflow checks, build-script syntax, milestone checks 66, 69-76 all passed. Android APK build/device runtime testing not performed because Android SDK/NDK are unavailable in this execution environment.
