package com.videomakerai.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedInputStream
import java.security.MessageDigest
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.SynchronousQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private var nativeLibraryLoaded = false
    private val modelIntegrityVerificationActive = AtomicBoolean(false)
    private val modelImportActive = AtomicBoolean(false)
    private val modelFileOperationLock = Any()
    private val nativeGenerationExecutor = ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, SynchronousQueue<Runnable>(), { r -> Thread(r, "VideoMakerNativeGeneration").apply { isDaemon = true } })
    private external fun nativeStatus(): String
    private external fun nativeRuntimeInfo(): String
    private external fun nativeGenerateSmokeTest(modelPath: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String
    private external fun nativeGenerateImagePayload(modelPath: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String
    companion object {
        init { try { System.loadLibrary("videomaker_native") } catch (_: Throwable) { } }
    }
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 701
    private val modelPickerRequest = 702
    private val modelExtensions = setOf("gguf", "safetensors", "ckpt", "pt", "pth", "onnx")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nativeLibraryLoaded = try { nativeStatus().isNotBlank() } catch (_: Throwable) { false }
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // This editor is bundled in app assets. Keep file access enabled only for the
        // packaged editor and block navigation away from that trusted origin.
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) webView.settings.safeBrowsingEnabled = true
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = params.acceptTypes.firstOrNull()?.takeIf { it.isNotBlank() } ?: "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, params.acceptTypes.filter { it.isNotBlank() }.toTypedArray())
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (e: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    Toast.makeText(this@MainActivity, "Nu pot deschide selectorul de fișiere.", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            private val trustedEditorPrefix = "file:///android_asset/web/"
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                // Prevent the JavaScript bridge from being exposed to arbitrary pages.
                return !url.startsWith(trustedEditorPrefix)
            }
            @Deprecated("Deprecated on newer Android versions")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return !url.startsWith(trustedEditorPrefix)
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "VideoMakerNative")
        setContentView(webView)
        val recoveredTempFiles = cleanupInterruptedModelImports()
        if (recoveredTempFiles > 0) Toast.makeText(this, "Recuperare spațiu: $recoveredTempFiles fișiere temporare eliminate.", Toast.LENGTH_LONG).show()
        webView.loadUrl("file:///android_asset/web/index.html")
    }

    @Deprecated("Activity result API retained for compatibility with this minimal scaffold")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == modelPickerRequest) {
            if (resultCode == RESULT_OK && data?.data != null) importModelUri(data.data!!)
            else runOnUiThread { webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Import anulat.');", null) }
            return
        }
        if (requestCode != filePickerRequest) return
        val callback = fileChooserCallback ?: return
        fileChooserCallback = null
        if (resultCode != RESULT_OK || data == null) {
            callback.onReceiveValue(null)
            return
        }
        val uris = data.clipData?.let { clip ->
            Array(clip.itemCount) { index -> clip.getItemAt(index).uri }
        } ?: data.data?.let { arrayOf(it) }
        callback.onReceiveValue(uris)
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun getCapabilities(): String {
            val info = JSONObject()
            info.put("nativeShell", true)
            info.put("diffusionEngine", false)
            info.put("nativeBridgeLibraryLoaded", nativeLibraryLoaded)
            info.put("nativeBridgeStatus", if (nativeLibraryLoaded) nativeStatus() else "native-library-not-loaded")
            info.put("nativeRuntimeInfo", if (nativeLibraryLoaded) nativeRuntimeInfo() else "JNI library unavailable")
            info.put("status", "android-shell-jni-boundary")
            info.put("manufacturer", Build.MANUFACTURER)
            info.put("model", Build.MODEL)
            info.put("androidVersion", Build.VERSION.RELEASE)
            info.put("sdk", Build.VERSION.SDK_INT)
            info.put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown")
            val cpuInfo = try { File("/proc/cpuinfo").readText() } catch (_: Exception) { "" }
            val cpuFlags = Regex("(?im)^\\s*(Features|flags)\\s*:\\s*(.+)$").findAll(cpuInfo)
                .map { it.groupValues[2].lowercase().split(Regex("\\s+")) }.flatten().toSet()
            info.put("cpuDotprod", cpuFlags.contains("asimddp") || cpuFlags.contains("dotprod"))
            info.put("cpuFp16", cpuFlags.contains("fphp") || cpuFlags.contains("asimdhp"))
            info.put("cpuNeon", cpuFlags.contains("asimd") || cpuFlags.contains("neon"))
            info.put("cpuFeatureDetection", if (cpuFlags.isEmpty()) "unavailable" else "read-from-proc-cpuinfo")
            info.put("webViewFilePicker", true)
            val activityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            info.put("totalRamBytes", memoryInfo.totalMem)
            info.put("availableRamBytes", memoryInfo.availMem)
            info.put("lowMemory", memoryInfo.lowMemory)
            info.put("ramThresholdBytes", memoryInfo.threshold)
            info.put("availableModelStorageBytes", android.os.StatFs(filesDir.absolutePath).availableBytes)
            info.put("engineStatus", "not-integrated")
            info.put("modelImportSupport", true)
            info.put("modelsStoredPrivately", true)
            info.put("modelImportFormats", "gguf,safetensors,ckpt,pt,pth,onnx")
            val runtime = Runtime.getRuntime()
            info.put("appMaxHeapBytes", runtime.maxMemory())
            info.put("appUsedHeapBytes", runtime.totalMemory() - runtime.freeMemory())
            info.put("appFreeHeapBytes", runtime.freeMemory())
            info.put("processId", Process.myPid())
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.put("thermalStatus", powerManager.currentThermalStatus)
                info.put("thermalStatusLabel", thermalLabel(powerManager.currentThermalStatus))
            } else {
                info.put("thermalStatus", -1)
                info.put("thermalStatusLabel", "unsupported")
            }
            info.put("note", "Native shell diagnostics available; AI engine not integrated")
            return info.toString()
        }

        @JavascriptInterface
        fun engineStatus(): String = if (nativeLibraryLoaded) nativeStatus() else "native-library-not-loaded; diffusion-runtime-not-integrated"

        @JavascriptInterface
        fun nativeInferenceSmokeTest(modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String {
            if (!nativeLibraryLoaded) return "ERROR: native bridge unavailable"
            val model = safeModelFile(modelFileName)
                ?: return "ERROR: invalid model filename or model path outside private library"
            if (!model.exists() || !model.isFile) return "ERROR: model file not found in app-private models folder"
            val requestError = validateNativeGenerationRequest(prompt, width, height, steps, threads)
            if (requestError != null) return "ERROR: $requestError"
            return try { nativeGenerateSmokeTest(model.absolutePath, prompt, width, height, steps, seed, threads) }
            catch (e: Throwable) { "ERROR: ${e.message ?: "native call failed"}" }
        }

        @JavascriptInterface
        fun getThermalStatus(): String {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "unsupported"
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            return thermalLabel(powerManager.currentThermalStatus)
        }

        @JavascriptInterface
        fun nativeGenerateImagePayloadAsync(callbackId: String, modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int) {
            val safeCallbackId = callbackId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64)
            if (safeCallbackId.isBlank()) return
            if (!nativeLibraryLoaded) {
                deliverNativeGenerationResult(safeCallbackId, "NOT_READY|native library not loaded")
                return
            }
            val model = safeModelFile(modelFileName)
            if (model == null || !model.exists() || !model.isFile) {
                deliverNativeGenerationResult(safeCallbackId, "ERROR|invalid model filename or model path outside private library")
                return
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val thermal = (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus
                if (thermal >= PowerManager.THERMAL_STATUS_SEVERE) {
                    deliverNativeGenerationResult(safeCallbackId, "THERMAL_BLOCKED|phone thermal status is severe; cool the device before generating")
                    return
                }
            }
            val requestError = validateNativeGenerationRequest(prompt, width, height, steps, threads)
            if (requestError != null) {
                deliverNativeGenerationResult(safeCallbackId, "ERROR|$requestError")
                return
            }
            val safeWidth = width
            val safeHeight = height
            val safeSteps = steps
            val safeThreads = threads
            try {
                nativeGenerationExecutor.execute {
                    val result = try {
                        this@MainActivity.nativeGenerateImagePayload(model.absolutePath, prompt.take(4000), safeWidth, safeHeight, safeSteps, seed, safeThreads)
                    } catch (e: Throwable) {
                        "ERROR|${e.message ?: "native generation failed"}"
                    }
                    deliverNativeGenerationResult(safeCallbackId, result)
                }
            } catch (_: RejectedExecutionException) {
                deliverNativeGenerationResult(safeCallbackId, "BUSY|an image generation is already running; wait for it to finish")
            }
        }

        private fun deliverNativeGenerationResult(callbackId: String, payload: String) {
            runOnUiThread {
                val quotedId = JSONObject.quote(callbackId)
                val quotedPayload = JSONObject.quote(payload)
                webView.evaluateJavascript("window.onNativeGenerationResult && window.onNativeGenerationResult($quotedId,$quotedPayload);", null)
            }
        }

        @JavascriptInterface
        fun nativeGenerateImagePayload(modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String {
            if (!nativeLibraryLoaded) return "NOT_READY|native library not loaded"
            val safeName = modelFileName.replace("/", "").replace("\\", "")
            val model = File(modelsDirectory(), safeName)
            if (!model.exists() || !model.isFile) return "ERROR|model file not found in app-private models folder"
            val requestError = validateNativeGenerationRequest(prompt, width, height, steps, threads)
            if (requestError != null) return "ERROR|$requestError"
            return try { this@MainActivity.nativeGenerateImagePayload(model.absolutePath, prompt, width, height, steps, seed, threads) }
            catch (e: Throwable) { "ERROR|${e.message ?: "native generation failed"}" }
        }

        @JavascriptInterface
        fun requestModelImport() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                try { startActivityForResult(intent, modelPickerRequest) }
                catch (e: Exception) { webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Selector de fișiere indisponibil.');", null) }
            }
        }

        @JavascriptInterface
        fun listModels(): String = modelListJson()

        @JavascriptInterface
        fun verifyModelIntegrity(callbackId: String, fileName: String) {
            val safeCallbackId = callbackId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64)
            if (safeCallbackId.isBlank()) return
            val model = safeModelFile(fileName)
            if (model == null || !model.exists() || !model.isFile) {
                deliverModelIntegrityResult(safeCallbackId, fileName, "INVALID_FILE", "Fișierul model nu este găsit în biblioteca privată.")
                return
            }
            val reserved = synchronized(modelFileOperationLock) {
                !modelImportActive.get() && modelIntegrityVerificationActive.compareAndSet(false, true)
            }
            if (!reserved) {
                deliverModelIntegrityResult(safeCallbackId, model.name, "BUSY", "O altă verificare SHA-256 este în desfășurare. Așteaptă să se termine.")
                return
            }
            Thread {
                val result = try {
                    synchronized(modelFileOperationLock) {
                    if (!model.exists() || !model.isFile) return@synchronized "INVALID_FILE" to "Modelul nu mai există în biblioteca privată."
                    val sidecar = File(modelsDirectory(), model.name + ".sha256")
                    val expected = if (sidecar.exists()) sidecar.readText().trim().lowercase() else ""
                    if (!expected.matches(Regex("[a-f0-9]{64}"))) {
                        "NO_CHECKSUM" to "Nu există o amprentă SHA-256 validă salvată la import."
                    } else {
                        val digest = MessageDigest.getInstance("SHA-256")
                        model.inputStream().use { input ->
                            val buffer = ByteArray(1024 * 1024)
                            while (true) {
                                val read = input.read(buffer)
                                if (read < 0) break
                                digest.update(buffer, 0, read)
                            }
                        }
                        val actual = digest.digest().joinToString("") { "%02x".format(it) }
                        if (MessageDigest.isEqual(expected.toByteArray(Charsets.US_ASCII), actual.toByteArray(Charsets.US_ASCII)))
                            "MATCH" to "Integritate confirmată: SHA-256 coincide cu amprenta de la import."
                        else "MISMATCH" to "ALERTĂ: amprenta SHA-256 nu coincide. Fișierul poate fi modificat sau deteriorat. Nu îl folosi."
                    }
                    }
                } catch (e: Exception) {
                    "ERROR" to ("Verificare nereușită: " + (e.message ?: "eroare de citire"))
                }
                deliverModelIntegrityResult(safeCallbackId, model.name, result.first, result.second)
                modelIntegrityVerificationActive.set(false)
            }.apply { isDaemon = true; name = "VideoMakerModelIntegrity" }.start()
        }

        private fun deliverModelIntegrityResult(callbackId: String, modelName: String, code: String, message: String) {
            runOnUiThread {
                val id = JSONObject.quote(callbackId)
                val name = JSONObject.quote(modelName)
                val status = JSONObject.quote(code)
                val text = JSONObject.quote(message)
                webView.evaluateJavascript("window.onNativeModelIntegrityResult && window.onNativeModelIntegrityResult($id,$name,$status,$text);", null)
            }
        }

        @JavascriptInterface
        fun copyModelSha256(fileName: String): String = synchronized(modelFileOperationLock) {
            val model = safeModelFile(fileName) ?: return@synchronized "INVALID_FILE"
            if (modelIntegrityVerificationActive.get() || modelImportActive.get()) return@synchronized "BUSY"
            val sidecar = File(modelsDirectory(), model.name + ".sha256")
            val checksum = if (sidecar.exists() && sidecar.isFile) sidecar.readText().trim().lowercase() else ""
            if (!checksum.matches(Regex("[a-f0-9]{64}"))) return@synchronized "NO_CHECKSUM"
            runOnUiThread {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("SHA-256 ${model.name}", checksum))
                Toast.makeText(this@MainActivity, "SHA-256 copiat în clipboard", Toast.LENGTH_SHORT).show()
            }
            "COPIED"
        }

        @JavascriptInterface
        fun deleteModel(fileName: String): String = synchronized(modelFileOperationLock) {
            if (modelIntegrityVerificationActive.get() || modelImportActive.get()) {
                return@synchronized JSONObject().put("deleted", false).put("code", "BUSY")
                    .put("message", "O verificare SHA-256 este în desfășurare. Așteaptă să se termine înainte de ștergere.")
                    .put("models", modelListJson()).toString()
            }
            val file = safeModelFile(fileName)
            if (file == null || !file.exists() || !file.isFile) {
                return@synchronized JSONObject().put("deleted", false).put("code", "INVALID_FILE")
                    .put("message", "Fișierul model nu este găsit sau numele nu este valid.")
                    .put("models", modelListJson()).toString()
            }
            val deleted = try { file.delete() } catch (_: SecurityException) { false }
            var checksumDeleted = false
            if (deleted) {
                val sidecar = File(modelsDirectory(), file.name + ".sha256").canonicalFile
                if (sidecar.parentFile == modelsDirectory().canonicalFile && sidecar.isFile) {
                    checksumDeleted = try { sidecar.delete() } catch (_: SecurityException) { false }
                }
            }
            JSONObject().put("deleted", deleted).put("code", if (deleted) "DELETED" else "DELETE_FAILED")
                .put("checksumDeleted", checksumDeleted)
                .put("message", if (deleted) "Model șters din spațiul privat al aplicației." else "Nu am putut șterge fișierul model. Am păstrat amprenta SHA-256.")
                .put("models", modelListJson()).toString()
        }

        @JavascriptInterface
        fun showMessage(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(180), Toast.LENGTH_SHORT).show() }
        }
    }



    private fun validateNativeGenerationRequest(prompt: String, width: Int, height: Int, steps: Int, threads: Int): String? {
        if (prompt.isBlank()) return "prompt is empty"
        if (prompt.length > 4000) return "prompt exceeds 4000 characters"
        if (width !in 256..512 || height !in 256..512) return "image dimensions must be between 256 and 512 pixels"
        if (steps !in 1..20) return "steps must be between 1 and 20"
        if (threads !in 1..6) return "threads must be between 1 and 6"
        return null
    }

    private fun safeModelFile(fileName: String): File? {
        if (fileName.isBlank() || fileName == "." || fileName == ".." ||
            fileName.contains("/") || fileName.contains("\\") ||
            !fileName.matches(Regex("[A-Za-z0-9._() -]{1,180}"))) return null
        val dir = modelsDirectory().canonicalFile
        val candidate = File(dir, fileName).canonicalFile
        if (candidate.parentFile != dir) return null
        return candidate
    }

    private fun modelsDirectory(): File = File(filesDir, "models").apply { if (!exists()) mkdirs() }

    /** Remove only temp artifacts created by this app's model import pipeline. */
    private fun cleanupInterruptedModelImports(): Int {
        val dir = modelsDirectory()
        val candidates = dir.listFiles()?.filter { file ->
            file.isFile && (file.name.startsWith(".import-") && file.name.endsWith(".tmp") || file.name.startsWith(".") && file.name.endsWith(".sha256.tmp"))
        } ?: emptyList()
        var removed = 0
        for (file in candidates) {
            try { if (file.delete()) removed++ } catch (_: Exception) { }
        }
        return removed
    }

    private fun modelFormatCheck(file: File): String {
        val ext = file.extension.lowercase()
        if (!file.exists() || !file.isFile || file.length() <= 0) return "empty-or-missing"
        val head = ByteArray(8)
        val count = try { file.inputStream().use { it.read(head) } } catch (_: Exception) { return "unreadable" }
        return when (ext) {
            "gguf" -> if (count >= 4 && String(head, 0, 4, Charsets.US_ASCII) == "GGUF") "signature-ok" else "signature-mismatch"
            "safetensors" -> {
                if (count < 8) "signature-mismatch" else {
                    val headerLen = java.nio.ByteBuffer.wrap(head, 0, 8).order(java.nio.ByteOrder.LITTLE_ENDIAN).long
                    if (headerLen in 2..(file.length() - 8) && headerLen <= 100L * 1024 * 1024) "header-length-ok" else "signature-mismatch"
                }
            }
            "pt", "pth", "ckpt" -> if (count >= 2 && ((head[0].toInt() and 0xff) == 0x50 && (head[1].toInt() and 0xff) == 0x4b || (head[0].toInt() and 0xff) == 0x80)) "container-signature-ok" else "signature-mismatch"
            "onnx" -> if (file.length() >= 16) "protobuf-file-size-ok-unverified" else "signature-mismatch"
            else -> "unsupported"
        }
    }

    private fun modelGenerationReadiness(file: File): String {
        val format = file.extension.lowercase()
        val signature = modelFormatCheck(file)
        if (signature == "empty-or-missing" || signature == "unreadable" || signature == "signature-mismatch") return "invalid-file"
        if (format == "gguf") return "not-diffusion-checkpoint: GGUF is not supported by this image-generation bridge"
        if (format == "onnx") return "unverified-onnx: model graph and runtime compatibility must be confirmed"
        if (format == "safetensors") return "pipeline-component: a single file may be only one component of a diffusion pipeline"
        if (format in setOf("pt", "pth", "ckpt")) return "legacy-checkpoint: compatibility and safety are not guaranteed"
        return "unsupported-format"
    }

    private fun modelListJson(): String {
        val dir = modelsDirectory()
        val engineLinked = try { nativeLibraryLoaded && nativeRuntimeInfo().contains("stable-diffusion.cpp C API linked") } catch (_: Throwable) { false }
        val files = dir.listFiles()?.filter { it.isFile && !it.name.startsWith(".") && !it.name.endsWith(".sha256") }?.map { f ->
            val checksumFile = File(dir, f.name + ".sha256")
            val checksum = if (checksumFile.exists()) checksumFile.readText().trim().takeIf { it.matches(Regex("[a-fA-F0-9]{64}")) } else null
            JSONObject().put("name", f.name).put("sizeBytes", f.length()).put("extension", f.extension.lowercase())
                .put("sha256", checksum ?: JSONObject.NULL).put("formatCheck", modelFormatCheck(f))
                .put("generationReadiness", modelGenerationReadiness(f))
                .put("candidateForNativeDiffusion", f.extension.lowercase() in setOf("safetensors", "ckpt", "pt", "pth") && modelFormatCheck(f) !in setOf("signature-mismatch", "empty-or-missing", "unreadable"))
                .put("engineLinked", engineLinked)
        } ?: emptyList()
        val stat = android.os.StatFs(filesDir.absolutePath)
        val totalModelStorageBytes = files.sumOf { it.getLong("sizeBytes") }
        return JSONObject().put("models", org.json.JSONArray(files)).put("count", files.size)
            .put("totalModelStorageBytes", totalModelStorageBytes)
            .put("totalAppStorageBytes", stat.totalBytes)
            .put("freeAppStorageBytes", stat.availableBytes).put("storagePath", "app-private/models")
            .put("engineIntegrated", engineLinked).put("nativeStatus", if (nativeLibraryLoaded) nativeStatus() else "native-library-not-loaded").toString()
    }

    private fun importModelUri(uri: Uri) {
        val importReserved = synchronized(modelFileOperationLock) {
            !modelIntegrityVerificationActive.get() && modelImportActive.compareAndSet(false, true)
        }
        if (!importReserved) {
            runOnUiThread { webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Un import de model este deja în desfășurare. Așteaptă să se termine.');", null) }
            return
        }
        webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Import în curs; copierea se face în spațiul privat al aplicației…');", null)
        Thread {
            var status = "Import eșuat."
            try {
                val name = queryDisplayName(uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in modelExtensions) throw IllegalArgumentException("Format neacceptat. Acceptăm: GGUF, SafeTensors, ONNX, CKPT/PT/PTH.")
                // Quick source signature/header check before copying; ONNX is size-only because protobuf has no fixed magic.
                val sourceCheck = try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val head = ByteArray(8); val read = input.read(head)
                        when (ext) {
                            "gguf" -> if (read >= 4 && String(head, 0, 4, Charsets.US_ASCII) == "GGUF") "signature-ok" else "signature-mismatch"
                            "safetensors" -> if (read >= 8) {
                                val len = java.nio.ByteBuffer.wrap(head, 0, 8).order(java.nio.ByteOrder.LITTLE_ENDIAN).long
                                if (len in 2..100L*1024*1024) "header-length-ok" else "signature-mismatch"
                            } else "signature-mismatch"
                            "pt", "pth", "ckpt" -> if (read >= 2 && (((head[0].toInt() and 0xff)==0x50 && (head[1].toInt() and 0xff)==0x4b) || (head[0].toInt() and 0xff)==0x80)) "container-signature-ok" else "signature-mismatch"
                            "onnx" -> if (read >= 8) "protobuf-file-size-ok-unverified" else "signature-mismatch"
                            else -> "unsupported"
                        }
                    } ?: "unreadable"
                } catch (_: Exception) { "unreadable" }
                if (sourceCheck == "signature-mismatch" || sourceCheck == "unreadable") throw IllegalArgumentException("Fișierul nu pare valid pentru extensia .$ext (verificare antifișier greșit).")
                val dir = modelsDirectory()
                val available = android.os.StatFs(filesDir.absolutePath).availableBytes
                val declaredSize = try {
                    contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
                    } ?: -1L
                } catch (_: Exception) { -1L }
                val maxModelBytes = 6L * 1024 * 1024 * 1024
                val storageReserveBytes = 256L * 1024 * 1024
                val usableForImport = (available - storageReserveBytes).coerceAtLeast(0L)
                if (declaredSize > maxModelBytes || (declaredSize > 0 && declaredSize > usableForImport))
                    throw IllegalArgumentException("Import refuzat: păstrează minimum 256 MB spațiu liber; modelul depășește spațiul sigur disponibil (limită 6 GB).")
                // Preserve existing models: choose a unique final name and copy to a temporary file first.
                var finalName = name
                var target = File(dir, finalName)
                var suffix = 1
                while (target.exists()) {
                    val stem = name.substringBeforeLast('.', name)
                    val extension = name.substringAfterLast('.', "")
                    finalName = if (extension.isNotBlank()) "$stem ($suffix).$extension" else "$name ($suffix)"
                    target = File(dir, finalName)
                    suffix++
                }
                val temp = File(dir, ".import-${System.currentTimeMillis()}-$finalName.tmp")
                val digest = MessageDigest.getInstance("SHA-256")
                var total = 0L
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        BufferedInputStream(input).use { buffered ->
                            FileOutputStream(temp).use { output ->
                                val buffer = ByteArray(1024 * 1024)
                                while (true) {
                                    val read = buffered.read(buffer)
                                    if (read < 0) break
                                    total += read
                                    val currentAvailable = android.os.StatFs(filesDir.absolutePath).availableBytes
                                    if (total > maxModelBytes || total > usableForImport || read > (currentAvailable - storageReserveBytes).coerceAtLeast(0L)) {
                                        throw IllegalArgumentException("Import oprit: modelul depășește limita sau spațiul liber.")
                                    }
                                    digest.update(buffer, 0, read)
                                    output.write(buffer, 0, read)
                                }
                                output.fd.sync()
                            }
                        }
                    } ?: throw IllegalStateException("Nu pot deschide fișierul ales.")
                    if (declaredSize >= 0 && total != declaredSize) throw IllegalStateException("Dimensiunea copiată nu corespunde fișierului sursă.")
                    if (!temp.renameTo(target)) throw IllegalStateException("Nu pot finaliza importul atomic al modelului.")
                } finally {
                    if (temp.exists()) temp.delete()
                }
                val sha256 = digest.digest().joinToString("") { "%02x".format(it) }
                val checksumTemp = File(dir, ".$finalName.sha256.tmp")
                val checksumTarget = File(dir, "$finalName.sha256")
                try {
                    FileOutputStream(checksumTemp).use { checksumOutput ->
                        checksumOutput.write((sha256 + "\n").toByteArray(Charsets.UTF_8))
                        checksumOutput.fd.sync()
                    }
                    if (!checksumTemp.renameTo(checksumTarget)) {
                        throw IllegalStateException("Nu pot salva fișierul de verificare SHA-256.")
                    }
                } catch (checksumError: Exception) {
                    checksumTemp.delete()
                    checksumTarget.delete()
                    target.delete()
                    throw IllegalStateException("Import anulat: nu am putut salva verificarea SHA-256; modelul a fost șters pentru a evita o bibliotecă incompletă.", checksumError)
                }
                status = "Model importat și verificare format ($sourceCheck): $finalName (${formatBytes(target.length())}). SHA-256: $sha256. ONNX este doar verificat ca fișier suficient de mare, nu validat semantic. Motorul de inferență nu este încă integrat."
            } catch (e: Exception) { status = e.message ?: "Import eșuat." }
            finally { modelImportActive.set(false) }
            val finalStatus = status
            runOnUiThread { webView.evaluateJavascript("window.onNativeModelImportStatus(${JSONObject.quote(finalStatus)}); window.refreshNativeModels && window.refreshNativeModels();", null) }
        }.apply { isDaemon = true; name = "VideoMakerModelImport" }.start()
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "model.bin"
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "model.bin"
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L*1024*1024 -> "%.2f GB".format(bytes/(1024.0*1024*1024))
        bytes >= 1024L*1024 -> "%.1f MB".format(bytes/(1024.0*1024))
        else -> "$bytes bytes"
    }

    private fun thermalLabel(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "none"
        PowerManager.THERMAL_STATUS_LIGHT -> "light"
        PowerManager.THERMAL_STATUS_MODERATE -> "moderate"
        PowerManager.THERMAL_STATUS_SEVERE -> "severe"
        PowerManager.THERMAL_STATUS_CRITICAL -> "critical"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "emergency"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "shutdown"
        else -> "unknown"
    }

    override fun onBackPressed() {
        // Do not allow Back to navigate the trusted editor into an external page.
        if (webView.canGoBack() && webView.url?.startsWith("file:///android_asset/web/") == true) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        nativeGenerationExecutor.shutdownNow()
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        webView.destroy()
        super.onDestroy()
    }
}
