cmake_minimum_required(VERSION 3.22.1)
project(videomaker_native LANGUAGES CXX)

# The native runtime is linked into Android shared library videomaker_native.
# Make every static dependency position-independent for this final shared link.
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Optional local stable-diffusion.cpp source checkout.
# Configure with -DSDCPP_SOURCE_DIR=/path/to/stable-diffusion.cpp when available.
set(SDCPP_SOURCE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/vendor/stable-diffusion.cpp" CACHE PATH "Path to stable-diffusion.cpp source checkout")
if(EXISTS "${SDCPP_SOURCE_DIR}/CMakeLists.txt")
    set(_SDCPP_DEFAULT ON)
else()
    set(_SDCPP_DEFAULT OFF)
endif()
option(VIDEOMAKER_LINK_SDCPP "Build and link stable-diffusion.cpp into the app" ${_SDCPP_DEFAULT})

add_library(videomaker_native SHARED native_engine.cpp)
find_library(log_lib log)
if(log_lib)
    target_link_libraries(videomaker_native PRIVATE ${log_lib})
endif()
target_compile_features(videomaker_native PRIVATE cxx_std_17)
target_compile_options(videomaker_native PRIVATE -Wall -Wextra)

if(VIDEOMAKER_LINK_SDCPP)
    if(NOT SDCPP_SOURCE_DIR OR NOT EXISTS "${SDCPP_SOURCE_DIR}/CMakeLists.txt")
        message(FATAL_ERROR "VIDEOMAKER_LINK_SDCPP=ON requires SDCPP_SOURCE_DIR pointing to stable-diffusion.cpp")
    endif()
    set(SD_BUILD_EXAMPLES OFF CACHE BOOL "Disable upstream examples" FORCE)
    set(SD_BUILD_SHARED_LIBS OFF CACHE BOOL "Build upstream static libraries" FORCE)
    set(SD_WEBP OFF CACHE BOOL "Disable WebP dependency for minimal Android build" FORCE)
    set(SD_WEBM OFF CACHE BOOL "Disable WebM dependency for minimal Android build" FORCE)
    set(SD_VULKAN OFF CACHE BOOL "Disable Vulkan for CPU-only target" FORCE)
    set(SD_METAL OFF CACHE BOOL "Disable Metal" FORCE)
    set(SD_SYCL OFF CACHE BOOL "Disable SYCL" FORCE)
    set(SD_MUSA OFF CACHE BOOL "Disable MUSA" FORCE)
    set(SD_HIPBLAS OFF CACHE BOOL "Disable HIP" FORCE)
    set(SD_RPC OFF CACHE BOOL "Disable RPC backend" FORCE)
    # Avoid desktop OpenMP runtime assumptions on Android; CPU thread count is
    # controlled by the JNI generation call.
    set(GGML_OPENMP OFF CACHE BOOL "Disable OpenMP for Android CPU build" FORCE)
    set(SD_BUILD_TESTS OFF CACHE BOOL "Disable upstream tests" FORCE)
    set(SD_CUDA OFF CACHE BOOL "CPU-only Android build" FORCE)
    set(SD_OPENCL OFF CACHE BOOL "Disable OpenCL for Mali/MediaTek CPU path" FORCE)
    add_subdirectory(${SDCPP_SOURCE_DIR} stable-diffusion-build)
    target_compile_definitions(videomaker_native PRIVATE VIDEOMAKER_SDCPP_LINKED=1)
    target_include_directories(videomaker_native PRIVATE ${SDCPP_SOURCE_DIR}/include)
    if(NOT TARGET stable-diffusion)
        message(FATAL_ERROR "Upstream stable-diffusion.cpp did not define expected target stable-diffusion")
    endif()
    target_link_libraries(videomaker_native PRIVATE stable-diffusion)
endif()
