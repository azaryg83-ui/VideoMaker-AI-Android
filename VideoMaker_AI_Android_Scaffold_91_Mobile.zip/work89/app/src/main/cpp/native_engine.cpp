#include <jni.h>
#include <string>
#include <sstream>
#include <cstring>
#include <vector>
#include <cstdint>

#ifdef VIDEOMAKER_SDCPP_LINKED
#include "stable-diffusion.h"
#endif


#ifdef VIDEOMAKER_SDCPP_LINKED
static std::string base64_encode(const uint8_t* data, size_t size) {
    static const char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    out.reserve(((size + 2) / 3) * 4);
    for (size_t i = 0; i < size; i += 3) {
        uint32_t a = data[i];
        uint32_t b = (i + 1 < size) ? data[i + 1] : 0;
        uint32_t c = (i + 2 < size) ? data[i + 2] : 0;
        uint32_t v = (a << 16) | (b << 8) | c;
        out.push_back(alphabet[(v >> 18) & 63]);
        out.push_back(alphabet[(v >> 12) & 63]);
        out.push_back(i + 1 < size ? alphabet[(v >> 6) & 63] : '=');
        out.push_back(i + 2 < size ? alphabet[v & 63] : '=');
    }
    return out;
}
#endif

static const char* kBridgeStatus =
#ifdef VIDEOMAKER_SDCPP_LINKED
    "native-bridge-ready;stable-diffusion.cpp-linked;checked-c-api-path";
#else
    "native-bridge-ready;stable-diffusion.cpp-not-linked";
#endif

extern "C" JNIEXPORT jstring JNICALL
Java_com_videomakerai_app_MainActivity_nativeStatus(JNIEnv* env, jobject) {
    return env->NewStringUTF(kBridgeStatus);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_videomakerai_app_MainActivity_nativeRuntimeInfo(JNIEnv* env, jobject) {
#ifdef VIDEOMAKER_SDCPP_LINKED
    return env->NewStringUTF("stable-diffusion.cpp C API linked; CPU-only Android configuration; context preparation and inference smoke test available; output pixels not exported yet");
#else
    return env->NewStringUTF("JNI bridge loaded; configure VIDEOMAKER_LINK_SDCPP and SDCPP_SOURCE_DIR to link inference runtime");
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_videomakerai_app_MainActivity_nativeGenerateSmokeTest(
    JNIEnv* env, jobject, jstring modelPath, jstring prompt, jint width, jint height,
    jint steps, jlong seed, jint threads) {
#ifndef VIDEOMAKER_SDCPP_LINKED
    (void)modelPath; (void)prompt; (void)width; (void)height; (void)steps; (void)seed; (void)threads;
    return env->NewStringUTF("NOT_READY: stable-diffusion.cpp is not linked into this build");
#else
    const char* model = env->GetStringUTFChars(modelPath, nullptr);
    const char* promptUtf = env->GetStringUTFChars(prompt, nullptr);
    if (!model || !promptUtf) {
        if (model) env->ReleaseStringUTFChars(modelPath, model);
        if (promptUtf) env->ReleaseStringUTFChars(prompt, promptUtf);
        return env->NewStringUTF("ERROR: JNI string conversion failed");
    }

    sd_ctx_t* ctx = nullptr;
    sd_result_t* result = nullptr;
    sd_ctx_opt_t* ctxOpt = sd_ctx_opt_create();
    sd_img_gen_opt_t* imageOpt = nullptr;
    sd_status_t status = ctxOpt ? SD_STATUS_OK : SD_STATUS_OUT_OF_MEMORY;

    // All option setters are checked. A failed setter must not silently leave
    // the generation configuration partially initialized.
    if (status == SD_STATUS_OK) status = sd_opt_set_string(ctxOpt, "model_path", model);
    if (status == SD_STATUS_OK) status = sd_opt_set_int(ctxOpt, "n_threads", threads > 0 ? threads : 2);
    if (status == SD_STATUS_OK) status = sd_ctx_create(ctxOpt, &ctx);
    sd_opt_free(ctxOpt);
    ctxOpt = nullptr;

    // Current upstream C API loads model components lazily during generation.
    // The former sd_ctx_prepare() API was removed in the upstream breaking refactor.

    if (status == SD_STATUS_OK) {
        imageOpt = sd_img_gen_opt_create();
        if (!imageOpt) status = SD_STATUS_OUT_OF_MEMORY;
    }
    if (status == SD_STATUS_OK) status = sd_opt_set_string(imageOpt, "prompt", promptUtf);
    if (status == SD_STATUS_OK) status = sd_opt_set_int(imageOpt, "width", width);
    if (status == SD_STATUS_OK) status = sd_opt_set_int(imageOpt, "height", height);
    if (status == SD_STATUS_OK) status = sd_opt_set_int(imageOpt, "seed", static_cast<int64_t>(seed));
    if (status == SD_STATUS_OK) status = sd_opt_set_int(imageOpt, "sample.steps", steps);
    if (status == SD_STATUS_OK) status = sd_opt_set_string(imageOpt, "sample.method", "euler");
    if (status == SD_STATUS_OK) status = sd_generate_image(ctx, imageOpt, &result);

    std::ostringstream out;
    if (status == SD_STATUS_OK && result) {
        out << "SMOKE_TEST_OK: inference completed; images=" << sd_result_get_image_count(result)
            << "; model prepared; pixels not exported to editor yet";
    } else {
        const char* error = sd_get_last_error();
        out << "INFERENCE_FAILED: status=" << static_cast<int>(status)
            << "; error=" << (error ? error : "unknown");
    }
    sd_result_free(result);
    sd_opt_free(imageOpt);
    sd_ctx_free(ctx);
    env->ReleaseStringUTFChars(modelPath, model);
    env->ReleaseStringUTFChars(prompt, promptUtf);
    return env->NewStringUTF(out.str().c_str());
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_videomakerai_app_MainActivity_nativeGenerateImagePayload(
    JNIEnv* env, jobject, jstring modelPath, jstring prompt, jint width, jint height,
    jint steps, jlong seed, jint threads) {
#ifndef VIDEOMAKER_SDCPP_LINKED
    (void)modelPath; (void)prompt; (void)width; (void)height; (void)steps; (void)seed; (void)threads;
    return env->NewStringUTF("NOT_READY|stable-diffusion.cpp is not linked");
#else
    if (width < 256 || width > 512 || height < 256 || height > 512 ||
        steps < 1 || steps > 20 || threads < 1 || threads > 6) {
        return env->NewStringUTF("ERROR|generation parameters exceed native safety limits");
    }
    const char* model = env->GetStringUTFChars(modelPath, nullptr);
    const char* promptUtf = env->GetStringUTFChars(prompt, nullptr);
    if (!model || !promptUtf) {
        if (model) env->ReleaseStringUTFChars(modelPath, model);
        if (promptUtf) env->ReleaseStringUTFChars(prompt, promptUtf);
        return env->NewStringUTF("ERROR|JNI string conversion failed");
    }
    sd_ctx_t* ctx = nullptr;
    sd_result_t* result = nullptr;
    sd_ctx_opt_t* ctxOpt = sd_ctx_opt_create();
    sd_img_gen_opt_t* imageOpt = nullptr;
    sd_status_t status = ctxOpt ? SD_STATUS_OK : SD_STATUS_OUT_OF_MEMORY;
    if (status == SD_STATUS_OK) status = sd_opt_set_string(ctxOpt, "model_path", model);
    if (status == SD_STATUS_OK) status = sd_opt_set_int(ctxOpt, "n_threads", threads > 0 ? threads : 2);
    if (status == SD_STATUS_OK) status = sd_ctx_create(ctxOpt, &ctx);
    sd_opt_free(ctxOpt);
    // Current upstream C API loads components lazily during generation.
    if (status == SD_STATUS_OK) {
        imageOpt = sd_img_gen_opt_create();
        if (!imageOpt) status = SD_STATUS_OUT_OF_MEMORY;
    }
    if (status == SD_STATUS_OK) status = sd_opt_set_string(imageOpt, "prompt", promptUtf);
    if (status == SD_STATUS_OK) status = sd_opt_set_int(imageOpt, "width", width);
    if (status == SD_STATUS_OK) status = sd_opt_set_int(imageOpt, "height", height);
    if (status == SD_STATUS_OK) status = sd_opt_set_int(imageOpt, "seed", static_cast<int64_t>(seed));
    if (status == SD_STATUS_OK) status = sd_opt_set_int(imageOpt, "sample.steps", steps);
    if (status == SD_STATUS_OK) status = sd_opt_set_string(imageOpt, "sample.method", "euler");
    if (status == SD_STATUS_OK) status = sd_generate_image(ctx, imageOpt, &result);

    std::string payload;
    if (status == SD_STATUS_OK && result && sd_result_get_image_count(result) > 0) {
        const sd_tensor_t* image = sd_result_get_image(result, 0);
        if (image && sd_tensor_type(image) == SD_TENSOR_U8 && sd_tensor_rank(image) == 3) {
            const int64_t channels = sd_tensor_dim(image, 0);
            const int64_t imageWidth = sd_tensor_dim(image, 1);
            const int64_t imageHeight = sd_tensor_dim(image, 2);
            const size_t bytes = sd_tensor_byte_size(image);
            const void* pixels = sd_tensor_data(image);
            const uint64_t expected = static_cast<uint64_t>(channels) * static_cast<uint64_t>(imageWidth) * static_cast<uint64_t>(imageHeight);
            if (pixels && (channels == 3 || channels == 4) && imageWidth > 0 && imageHeight > 0 &&
                imageWidth <= 512 && imageHeight <= 512 && expected == bytes && bytes <= 2 * 1024 * 1024) {
                // Upstream image tensors are channel-first [C, W, H] with H
                // contiguous inside each channel plane. The WebView payload expects
                // row-major interleaved RGB/RGBA, so explicitly transpose here.
                const auto* source = static_cast<const uint8_t*>(pixels);
                const size_t planeSize = static_cast<size_t>(imageWidth) * static_cast<size_t>(imageHeight);
                std::vector<uint8_t> interleaved(bytes);
                for (int64_t y = 0; y < imageHeight; ++y) {
                    for (int64_t x = 0; x < imageWidth; ++x) {
                        const size_t sourcePixel = static_cast<size_t>(x) * static_cast<size_t>(imageHeight) + static_cast<size_t>(y);
                        const size_t targetPixel = static_cast<size_t>(y) * static_cast<size_t>(imageWidth) + static_cast<size_t>(x);
                        for (int64_t c = 0; c < channels; ++c) {
                            interleaved[targetPixel * static_cast<size_t>(channels) + static_cast<size_t>(c)] =
                                source[static_cast<size_t>(c) * planeSize + sourcePixel];
                        }
                    }
                }
                payload = "OK|" + std::to_string(imageWidth) + "|" + std::to_string(imageHeight) + "|" +
                         std::to_string(channels) + "|" + base64_encode(interleaved.data(), interleaved.size());
            } else {
                payload = "ERROR|output tensor shape, channels, or size is invalid";
            }
        } else {
            payload = "ERROR|generated output is not a supported U8 image tensor";
        }
    } else {
        const char* error = sd_get_last_error();
        payload = "INFERENCE_FAILED|" + std::to_string(static_cast<int>(status)) + "|" + (error ? error : "unknown");
    }
    sd_result_free(result);
    sd_opt_free(imageOpt);
    sd_ctx_free(ctx);
    env->ReleaseStringUTFChars(modelPath, model);
    env->ReleaseStringUTFChars(prompt, promptUtf);
    return env->NewStringUTF(payload.c_str());
#endif
}
