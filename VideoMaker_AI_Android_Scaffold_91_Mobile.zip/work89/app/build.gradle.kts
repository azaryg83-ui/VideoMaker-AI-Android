plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.videomakerai.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.videomakerai.app"
        ndk { abiFilters += listOf("arm64-v8a") }
        minSdk = 28
        targetSdk = 35
        versionCode = 58
        versionName = "0.58-build-candidate"
    }
    // Opt-in native AI runtime linking. Default keeps a lightweight bridge build.
    val linkSdcppRuntime = providers.gradleProperty("videomakerLinkSdcpp").orNull == "true"
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
            arguments += listOf("-DVIDEOMAKER_LINK_SDCPP=${if (linkSdcppRuntime) "ON" else "OFF"}")
        }
    }
}
