# Milestone 81 — Safe model import storage reserve and interrupted-import cleanup

- Startup cleanup removes only app-created model-import temporary files and temporary SHA-256 sidecars; completed model files are not targeted.
- Model import preflight now preserves a 256 MB free-storage reserve.
- Copy-time storage checks continue to enforce the reserve as available storage changes.
- Retains the 6 GB per-model import cap and existing validation/atomic finalization.
- Android version: 0.48-build-candidate (versionCode 48).

Checks: `scripts/milestone81_check.py`.

Android APK build and device testing are not performed in this milestone.
