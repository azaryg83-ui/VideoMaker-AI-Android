# Milestone 66 — Stable Diffusion Runtime Bootstrap & API Gate

## Added
- Bootstrap script for the official stable-diffusion.cpp source with recursive submodules.
- Safe behavior for an existing checkout: submodules are initialized, but the script does not silently pull a new upstream commit.
- API compatibility gate for the JNI bridge's expected C API symbols and upstream CMake target.
- Exact upstream commit and recursive submodule status recorded in `SDCPP_RUNTIME_LOCK.txt` after successful bootstrap.
- Refuses to mark runtime compatible when upstream API/target differs.

## Run

```bash
./scripts/bootstrap_stable_diffusion_runtime.sh
```

## Validation
- Script syntax checked with `bash -n`.
- Static milestone 66 checks passed.
- Full source verification rerun.

## Limitations
- Runtime fetching was not executed in this environment, so no upstream checkout/commit is included yet.
- Android SDK/NDK are unavailable here; APK build and device inference remain unverified.
