# Milestone 48 — Character Consistency Foundation

Added a persistent character manager to the mobile editor:
- Create named characters with fixed physical descriptions.
- Optional reference image imported from device.
- Character library in the project and autosave/project JSON.
- Assign a character to individual scenes.
- Inject identity-lock wording into visual/video prompts for assigned scenes.
- Character Bible added to storyboard text export.

Limitations honestly stated in UI: prompt/reference groundwork does not guarantee exact facial identity. The current image/video engines are not yet integrated with reference-image conditioning/identity embedding, so deterministic face consistency remains future integration work.

Checks: frontend/static JS syntax, Android WebView security, bridge contract, host JNI compilation, CI workflow YAML, build script syntax, ZIP integrity.
Runtime Android test pending.
