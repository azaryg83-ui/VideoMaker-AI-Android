# Milestone 55 — Voiceover Duration Estimator

Added a scene-by-scene narration duration estimator using available scene caption/subtitle text or cue text.

Features:
- Selectable narration pace (110, 130, 150, 170 words/minute).
- Selectable pause allowance (0–30%).
- Calculates estimated duration per scene and compares it with the current scene duration.
- Optional action to apply estimates to scenes with available narration text.
- Updates scene rendering, timeline counters, production workflow, and autosave after applying.
- Clearly labeled as an estimate; it does not analyze actual voiceover waveform/audio duration.

Validation: frontend/static security checks, bridge contract, privacy checks, model integrity/thermal safety checks, native payload guards, WebM audio export checks, scene motion heuristic checks, host JNI compilation, Android CI configuration and source verification passed. No Android APK/device runtime test was performed.
