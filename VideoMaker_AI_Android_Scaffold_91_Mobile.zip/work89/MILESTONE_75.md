# Milestone 75 — Serialized model integrity checks

- Added a process-wide atomic guard so only one model SHA-256 verification can run at a time.
- Concurrent verification requests are returned immediately as `BUSY`, instead of hashing multiple large model files simultaneously.
- The verifier worker is explicitly named and daemonized; the UI reports a clear Romanian busy message.
- Added a distinct amber status color for busy responses.
- Candidate version bumped to 0.43 (versionCode 43).

Validation: source contract checker and frontend/JNI host/CI verification. Android APK build and device behavior remain untested in this environment.
