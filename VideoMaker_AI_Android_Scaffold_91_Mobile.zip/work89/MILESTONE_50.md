# Milestone 50 — Character timeline / controlled evolution

Added persistent character evolution variants to the Character Manager.

- Users can define named timeline stages (e.g., "20 years later").
- Each stage can explicitly override apparent age, body/weight, hair color, hair length, hair style/texture, facial hair, clothing, and add notes for other intentional changes.
- Scene editor now lets each assigned character use either the base identity or a chosen timeline variant.
- Prompt identity lock now includes the selected variant as deliberate changes only and instructs the generation engine to preserve all non-overridden identity traits.
- Variants are stored within the existing character/project object and autosave/export/load naturally preserve them.
- Character Bible storyboard export includes the evolution variants.
- Variant deletion clears matching scene variant references.

Verification: `scripts/frontend_check.sh` and `scripts/verify_source.sh` passed. Static JavaScript/WebView checks and host-native JNI compile only; no Android runtime or APK test was performed.
