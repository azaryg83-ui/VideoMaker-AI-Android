# Milestone 87 — Model compatibility filters

- Added a compatibility/format filter to the native model library: all, invalid files, GGUF, ONNX, SafeTensors, legacy PT/PTH/CKPT, and other unsupported formats.
- Filters are combined with the existing name/format search and sorting.
- The filter uses existing metadata (`extension`, `generationReadiness`) and does not imply runtime support or change model files.
- Android app version: 0.54-build-candidate (versionCode 54).

## Validation
- Static milestone check covers filter UI/options, filtering logic, and event wiring.
- Full available script checks and frontend checks run from the current scaffold.
- No Android APK/device inference claim.
