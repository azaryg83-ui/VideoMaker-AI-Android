# Milestone 88 — Optional native AI runtime build in CI

- Added a manual GitHub Actions input to opt into fetching the pinned stable-diffusion.cpp source and attempting an Android native runtime build.
- The default CI path remains the lightweight bridge build.
- Runtime opt-in executes the pinned bootstrap/API gate and builds with `-PvideomakerLinkSdcpp=true`, enabling CMake's runtime link option.
- The runtime build is an attempt/validation path, not a claim that inference works on the Redmi device.
- Android app version: 0.55-build-candidate (versionCode 55).

## Validation
- Static workflow wiring check validates the opt-in, pinned bootstrap step, and Gradle property path.
- APK/runtime build was not executed in this environment; it must be run through GitHub Actions with the runtime option enabled.
