# Milestone 49 — Structured Character Identity Profiles

Added structured character creation fields to the Android-first editor:
- apparent age
- height
- weight/body build
- proportions/posture
- skin tone
- eyes
- hair color, length, style and texture
- facial hair
- tattoos
- scars
- distinctive marks
- baseline clothing
- facial/identity description and optional reference image

The editor assembles these fields into a persistent profile summary, stores structured profile fields with the character, uses the summary in the CHARACTER IDENTITY LOCK prompt, displays the profile in the character list, and exports the character bible with profile details. Existing legacy characters with description-only data remain supported.

Verification: `scripts/frontend_check.sh` and `scripts/verify_source.sh` passed. Static checks and host-native JNI compilation only; no Android runtime/APK test performed for this milestone.
