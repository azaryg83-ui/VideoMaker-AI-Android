# Milestone 71 — Native generation concurrency guard

- Replaced the unbounded single-thread executor queue with a single-worker `ThreadPoolExecutor` backed by a `SynchronousQueue`.
- At most one native generation request can run at a time; additional requests are rejected immediately rather than accumulating and potentially consuming resources later.
- Rejected requests receive a `BUSY` callback, preserving the asynchronous bridge contract.
- Existing model path validation, severe thermal block, prompt cap, and worker-thread execution remain in place.
- Version updated to `0.40-build-candidate` / `versionCode 40`.

Validation: source-contract checker and source verification passed, as did milestone checkers 62–71. This is source-level validation only; Android APK build and device inference are not available in the current environment.
