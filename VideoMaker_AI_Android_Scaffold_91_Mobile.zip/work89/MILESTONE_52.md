# Milestone 52 — Character Continuity Audit

Added a scene-by-scene character continuity audit:
- Detect scenes assigned to a character where image prompt lacks `CHARACTER IDENTITY LOCK`.
- Detect assigned scenes where video prompt lacks the identity lock.
- Warn when scene narration mentions a saved character but that character is not assigned to the scene.
- Report assigned character without a saved reference image (informational).
- Flag scene assignments whose selected evolution variant no longer exists.
- Added a prompt repair action that reapplies the identity prompt to assigned scenes while retaining scene-specific text.
- Export a TXT continuity report.

Validation: `scripts/frontend_check.sh` and `scripts/verify_source.sh` passed. These are static/source checks and host-native compilation; no Android APK runtime/device test was performed.
