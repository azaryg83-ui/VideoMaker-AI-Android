# Milestone 65 — Android Runtime Build Preflight

## Added
- A single preflight script to check Android NDK/SDK environment variables, CMake, Git, Gradle, native project files, and whether the pinned Stable Diffusion source/API is present.
- Clear PASS / MISSING / WARN output and an overall READY, READY WITH WARNINGS, or BLOCKED status.
- The script avoids downloading anything or changing the source tree; it is a diagnostic-only check.

## Run
From the project root:

```bash
./scripts/android_runtime_preflight.sh
```

## Validation
- Shell syntax checked with `bash -n`.
- Script executed in the current environment; missing Android build dependencies are reported rather than hidden.
- Frontend, bridge, native host, CI and milestone 62–64 checks rerun.

## Limitation
The script does not build the APK or prove model inference on-device. That still requires a configured Android SDK/NDK, upstream runtime checkout, and device validation.
