# Milestone 47 — Automatic shot type suggestions

- Added scene text heuristic for shot categories: wide, close-up, detail, establishing, crowd, atmosphere, action-wide, medium.
- Added a project-wide button to suggest frame types and vary repeated adjacent shot suggestions.
- Added per-scene editable shot-type selector.
- Shot-type suggestions enrich visual prompts and are saved in project JSON.
- Storyboard text export includes the suggested frame type.
- This is heuristic planning, not AI image/video generation.

Verification: `scripts/frontend_check.sh` and `scripts/verify_source.sh` passed. No Android runtime test or APK build was performed.
