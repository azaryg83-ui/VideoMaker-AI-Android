# Milestone 72 — Human-readable native generation feedback

- Added a status formatter for native generation callback codes.
- BUSY, NOT_READY, THERMAL_BLOCKED, and ERROR responses are translated into concise Romanian messages rather than exposing raw protocol strings.
- Payload attachment is attempted only for successful `OK` responses.
- Generation control unlock behavior remains intact.

Validation: source-contract checker passed and full source verification was rerun. Android APK build/device inference remain untested. Version updated to 0.41-build-candidate/versionCode 41.
