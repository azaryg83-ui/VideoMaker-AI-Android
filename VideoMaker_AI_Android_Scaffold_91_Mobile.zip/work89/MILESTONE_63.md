# Milestone 63 — Local AI Runtime Compatibility Matrix

## Changes
- Added a user-visible compatibility matrix for the model file types accepted by the import library.
- Clarifies that GGUF is commonly a language-model format and is not a direct Stable Diffusion checkpoint format.
- Explains that SafeTensors may contain diffusion weights but may represent only one component of a larger model pipeline.
- Notes that ONNX compatibility depends on graph/operator/runtime support, not merely the extension.
- Warns that PT/PTH/CKPT legacy serialization is not automatically safe and should not be loaded automatically.
- Keeps hardware/resource diagnostics and explicitly labels the inference runtime as not integrated.

## Limitations
- This matrix is explanatory, not a parser, model classifier, benchmark, or compatibility guarantee.
- No AI model was downloaded or executed.
- Android APK/device inference test not performed.

## Validation
- Frontend syntax/static checks
- Bridge contract check
- CI workflow check
- Host native compile check
- Source verification
- Additional source check for compatibility matrix entries and runtime-not-integrated warning
