# Milestone 78 — Serialized model file operations

- Introduced a shared lock for integrity verification, checksum copying, and model deletion.
- Integrity verification reserves its active state under the lock and reads/hash-checks the model while holding the same lock.
- Checksum copying refuses to run while integrity verification is active and returns `BUSY` for the UI to explain.
- Model deletion is serialized with other model file operations.
- The checksum sidecar is deleted only after the model file deletion succeeds. If deletion fails, the sidecar is preserved and the user-facing message says so.
- Version: `0.46-build-candidate` (versionCode 46).

Checks: `scripts/milestone78_check.py` verifies the synchronization contract and UI BUSY message. Android APK/device behavior still requires Android SDK/NDK and device testing.
