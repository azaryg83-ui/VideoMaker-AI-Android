# Milestone 82 — Model storage usage visibility

- Native model-library listing now reports aggregate bytes occupied by completed model files.
- Android UI displays model storage used alongside model count and currently available app-private storage.
- Temporary and checksum sidecar files are excluded from the completed-model total.
- Android version: 0.49-build-candidate (versionCode 49).

Checks: `scripts/milestone82_check.py`.

Android APK build and device testing are not performed in this milestone.
