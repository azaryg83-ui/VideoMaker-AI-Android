# Milestone 84 — Storage space warning

- Model library shows free storage with an alert level.
- Below 512 MB: danger notice recommending no large model imports.
- Below 1 GB: warning recommending size checks before import.
- At or above 1 GB: informational notice only; does not guarantee inference.
- Version: 0.51-build-candidate.
