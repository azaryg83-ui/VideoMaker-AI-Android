# Milestone 85 — Model Storage Capacity Meter

- Native model library reports total private app storage capacity from Android StatFs.
- Web library UI shows capacity, model-storage percentage, and an accessible progress indicator.
- Existing free-space warning thresholds remain unchanged.
- Version bumped to 0.52-build-candidate.
- This is a storage visualization only; it does not predict model runtime compatibility.
