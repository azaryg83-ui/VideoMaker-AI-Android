# Milestone 51 — Edit Existing Character Profiles

- Added an Edit button to each saved character card.
- Edit loads the saved profile fields into the character creation form.
- Saving updates the existing character in place instead of creating a duplicate.
- Existing timeline/evolution variants and scene assignments are preserved.
- A newly selected reference image replaces the old one; if no new reference is selected, the previous reference image remains.
- The form returns to Create mode after save.

## Verification
- `scripts/frontend_check.sh` passed.
- `scripts/verify_source.sh` passed (frontend static checks, host-native JNI compilation, CI workflow YAML and build script syntax).
- No Android APK runtime test was performed for this milestone.
