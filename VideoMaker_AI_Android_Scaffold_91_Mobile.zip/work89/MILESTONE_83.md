# Milestone 83 — Model storage breakdown

- Model library UI now groups local model storage usage by file extension/format.
- Formats are sorted by occupied bytes descending for a quick storage overview.
- Existing inventory, import, checksum, and delete flows remain unchanged.
- Android version: 0.50-build-candidate (versionCode 50).

Validation: see scripts/milestone83_check.py.
