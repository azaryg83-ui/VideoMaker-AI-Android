# Milestone 74 — On-demand model integrity verification

- Added an Android bridge method that verifies a model file against its SHA-256 sidecar on a background thread.
- Uses the private-library path guard and validates sidecar format before hashing.
- Hashes the file in 1 MiB chunks and compares the digest with `MessageDigest.isEqual`.
- Reports `MATCH`, `MISMATCH`, `NO_CHECKSUM`, `INVALID_FILE`, or `ERROR` to the UI.
- Added per-model “Verifică integritatea” action and visible result messaging.
- Bumped candidate app version to 0.42 (versionCode 42).

Validation: source contract checker and frontend/JNI host/CI verification. Android APK build and on-device hash action remain untested in this environment.
