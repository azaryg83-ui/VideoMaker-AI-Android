# Milestone 73 — Strict native generation request validation

- Added one shared Kotlin validator for the native generation request.
- Requests now reject blank prompts and prompts longer than 4000 characters.
- Requests reject image dimensions outside 256–512 pixels, steps outside 1–20, and threads outside 1–6.
- Async and synchronous bridge paths use the same validation and no longer silently clamp invalid values.
- Source verification now runs milestone checks 71, 72, and 73.

Validation: source-contract checker and consolidated source verification passed. Android APK build/device generation remain untested.
