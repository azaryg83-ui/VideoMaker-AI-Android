#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENDOR="$ROOT/app/src/main/cpp/vendor/stable-diffusion.cpp"
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
fail=0
warn=0
pass(){ printf 'PASS: %s\n' "$1"; }
missing(){ printf 'MISSING: %s\n' "$1"; fail=$((fail+1)); }
warning(){ printf 'WARN: %s\n' "$1"; warn=$((warn+1)); }
printf 'VideoMaker AI Android runtime preflight\nProject: %s\n\n' "$ROOT"
if [[ -n "$NDK" && -d "$NDK" ]]; then pass "Android NDK path found: $NDK"; else missing 'Android NDK not found; set ANDROID_NDK_HOME or ANDROID_NDK_ROOT'; fi
if [[ -n "$SDK" && -d "$SDK" ]]; then pass "Android SDK path found: $SDK"; else warning 'Android SDK path not found; set ANDROID_HOME or ANDROID_SDK_ROOT'; fi
if command -v cmake >/dev/null 2>&1; then pass "CMake found: $(cmake --version | head -n1)"; else missing 'CMake is not installed or not in PATH'; fi
if command -v git >/dev/null 2>&1; then pass "Git found: $(git --version)"; else missing 'Git is not installed or not in PATH'; fi
if [[ -x "$ROOT/gradlew" ]]; then pass 'Gradle wrapper is present'; elif command -v gradle >/dev/null 2>&1; then pass "System Gradle found: $(gradle --version | head -n1)"; else missing 'Gradle wrapper/system Gradle not found'; fi
if [[ -d "$VENDOR/.git" ]]; then
  pass 'stable-diffusion.cpp source checkout exists'
  if [[ -f "$VENDOR/include/stable-diffusion.h" ]] && grep -q 'sd_generate_image' "$VENDOR/include/stable-diffusion.h"; then pass 'Expected stable-diffusion C API symbol found'; else missing 'Upstream C API header/symbol missing; checkout may be incomplete or incompatible'; fi
  if grep -q 'set(SD_LIB stable-diffusion)' "$VENDOR/CMakeLists.txt"; then pass 'Expected upstream CMake target declaration found'; else missing 'Expected upstream CMake target stable-diffusion not found'; fi
else warning 'Stable Diffusion runtime source is not downloaded; native bridge will build in NOT_READY mode'; fi
if [[ -f "$ROOT/app/src/main/cpp/CMakeLists.txt" ]]; then pass 'Native CMake configuration exists'; else missing 'Native CMakeLists.txt missing'; fi
if [[ -f "$ROOT/app/src/main/cpp/native_engine.cpp" ]]; then pass 'JNI native engine source exists'; else missing 'JNI native engine source missing'; fi
printf '\nSummary: %d missing requirement(s), %d warning(s)\n' "$fail" "$warn"
if (( fail > 0 )); then printf 'Preflight status: BLOCKED\n'; exit 1; fi
if (( warn > 0 )); then printf 'Preflight status: READY WITH WARNINGS\n'; else printf 'Preflight status: READY\n'; fi
