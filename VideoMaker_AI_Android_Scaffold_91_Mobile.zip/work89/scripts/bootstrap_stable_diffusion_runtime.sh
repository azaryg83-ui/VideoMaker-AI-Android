#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENDOR="$ROOT/app/src/main/cpp/vendor/stable-diffusion.cpp"
REPO="https://github.com/leejet/stable-diffusion.cpp.git"
PIN="0d71f963af9c94941f4a67e8ea145935651dd756"
LOCK="$ROOT/SDCPP_RUNTIME_LOCK.txt"

if ! command -v git >/dev/null 2>&1; then
  echo "ERROR: git is required to fetch the native AI runtime." >&2
  exit 2
fi
if [[ -e "$VENDOR" && ! -d "$VENDOR/.git" ]]; then
  echo "ERROR: runtime destination exists but is not a Git checkout: $VENDOR" >&2
  exit 2
fi
if [[ ! -d "$VENDOR/.git" ]]; then
  mkdir -p "$(dirname "$VENDOR")"
  echo "Fetching stable-diffusion.cpp with submodules..."
  git clone "$REPO" "$VENDOR"
  git -C "$VENDOR" fetch origin "$PIN"
  git -C "$VENDOR" checkout --detach "$PIN"
  git -C "$VENDOR" submodule update --init --recursive
else
  echo "Runtime checkout exists; pinning to the verified commit (no implicit latest pull)."
  git -C "$VENDOR" fetch origin "$PIN"
  git -C "$VENDOR" checkout --detach "$PIN"
  git -C "$VENDOR" submodule update --init --recursive
fi

HEADER="$VENDOR/include/stable-diffusion.h"
CMAKE="$VENDOR/CMakeLists.txt"
[[ -f "$HEADER" ]] || { echo "ERROR: public C API header missing." >&2; exit 3; }
[[ -f "$CMAKE" ]] || { echo "ERROR: upstream CMake file missing." >&2; exit 3; }
for symbol in sd_ctx_opt_create sd_img_gen_opt_create sd_ctx_create sd_generate_image sd_result_get_image_count sd_result_free; do
  grep -q "$symbol" "$HEADER" || { echo "ERROR: expected API symbol missing: $symbol" >&2; exit 3; }
done
if ! grep -q 'set(SD_LIB stable-diffusion)' "$CMAKE"; then
  echo "ERROR: upstream CMake target declaration differs from expected stable-diffusion target." >&2
  echo "Review upstream changes before linking; refusing to mark runtime compatible." >&2
  exit 3
fi
REV="$(git -C "$VENDOR" rev-parse HEAD)"
if [[ "$REV" != "$PIN" ]]; then echo "ERROR: runtime commit mismatch; expected $PIN, got $REV" >&2; exit 3; fi
SUBMODULES="$(git -C "$VENDOR" submodule status --recursive | sed 's/^/  /')"
{
  echo "Repository: $REPO"
  echo "Commit: $REV"
  echo "Fetched: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "API gate: PASS"
  echo "Submodules:"
  printf '%s\n' "$SUBMODULES"
} > "$LOCK"
echo "RUNTIME_BOOTSTRAP_PASS: API gate passed; pinned checkout recorded in SDCPP_RUNTIME_LOCK.txt"
echo "Next build configuration must still be validated with Android SDK/NDK and device inference."
