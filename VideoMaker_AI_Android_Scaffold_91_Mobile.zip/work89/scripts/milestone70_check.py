#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/web/index.html').read_text()
checks={
 'generated payload attaches to captured scene index':'attachNativePayloadToScene(payload,targetSceneIndex,requestPrompt)' in html,
 'async callback passes captured scene index':'callback.sceneIndex,callback.prompt' in html,
 'request captures scene index and prompt':'nativeGenerationCallbacks.set(callbackId,{sceneIndex:cur,prompt})' in html,
 'async generation callback remains tracked':'nativeGenerationCallbacks.delete(callbackId)' in html,
 'generation UI unlocks after callbacks':'nativeGenerationCallbacks.size===0' in html,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
if not all(checks.values()): raise SystemExit(1)
