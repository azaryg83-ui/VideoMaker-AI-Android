#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/build-diagnostics}"
mkdir -p "$OUT"
{
  echo "Project: VideoMaker AI"
  echo "Commit: ${GITHUB_SHA:-local}"
  echo "Workflow: ${GITHUB_WORKFLOW:-local}"
  echo "Run: ${GITHUB_RUN_ID:-local} / ${GITHUB_RUN_ATTEMPT:-1}"
  echo "Runtime option: ${LINK_SDCPP_RUNTIME:-unknown}"
  echo "Collected UTC: $(date -u +%FT%TZ)"
  echo
  echo "== Java =="; java -version 2>&1 || true
  echo "== Gradle =="; gradle --version 2>&1 || true
  echo "== CMake =="; cmake --version 2>&1 || true
  echo "== Android SDK/NDK paths =="; echo "ANDROID_HOME=${ANDROID_HOME:-}"; echo "ANDROID_NDK_HOME=${ANDROID_NDK_HOME:-}"; echo "ANDROID_NDK_ROOT=${ANDROID_NDK_ROOT:-}"
  if [[ -n "${ANDROID_NDK_HOME:-}" && -d "$ANDROID_NDK_HOME" ]]; then ls -la "$ANDROID_NDK_HOME" | head -30; fi
  echo "== Runtime checkout =="
  VENDOR="$ROOT/app/src/main/cpp/vendor/stable-diffusion.cpp"
  if [[ -d "$VENDOR/.git" ]]; then git -C "$VENDOR" rev-parse HEAD 2>&1; git -C "$VENDOR" status --short 2>&1; git -C "$VENDOR" submodule status --recursive 2>&1; else echo "Runtime source not fetched"; fi
  echo "== Gradle native configuration =="
  grep -nE 'abiFilters|videomakerLinkSdcpp|versionCode|versionName' "$ROOT/app/build.gradle.kts" 2>&1 || true
} > "$OUT/BUILD_DIAGNOSTICS.txt" 2>&1
find "$ROOT/app/build" -name CMakeCache.txt -type f 2>/dev/null | while read -r cache; do
  mkdir -p "$OUT/cmake-cache"
  cp "$cache" "$OUT/cmake-cache/$(basename "$(dirname "$cache")")-CMakeCache.txt" 2>/dev/null || true
done
if [[ -f "$ROOT/SDCPP_RUNTIME_LOCK.txt" ]]; then cp "$ROOT/SDCPP_RUNTIME_LOCK.txt" "$OUT/"; fi
if [[ -f "$ROOT/build-evidence/android-build.log" ]]; then cp "$ROOT/build-evidence/android-build.log" "$OUT/"; fi
printf 'Build diagnostics collected at %s\n' "$OUT"
