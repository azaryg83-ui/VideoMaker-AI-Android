#!/usr/bin/env bash
set -euo pipefail
APK_PATH="${1:-app/build/outputs/apk/debug/app-debug.apk}"
OUT_DIR="${2:-build-evidence}"
if [[ ! -f "$APK_PATH" ]]; then echo "APK not found: $APK_PATH" >&2; exit 2; fi
mkdir -p "$OUT_DIR"
APK_NAME="$(basename "$APK_PATH")"
APK_SIZE="$(stat -c '%s' "$APK_PATH" 2>/dev/null || stat -f '%z' "$APK_PATH")"
APK_SHA="$(sha256sum "$APK_PATH" | awk '{print $1}')"
VERSION_CODE="$(grep -E 'versionCode[[:space:]]*=' app/build.gradle.kts | head -1 | sed -E 's/.*=[[:space:]]*([0-9]+).*/\1/')"
VERSION_NAME="$(grep -E 'versionName[[:space:]]*=' app/build.gradle.kts | head -1 | sed -E 's/.*=[[:space:]]*"([^"]+)".*/\1/')"
cat > "$OUT_DIR/BUILD_MANIFEST.txt" <<MANIFEST
APK filename: $APK_NAME
APK size bytes: $APK_SIZE
APK SHA-256: $APK_SHA
Version code: $VERSION_CODE
Version name: $VERSION_NAME
Commit: ${GITHUB_SHA:-$(git rev-parse HEAD 2>/dev/null || echo unknown)}
Build date UTC: $(date -u +%FT%TZ)
Build type: debug
MANIFEST
printf '%s  %s\n' "$APK_SHA" "$APK_NAME" > "$OUT_DIR/SHA256SUMS.txt"
cat "$OUT_DIR/BUILD_MANIFEST.txt"
