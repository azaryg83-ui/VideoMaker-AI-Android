#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
kt = (root / 'app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
html = (root / 'app/src/main/assets/web/index.html').read_text()
start = kt.find('fun deleteModel(fileName: String): String')
end = kt.find('fun showMessage(message: String)', start)
block = kt[start:end]
checks = {
    'Delete uses safe canonical model resolver': 'safeModelFile(fileName)' in block,
    'Delete rejects active integrity verification': 'modelIntegrityVerificationActive.get()' in block and '"BUSY"' in block,
    'Delete requires existing regular file': 'file.isFile' in block and 'file.exists()' in block,
    'Sidecar constrained to models directory': 'sidecar.parentFile == modelsDirectory().canonicalFile' in block,
    'Delete result includes structured status': '"code"' in block and '"message"' in block,
    'Frontend reads structured delete result': 'JSON.parse(bridge.deleteModel' in html,
    'Frontend displays native delete result message': 'result.message' in html,
    'Milestone 77 historical record exists': (root/'MILESTONE_77.md').exists(),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
if not all(checks.values()): raise SystemExit(1)
print(f'{sum(checks.values())}/{len(checks)} milestone 77 checks passed')
