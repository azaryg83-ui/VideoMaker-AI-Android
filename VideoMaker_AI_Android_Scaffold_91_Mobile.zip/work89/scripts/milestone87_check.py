from pathlib import Path
root=Path(__file__).resolve().parents[1]
gradle=(root/'app/build.gradle.kts').read_text()
history=''.join((root/f'MILESTONE_{j}.md').read_text() for j in range(81,90) if (root/f'MILESTONE_{j}.md').exists())
html=(root/'app/src/main/assets/web/index.html').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'filter selector exists':'id="nativeModelFilter"' in html,
 'all option':'value="all">Toate modelele' in html,
 'invalid file option':'value="invalid">Fișiere invalide' in html,
 'GGUF filter':'value="gguf">GGUF' in html,
 'ONNX filter':'value="onnx">ONNX' in html,
 'SafeTensors filter':'value="safetensors">SafeTensors' in html,
 'legacy filter':'value="legacy">PT / PTH / CKPT' in html,
 'unsupported filter':'value="unsupported">Alte formate' in html,
 'filter logic uses metadata':'const modelFilter=' in html and 'generationReadiness' in html and 'matchesFilter' in html,
 'combined search/filter':'return matchesSearch&&matchesFilter' in html,
 'filter change wired':"$('nativeModelFilter').onchange=refreshNativeModels" in html,
 'version check accepts current milestone': '0.55-build-candidate' in history and 'versionCode = 58' in gradle and '0.58-build-candidate' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
if not all(checks.values()): raise SystemExit(1)
