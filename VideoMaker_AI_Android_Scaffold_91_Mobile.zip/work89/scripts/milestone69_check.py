from pathlib import Path
native=Path('app/src/main/cpp/native_engine.cpp').read_text()
activity=Path('app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
web=Path('app/src/main/assets/web/index.html').read_text()
checks={
 'native image payload method exists':'nativeGenerateImagePayload' in native and 'Java_com_videomakerai_app_MainActivity_nativeGenerateImagePayload' in native,
 'native tensor output is restricted to U8 RGB/RGBA':'sd_tensor_type(image) == SD_TENSOR_U8' in native and '(channels == 3 || channels == 4)' in native,
 'native output dimensions and byte size are bounded':'imageWidth <= 512 && imageHeight <= 512' in native and 'bytes <= 2 * 1024 * 1024' in native,
 'payload converts channel-first tensor into interleaved pixels':'interleaved[targetPixel * static_cast<size_t>(channels)' in native,
 'payload uses base64 transport':'base64_encode(interleaved.data(), interleaved.size())' in native,
 'Android async bridge executes generation off UI thread':'nativeGenerationExecutor.execute' in activity and 'nativeGenerateImagePayload' in activity,
 'WebView validates payload dimensions, channels and decoded byte count':'width*height*channels' in web and '![3,4].includes(channels)' in web,
 'WebView attaches generated image to scene':'attachNativePayloadToScene(payload,callback.sceneIndex,callback.prompt)' in web and 'scenes[idx].img=im' in web,
 'callback unlocks generate control after result':"$('nativeGenerateScene').disabled=false" in web,
}
for name,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+name)
if not all(checks.values()): raise SystemExit(1)
print('MILESTONE69_CHECK_PASS')
