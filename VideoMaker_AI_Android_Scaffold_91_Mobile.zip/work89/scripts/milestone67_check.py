from pathlib import Path
pin = '0d71f963af9c94941f4a67e8ea145935651dd756'
pin_file = Path('SDCPP_RUNTIME_PIN.txt').read_text()
bootstrap = Path('scripts/bootstrap_stable_diffusion_runtime.sh').read_text()
build = Path('scripts/fetch_and_build_android.sh').read_text()
checks = {
    'central runtime pin documented': pin in pin_file,
    'bootstrap fetches and checks out pinned commit': f'PIN="{pin}"' in bootstrap and 'checkout --detach "$PIN"' in bootstrap,
    'bootstrap validates commit after checkout': 'if [[ "$REV" != "$PIN" ]]' in bootstrap,
    'Android build script uses matching pin': f'SDCPP_COMMIT="{pin}"' in build,
    'build script cross-checks pin file': 'SDCPP_RUNTIME_PIN.txt' in build,
    'no implicit latest checkout in bootstrap': 'git pull' not in bootstrap,
}
for name, ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ') + name)
if not all(checks.values()): raise SystemExit(1)
print('MILESTONE67_CHECK_PASS')
