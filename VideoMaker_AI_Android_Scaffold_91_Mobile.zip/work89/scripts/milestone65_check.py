from pathlib import Path
import subprocess
script = Path('scripts/android_runtime_preflight.sh')
text = script.read_text(encoding='utf-8')
checks = {
    'preflight checks NDK environment': 'ANDROID_NDK_HOME' in text and 'ANDROID_NDK_ROOT' in text,
    'preflight checks SDK environment': 'ANDROID_HOME' in text and 'ANDROID_SDK_ROOT' in text,
    'preflight checks CMake and Git': 'cmake' in text and 'git' in text,
    'preflight checks Gradle': 'Gradle wrapper/system Gradle' in text,
    'preflight checks runtime source and C API': 'stable-diffusion.cpp source checkout exists' in text and 'sd_generate_image' in text,
    'preflight uses explicit result statuses': all(x in text for x in ['READY WITH WARNINGS', 'BLOCKED', 'READY']),
    'preflight is diagnostic-only': 'git clone' not in text and 'git fetch' not in text,
}
for name, ok in checks.items():
    print(('PASS: ' if ok else 'FAIL: ') + name)
if not all(checks.values()):
    raise SystemExit(1)
print('MILESTONE65_CHECK_PASS')
