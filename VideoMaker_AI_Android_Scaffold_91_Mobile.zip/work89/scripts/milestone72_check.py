#!/usr/bin/env python3
from pathlib import Path
s=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
checks={
 'generation error formatter exists':'function nativeGenerationErrorMessage(payload)' in s,
 'busy error translated to Romanian':'O altă generare este în desfășurare' in s,
 'not-ready error translated':'Motorul AI local nu este integrat' in s,
 'thermal block translated':'Telefonul este prea cald pentru generare' in s,
 'error code is checked before payload attach':"split('|',1)[0]!=='OK'" in s,
 'callback still unlocks generation button':'nativeGenerationCallbacks.size===0' in s,
}
for name,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+name)
if not all(checks.values()): raise SystemExit('MILESTONE72_CHECK_FAIL')
print('MILESTONE72_CHECK_PASS')
