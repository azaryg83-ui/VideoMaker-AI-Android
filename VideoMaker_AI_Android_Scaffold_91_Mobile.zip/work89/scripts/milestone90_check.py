#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
workflow=(root/'.github/workflows/android-build.yml').read_text()
script=(root/'scripts/create_build_manifest.sh').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'CI calls build manifest generator': 'scripts/create_build_manifest.sh build-evidence/app-debug.apk build-evidence' in workflow,
 'manifest records APK file name and size': 'APK filename:' in script and 'APK size bytes:' in script,
 'manifest records SHA-256': 'APK SHA-256:' in script and 'sha256sum' in script,
 'manifest records version code/name': 'Version code:' in script and 'Version name:' in script and 'versionCode' in script and 'versionName' in script,
 'manifest records commit and build timestamp': 'Commit:' in script and 'Build date UTC:' in script,
 'manifest includes debug build type': 'Build type: debug' in script,
 'milestone 90 version bump': 'versionCode = 58' in gradle and '0.58-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
if not all(checks.values()): raise SystemExit(1)
