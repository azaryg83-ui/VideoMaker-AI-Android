#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
gradle=(root/'app/build.gradle.kts').read_text()
history=''.join((root/f'MILESTONE_{j}.md').read_text() for j in range(81,90) if (root/f'MILESTONE_{j}.md').exists())
kt=(root/'app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
html=(root/'app/src/main/assets/web/index.html').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'aggregate model byte count': 'totalModelStorageBytes' in kt and 'files.sumOf' in kt,
 'aggregate storage JSON field': '.put("totalModelStorageBytes", totalModelStorageBytes)' in kt,
 'UI displays used model storage': 'ocupat de modele:' in html and 'data.totalModelStorageBytes' in html,
 'available storage remains displayed': 'data.freeAppStorageBytes' in html,
 'checksum sidecars excluded from inventory': 'endsWith(".sha256")' in kt,
 'version check accepts current milestone': '0.55-build-candidate' in history and 'versionCode = 58' in gradle and '0.58-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
