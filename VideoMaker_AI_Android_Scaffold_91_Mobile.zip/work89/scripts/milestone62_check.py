from pathlib import Path
root=Path(__file__).resolve().parents[1]
kt=(root/'app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
html=(root/'app/src/main/assets/web/index.html').read_text()
checks=[
 ('Android RAM threshold exposed', 'info.put("ramThresholdBytes", memoryInfo.threshold)' in kt),
 ('Available private model storage exposed', 'info.put("availableModelStorageBytes", android.os.StatFs(filesDir.absolutePath).availableBytes)' in kt),
 ('Conservative memory budget calculated', 'availableRam*.30,heapMax*.35' in html),
 ('Current free RAM shown', 'RAM disponibilă acum:' in html),
 ('Storage budget shown', 'spațiu privat liber:' in html),
 ('Thermal status guidance present', 'thermalWarn' in html),
 ('No model download promise', 'Nu descărca model' in html),
]
for name,ok in checks:
 print(('PASS' if ok else 'FAIL')+': '+name)
if not all(ok for _,ok in checks): raise SystemExit(1)
print('MILESTONE_62_CHECK_PASS')
