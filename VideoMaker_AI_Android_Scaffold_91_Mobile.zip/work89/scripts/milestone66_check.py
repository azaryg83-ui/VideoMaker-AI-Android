from pathlib import Path
s=Path('scripts/bootstrap_stable_diffusion_runtime.sh').read_text(encoding='utf-8')
checks={
 'fetches official upstream repository':'https://github.com/leejet/stable-diffusion.cpp.git' in s,
 'pinned checkout before submodule init':'git clone' in s and 'checkout --detach "$PIN"' in s and 'submodule update --init --recursive' in s,
 'updates submodules without implicit pull':'submodule update --init --recursive' in s and not any(line.strip().startswith('git pull') for line in s.splitlines()),
 'validates required C API symbols':all(x in s for x in ['sd_ctx_opt_create','sd_img_gen_opt_create','sd_ctx_create','sd_generate_image','sd_result_get_image_count','sd_result_free']),
 'checks expected upstream CMake target':'set(SD_LIB stable-diffusion)' in s,
 'records exact upstream commit':'git -C "$VENDOR" rev-parse HEAD' in s and 'SDCPP_RUNTIME_LOCK.txt' in s,
 'refuses mismatched source instead of silently linking':'Review upstream changes before linking' in s,
 'does not download a model':'model download' not in s.lower() and 'huggingface' not in s.lower(),
}
for name,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+name)
if not all(checks.values()): raise SystemExit('MILESTONE66_CHECK_FAIL')
print('MILESTONE66_CHECK_PASS')
