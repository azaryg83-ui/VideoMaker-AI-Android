#!/usr/bin/env python3
"""Static contract check for methods exposed from Android Kotlin to the WebView editor."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / 'app/src/main/assets/web/index.html'
KOTLIN = ROOT / 'app/src/main/java/com/videomakerai/app/MainActivity.kt'
html = HTML.read_text(encoding='utf-8')
kotlin = KOTLIN.read_text(encoding='utf-8')

js_methods = set(re.findall(r'VideoMakerNative\.([A-Za-z_$][\w$]*)', html))
required_editor_methods = {'listModels', 'deleteModel', 'requestModelImport', 'nativeGenerateImagePayloadAsync'}
for method in required_editor_methods:
    if method not in html:
        raise SystemExit(f'BRIDGE_CONTRACT_FAIL: required editor bridge method reference missing: {method}')
js_methods |= required_editor_methods
annotated_methods = set(re.findall(r'@JavascriptInterface\s+fun\s+([A-Za-z_$][\w$]*)\s*\(', kotlin))
missing = sorted(js_methods - annotated_methods)
print('WebView bridge methods called by editor:', ', '.join(sorted(js_methods)) or '(none)')
print('Kotlin methods exposed with @JavascriptInterface:', ', '.join(sorted(annotated_methods)) or '(none)')
if missing:
    print('BRIDGE_CONTRACT_FAIL: editor calls methods not exposed to JavaScript: ' + ', '.join(missing))
    raise SystemExit(1)
# Ensure the native callbacks expected by the editor are emitted by the Kotlin bridge.
callbacks = set(re.findall(r'window\.(onNative[A-Za-z0-9_]+)', html))
callbacks_emitted = set(re.findall(r'window\.(onNative[A-Za-z0-9_]+)', kotlin))
callback_missing = sorted(callbacks - callbacks_emitted)
print('Editor native callbacks:', ', '.join(sorted(callbacks)) or '(none)')
if callback_missing:
    print('BRIDGE_CALLBACK_FAIL: callbacks not emitted by native shell: ' + ', '.join(callback_missing))
    raise SystemExit(1)
print(f'BRIDGE_CONTRACT_PASS: {len(js_methods)} JS bridge methods and {len(callbacks)} callbacks verified')
