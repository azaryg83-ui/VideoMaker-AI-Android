#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
kt = (root / 'app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
gradle = (root / 'app/build.gradle.kts').read_text()
history = ''.join((root / f'MILESTONE_{i}.md').read_text() for i in range(79, 91) if (root / f'MILESTONE_{i}.md').exists())
import_start = kt.find('private fun importModelUri(uri: Uri)')
import_end = kt.find('private fun queryDisplayName', import_start)
import_block = kt[import_start:import_end]
verify_start = kt.find('fun verifyModelIntegrity(callbackId: String, fileName: String)')
verify_end = kt.find('private fun deliverModelIntegrityResult', verify_start)
verify_block = kt[verify_start:verify_end]
copy_start = kt.find('fun copyModelSha256(fileName: String)')
copy_end = kt.find('fun deleteModel(fileName: String)', copy_start)
copy_block = kt[copy_start:copy_end]
delete_start = kt.find('fun deleteModel(fileName: String): String')
delete_end = kt.find('fun showMessage(message: String)', delete_start)
delete_block = kt[delete_start:delete_end]
checks = {
    'Import state atomic flag exists': 'modelImportActive = AtomicBoolean(false)' in kt,
    'Import reserves state before starting worker': 'modelImportActive.compareAndSet(false, true)' in import_block,
    'Concurrent import is rejected with user message': 'Un import de model este deja în desfășurare' in import_block,
    'Import reservation released on completion/error': 'finally { modelImportActive.set(false) }' in import_block,
    'Import worker has stable name and daemon mode': 'name = "VideoMakerModelImport"' in import_block and 'isDaemon = true' in import_block,
    'Integrity verification refuses during import': '!modelImportActive.get() && modelIntegrityVerificationActive.compareAndSet(false, true)' in verify_block,
    'Checksum copy refuses during import': 'modelIntegrityVerificationActive.get() || modelImportActive.get()' in copy_block,
    'Model deletion refuses during import': 'modelIntegrityVerificationActive.get() || modelImportActive.get()' in delete_block,
    'Version history includes milestone 79 and current build is newer': '0.47-build-candidate' in history and 'versionCode = 58' in gradle and '0.58-build-candidate' in gradle,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
if not all(checks.values()): raise SystemExit(1)
print(f'{sum(checks.values())}/{len(checks)} milestone 79 checks passed')
