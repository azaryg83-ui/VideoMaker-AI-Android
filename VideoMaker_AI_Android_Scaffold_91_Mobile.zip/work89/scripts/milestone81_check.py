from pathlib import Path
root=Path(__file__).resolve().parents[1]
gradle=(root/'app/build.gradle.kts').read_text()
history=''.join((root/f'MILESTONE_{j}.md').read_text() for j in range(81,90) if (root/f'MILESTONE_{j}.md').exists())
source=(root/'app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
checks={
 'startup cleanup invoked before editor load': 'cleanupInterruptedModelImports()' in source and source.index('cleanupInterruptedModelImports()') < source.index('webView.loadUrl'),
 'cleanup limited to import/checksum temp artifacts': 'startsWith(".import-")' in source and 'endsWith(".sha256.tmp")' in source,
 'cleanup does not target final model files': 'file.delete()' in source and 'modelsDirectory()' in source,
 'storage reserve defined as 256 MB': '256L * 1024 * 1024' in source,
 'preflight requires reserve before import': 'available - storageReserveBytes' in source,
 'dynamic copy-time reserve check': 'currentAvailable - storageReserveBytes' in source,
 '6GB import cap remains': '6L * 1024 * 1024 * 1024' in source,
 'version bumped': '0.48-build-candidate' in history and 'versionCode = 58' in gradle and '0.58-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
