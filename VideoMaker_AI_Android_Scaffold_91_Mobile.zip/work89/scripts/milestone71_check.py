#!/usr/bin/env python3
from pathlib import Path
s=Path('app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'single worker thread retained':'ThreadPoolExecutor(1, 1' in s,
 'executor queue is non-buffering':'SynchronousQueue<Runnable>()' in s,
 'rejected requests handled safely':'catch (_: RejectedExecutionException)' in s,
 'busy response delivered to caller':'BUSY|an image generation is already running' in s,
 'generation remains off main thread':'nativeGenerationExecutor.execute' in s,
 'model path validation before scheduling':'safeModelFile(modelFileName)' in s,
 'thermal severe-state guard remains':'THERMAL_STATUS_SEVERE' in s,
 'prompt length bounded':'prompt.take(4000)' in s,
}
for name,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+name)
if not all(checks.values()): raise SystemExit('MILESTONE71_CHECK_FAIL')
print('MILESTONE71_CHECK_PASS')
