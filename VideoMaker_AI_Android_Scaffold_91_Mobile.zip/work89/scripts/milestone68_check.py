from pathlib import Path
gradle=Path('app/build.gradle.kts').read_text()
cmake=Path('app/src/main/cpp/CMakeLists.txt').read_text()
build=Path('scripts/fetch_and_build_android.sh').read_text()
checks={
 'Gradle property controls runtime linking':'videomakerLinkSdcpp' in gradle and 'VIDEOMAKER_LINK_SDCPP=' in gradle,
 'runtime link remains opt-in for normal scaffold builds':'if (linkSdcppRuntime) "ON" else "OFF"' in gradle,
 'CMake rejects missing runtime source when enabled':'VIDEOMAKER_LINK_SDCPP=ON requires SDCPP_SOURCE_DIR' in cmake,
 'native runtime build script enables linking':'-PvideomakerLinkSdcpp=true' in build,
 'runtime build script uses debug assemble task':':app:assembleDebug' in build,
}
for name,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+name)
if not all(checks.values()): raise SystemExit(1)
print('MILESTONE68_CHECK_PASS')
