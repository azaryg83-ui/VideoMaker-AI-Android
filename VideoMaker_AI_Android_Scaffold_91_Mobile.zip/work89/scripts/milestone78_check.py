#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
kt = (root / 'app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
html = (root / 'app/src/main/assets/web/index.html').read_text()
gradle = (root / 'app/build.gradle.kts').read_text()
milestone_docs = ''.join((root / f'MILESTONE_{i}.md').read_text() for i in range(78, 91) if (root / f'MILESTONE_{i}.md').exists())
verify_start = kt.find('fun verifyModelIntegrity(callbackId: String, fileName: String)')
verify_end = kt.find('private fun deliverModelIntegrityResult', verify_start)
verify_block = kt[verify_start:verify_end]
delete_start = kt.find('fun deleteModel(fileName: String): String')
delete_end = kt.find('fun showMessage(message: String)', delete_start)
delete_block = kt[delete_start:delete_end]
copy_start = kt.find('fun copyModelSha256(fileName: String)')
copy_end = kt.find('fun deleteModel(fileName: String)', copy_start)
copy_block = kt[copy_start:copy_end]
checks = {
    'Shared model-operation lock exists': 'modelFileOperationLock = Any()' in kt,
    'Integrity reservation is synchronized': 'synchronized(modelFileOperationLock)' in verify_block and 'compareAndSet(false, true)' in verify_block,
    'Hash calculation runs under operation lock': 'synchronized(modelFileOperationLock)' in verify_block and 'model.inputStream().use' in verify_block,
    'Copy SHA-256 operation uses operation lock': 'synchronized(modelFileOperationLock)' in copy_block,
    'Copy rejects active integrity verification': 'modelIntegrityVerificationActive.get()' in copy_block and 'BUSY' in copy_block,
    'Delete operation uses operation lock': 'synchronized(modelFileOperationLock)' in delete_block,
    'Delete rejects active integrity verification': 'modelIntegrityVerificationActive.get()' in delete_block and 'BUSY' in delete_block,
    'Sidecar deletion occurs only after model deletion success': 'if (deleted)' in delete_block and 'checksumDeleted' in delete_block,
    'Delete failure message preserves checksum': 'Am păstrat amprenta SHA-256' in delete_block,
    'Frontend explains copy BUSY state': "result==='BUSY'?'Verificarea SHA-256 este în desfășurare" in html,
    'Milestone 78 version baseline remains represented in history': '0.47-build-candidate' in milestone_docs and ('0.58-build-candidate' in gradle and '0.57-build-candidate' in milestone_docs),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
if not all(checks.values()): raise SystemExit(1)
print(f'{sum(checks.values())}/{len(checks)} milestone 78 checks passed')
