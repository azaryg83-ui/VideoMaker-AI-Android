from pathlib import Path
import sys
html=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
kotlin=Path('app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'native model readiness classifier exists':'private fun modelGenerationReadiness' in kotlin,
 'GGUF marked non-diffusion candidate':'not supported by this image-generation bridge' in kotlin,
 'ONNX remains unverified':'unverified-onnx' in kotlin,
 'SafeTensors pipeline-component warning':'pipeline-component' in kotlin,
 'legacy checkpoint caution':'legacy-checkpoint' in kotlin,
 'model list reports runtime linkage':'nativeStatus' in kotlin and 'engineLinked' in kotlin,
 'UI displays generation readiness':'pregătire generare:' in html,
 'model selector displays readiness':'generationReadiness||' in html,
}
for label,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+label)
if not all(checks.values()): raise SystemExit(1)
print('MILESTONE64_CHECK_PASS')
