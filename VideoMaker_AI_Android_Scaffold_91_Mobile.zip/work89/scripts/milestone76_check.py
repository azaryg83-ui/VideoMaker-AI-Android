#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
kt = (root / 'app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
html = (root / 'app/src/main/assets/web/index.html').read_text()
checks = {
    'Clipboard imports': 'import android.content.ClipboardManager' in kt and 'import android.content.ClipData' in kt,
    'SHA copy bridge': 'fun copyModelSha256(fileName: String): String' in kt,
    'Model path validation reused': 'safeModelFile(fileName)' in kt[kt.find('fun copyModelSha256'):kt.find('fun deleteModel')],
    'Stored checksum format validation': 'Regex("[a-f0-9]{64}")' in kt[kt.find('fun copyModelSha256'):kt.find('fun deleteModel')],
    'Clipboard action user-visible': 'setPrimaryClip(ClipData.newPlainText' in kt and 'SHA-256 copiat în clipboard' in kt,
    'UI copy button only when checksum exists': 'data-model-copy-sha' in html and 'm.sha256?' in html,
    'UI binds copy button to bridge': 'bridge.copyModelSha256' in html,
    'UI reports missing checksum': 'Modelul nu are un SHA-256 salvat valid.' in html,
    'Milestone 76 documentation exists': (root/'MILESTONE_76.md').exists(),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
if not all(checks.values()): raise SystemExit(1)
print(f'{sum(checks.values())}/{len(checks)} milestone 76 checks passed')
