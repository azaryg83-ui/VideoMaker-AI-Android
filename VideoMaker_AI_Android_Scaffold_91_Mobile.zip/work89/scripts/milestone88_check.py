#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
workflow=(root/".github/workflows/android-build.yml").read_text()
gradle=(root/"app/build.gradle.kts").read_text()
bootstrap=(root/"scripts/bootstrap_stable_diffusion_runtime.sh").read_text()
checks={
 "manual workflow runtime toggle": "link_sd_cpp_runtime" in workflow and "type: boolean" in workflow,
 "runtime bootstrap conditional": "bootstrap_stable_diffusion_runtime.sh" in workflow and "inputs.link_sd_cpp_runtime == true" in workflow,
 "runtime build Gradle flag": "-PvideomakerLinkSdcpp=true" in workflow,
 "lightweight build fallback": ":app:assembleDebug" in workflow and "videomakerLinkSdcpp=true" in workflow,
 "Gradle opt-in wiring": "videomakerLinkSdcpp" in gradle and "VIDEOMAKER_LINK_SDCPP" in gradle,
 "runtime bootstrap pin": "PIN=\"0d71f963af9c94941f4a67e8ea145935651dd756\"" in bootstrap,
 "runtime bootstrap API checks": "sd_generate_image" in bootstrap and "sd_result_get_image_count" in bootstrap,
 "version milestone 88 remains in history": "0.55-build-candidate" in (root/"MILESTONE_88.md").read_text(),
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+": "+name)
print(f"{sum(checks.values())}/{len(checks)} checks passed")
if not all(checks.values()): raise SystemExit(1)
