from pathlib import Path
s=Path('app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'shared strict request validator exists':'private fun validateNativeGenerationRequest(' in s,
 'blank prompt rejected':'if (prompt.isBlank()) return "prompt is empty"' in s,
 'prompt length limited to 4000':'prompt.length > 4000' in s,
 'dimensions rejected outside 256..512':'image dimensions must be between 256 and 512 pixels' in s,
 'steps rejected outside 1..20':'steps must be between 1 and 20' in s,
 'threads rejected outside 1..6':'threads must be between 1 and 6' in s,
 'async generation validates before dispatch':'val requestError = validateNativeGenerationRequest(prompt, width, height, steps, threads)' in s,
 'async no longer silently clamps request values':'val safeWidth = width\n            val safeHeight = height\n            val safeSteps = steps\n            val safeThreads = threads' in s,
 'sync bridge validates strict request':'if (requestError != null) return "ERROR|$requestError"' in s,
}
for name,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+name)
if not all(checks.values()): raise SystemExit('MILESTONE73_CHECK_FAIL')
print('MILESTONE73_CHECK_PASS')
