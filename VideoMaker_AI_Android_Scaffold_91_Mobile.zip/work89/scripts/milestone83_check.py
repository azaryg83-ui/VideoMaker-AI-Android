#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
gradle=(root/'app/build.gradle.kts').read_text()
history=''.join((root/f'MILESTONE_{j}.md').read_text() for j in range(81,90) if (root/f'MILESTONE_{j}.md').exists())
html=(root/'app/src/main/assets/web/index.html').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'storage breakdown grouped by extension': 'storageByFormat' in html and 'm.extension' in html,
 'breakdown sorted largest first': 'sort((a,b)=>b[1]-a[1])' in html,
 'format summary rendered in inventory': 'Repartizare pe format' in html and 'formatStorageSummary' in html,
 'version check accepts current milestone': '0.55-build-candidate' in history and 'versionCode = 58' in gradle and '0.58-build-candidate' in gradle,
 'milestone notes present': (root/'MILESTONE_83.md').exists(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
