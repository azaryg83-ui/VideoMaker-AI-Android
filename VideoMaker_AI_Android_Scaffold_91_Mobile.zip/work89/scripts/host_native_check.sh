#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CPP="$ROOT/app/src/main/cpp"
JAVAC_BIN="$(command -v javac || true)"
if [[ -z "$JAVAC_BIN" ]]; then
  echo "ERROR: javac/JDK required for JNI headers." >&2
  exit 2
fi
JAVA_HOME_REAL="$(dirname "$(dirname "$(readlink -f "$JAVAC_BIN")")")"
JNI_INCLUDE="$JAVA_HOME_REAL/include"
JNI_PLATFORM="$JNI_INCLUDE/linux"
if [[ ! -f "$JNI_INCLUDE/jni.h" || ! -d "$JNI_PLATFORM" ]]; then
  echo "ERROR: JNI headers not found under $JAVA_HOME_REAL" >&2
  exit 2
fi
# Keep CMake caches isolated by source tree so archived copies and working trees do not collide.
SOURCE_KEY="$(printf '%s' "$ROOT" | sha256sum | cut -c1-12)"
BUILD_DIR="${TMPDIR:-/tmp}/videomaker-ai-host-native-check-$SOURCE_KEY"
cmake -S "$CPP" -B "$BUILD_DIR" -G Ninja \
  -DCMAKE_CXX_FLAGS="-I$JNI_INCLUDE -I$JNI_PLATFORM" \
  -DVIDEOMAKER_LINK_SDCPP=OFF
cmake --build "$BUILD_DIR"
echo "HOST_NATIVE_CHECK_PASS: JNI bridge compiled as host shared library (not an Android APK)."
