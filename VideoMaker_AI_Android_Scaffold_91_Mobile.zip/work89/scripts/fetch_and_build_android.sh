#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENDOR="$ROOT/app/src/main/cpp/vendor/stable-diffusion.cpp"
# Verified upstream commit. Keep this pin stable until the Android build is proven.
SDCPP_COMMIT="0d71f963af9c94941f4a67e8ea145935651dd756"
PIN_FILE="$ROOT/SDCPP_RUNTIME_PIN.txt"
if [[ ! -f "$PIN_FILE" ]] || ! grep -q "$SDCPP_COMMIT" "$PIN_FILE"; then
  echo "ERROR: runtime commit does not match SDCPP_RUNTIME_PIN.txt" >&2; exit 3;
fi

NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [[ -z "$NDK" || ! -d "$NDK" ]]; then
  echo "ERROR: Set ANDROID_NDK_HOME (or ANDROID_NDK_ROOT) to a valid Android NDK folder." >&2
  exit 2
fi
if ! command -v git >/dev/null 2>&1; then
  echo "ERROR: git is required." >&2
  exit 2
fi
GRADLE_CMD=""
if [[ -x "$ROOT/gradlew" ]]; then
  GRADLE_CMD="$ROOT/gradlew"
elif command -v gradle >/dev/null 2>&1; then
  GRADLE_CMD="$(command -v gradle)"
else
  echo "ERROR: Gradle wrapper or system Gradle is required. Open this project in Android Studio or install Gradle." >&2
  exit 2
fi
if ! command -v cmake >/dev/null 2>&1; then
  echo "ERROR: CMake is required; install it with Android SDK tools or add it to PATH." >&2
  exit 2
fi

if [[ ! -d "$VENDOR/.git" ]]; then
  mkdir -p "$(dirname "$VENDOR")"
  git clone https://github.com/leejet/stable-diffusion.cpp "$VENDOR"
fi
# Fetch only what is needed for the pinned checkout; avoid silently building latest upstream.
git -C "$VENDOR" fetch origin "$SDCPP_COMMIT"
git -C "$VENDOR" checkout --detach "$SDCPP_COMMIT"
git -C "$VENDOR" submodule update --init --recursive

# Fail early if the pinned checkout does not expose the expected C API/CMake target.
if ! grep -q 'set(SD_LIB stable-diffusion)' "$VENDOR/CMakeLists.txt"; then
  echo "ERROR: Pinned upstream CMake no longer defines the expected stable-diffusion target." >&2
  exit 3
fi
if ! grep -q 'sd_ctx_opt_create' "$VENDOR/include/stable-diffusion.h" || \
   ! grep -q 'sd_img_gen_opt_create' "$VENDOR/include/stable-diffusion.h" || \
   ! grep -q 'sd_generate_image' "$VENDOR/include/stable-diffusion.h"; then
  echo "ERROR: Pinned upstream header does not expose the C API used by this bridge." >&2
  exit 3
fi

export ANDROID_NDK_HOME="$NDK"
cd "$ROOT"
"$GRADLE_CMD" --no-daemon -PvideomakerLinkSdcpp=true :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK" ]]; then
  echo "ERROR: Gradle finished but APK was not found: $APK" >&2
  exit 3
fi
echo "Build output: $APK"
