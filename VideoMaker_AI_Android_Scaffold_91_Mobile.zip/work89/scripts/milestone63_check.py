from pathlib import Path
s=Path('app/src/main/assets/web/index.html').read_text(encoding='utf-8')
checks={
 'compatibility matrix helper exists':'function renderRuntimeCompatibilityMatrix()' in s,
 'GGUF caution included':'Nu este candidat direct pentru generare de imagini' in s,
 'SafeTensors component caveat included':'doar o componentă a pipeline-ului' in s,
 'ONNX graph/runtime caveat included':'graful modelului, operatori și runtime' in s,
 'legacy serialization safety caution included':'verificarea de format nu certifică siguranța' in s,
 'runtime-not-integrated status retained':'runtime diffusion încă neintegrat' in s,
}
for label,ok in checks.items(): print(('PASS: ' if ok else 'FAIL: ')+label)
if not all(checks.values()): raise SystemExit(1)
print('MILESTONE63_CHECK_PASS')
