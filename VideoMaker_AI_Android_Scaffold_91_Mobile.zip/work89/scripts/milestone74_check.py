#!/usr/bin/env python3
from pathlib import Path
k=Path('app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
web=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'Android bridge exposes asynchronous SHA-256 integrity verification':'fun verifyModelIntegrity(callbackId: String, fileName: String)' in k,
 'model file path is resolved through private safe-file guard':'val model = safeModelFile(fileName)' in k,
 'saved checksum is validated as 64 hexadecimal chars':'expected.matches(Regex("[a-f0-9]{64}"))' in k,
 'SHA-256 streams file in 1 MiB chunks':'val buffer = ByteArray(1024 * 1024)' in k and 'digest.update(buffer, 0, read)' in k,
 'checksum comparison uses constant-time MessageDigest.isEqual':'MessageDigest.isEqual(expected.toByteArray(Charsets.US_ASCII), actual.toByteArray(Charsets.US_ASCII))' in k,
 'integrity result codes include MATCH and MISMATCH':'"MATCH" to' in k and '"MISMATCH" to' in k,
 'frontend exposes per-model Verify integrity button':'data-model-verify' in web and 'requestNativeModelIntegrity' in web,
 'frontend receives native integrity callback':'onNativeModelIntegrityResult' in web,
 'milestone 74 historical version recorded':'0.42 (versionCode 42)' in Path('MILESTONE_74.md').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()): raise SystemExit(1)
print(f'MILESTONE_74_PASS: {len(checks)} checks')
