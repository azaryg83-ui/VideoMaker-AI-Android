#!/usr/bin/env python3
from pathlib import Path
import sys
p=Path(__file__).resolve().parents[1]/'.github/workflows/android-build.yml'
s=p.read_text()
required=[
 'gradle/actions/setup-gradle@v4',
 'gradle-version: 8.9',
 "'platforms;android-35'",
 "'ndk;27.2.12479018'",
 ':app:assembleDebug',
 'scripts/verify_apk.sh',
 'actions/upload-artifact@v4',
 'retention-days: 30',
]
missing=[x for x in required if x not in s]
if missing:
 print('CI_WORKFLOW_CHECK_FAIL: missing '+', '.join(missing), file=sys.stderr); sys.exit(1)
if 'services.gradle.org/distributions' in s:
 print('CI_WORKFLOW_CHECK_FAIL: manual Gradle download still present', file=sys.stderr); sys.exit(1)
print('CI_WORKFLOW_CHECK_PASS: Gradle setup action, Android toolchain, APK build, APK verification and 30-day artifact upload configured.')
