#!/usr/bin/env python3
from pathlib import Path
k=Path('app/src/main/java/com/videomakerai/app/MainActivity.kt').read_text()
web=Path('app/src/main/assets/web/index.html').read_text()
g=Path('app/build.gradle.kts').read_text()
checks={
 'atomic guard exists for integrity verification':'AtomicBoolean' in k and 'modelIntegrityVerificationActive' in k,
 'guard prevents concurrent hash verification':'compareAndSet(false, true)' in k,
 'busy request reports BUSY':'\"BUSY\"' in k and 'O altă verificare SHA-256' in k,
 'worker is named and daemonized':'VideoMakerModelIntegrity' in k and 'isDaemon = true' in k,
 'frontend displays BUSY amber':'code===\'BUSY\'?\'#fbbf24\'' in web,
 'milestone 75 historical version recorded':'0.43 (versionCode 43)' in Path('MILESTONE_75.md').read_text(),
}
for n,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+n)
if not all(checks.values()): raise SystemExit(1)
print(f'MILESTONE_75_PASS: {len(checks)} checks')
