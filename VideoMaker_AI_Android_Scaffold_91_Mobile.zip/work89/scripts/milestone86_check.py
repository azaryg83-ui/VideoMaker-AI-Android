#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
gradle=(root/'app/build.gradle.kts').read_text()
history=''.join((root/f'MILESTONE_{j}.md').read_text() for j in range(81,90) if (root/f'MILESTONE_{j}.md').exists())
html=(root/'app/src/main/assets/web/index.html').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'search field exists': 'id="nativeModelSearch"' in html,
 'search matches model names': "String(m.name||'').toLowerCase().includes(modelSearch)" in html,
 'search matches extensions': "String(m.extension||'').toLowerCase().includes(modelSearch)" in html or "ext.includes(modelSearch)" in html,
 'sort choices include size descending': 'value="size-desc"' in html,
 'sort choices include size ascending': 'value="size-asc"' in html,
 'sort choices include format': 'value="format"' in html,
 'search refresh listener is wired': "$('nativeModelSearch').oninput=refreshNativeModels" in html,
 'sort refresh listener is wired': "$('nativeModelSort').onchange=refreshNativeModels" in html,
 'milestone notes present': (root/'MILESTONE_86.md').exists(),
 'version check accepts current milestone': '0.55-build-candidate' in history and 'versionCode = 58' in gradle and '0.58-build-candidate' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
