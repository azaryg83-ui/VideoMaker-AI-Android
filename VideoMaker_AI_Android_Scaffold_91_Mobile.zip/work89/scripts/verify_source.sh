#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo '== 1/4 Frontend checks =='
bash scripts/frontend_check.sh
echo '== 2/4 Native JNI host compilation =='
bash scripts/host_native_check.sh
echo '== 3/4 Android CI workflow configuration =='
python3 scripts/ci_workflow_check.py
python3 - <<'PY'
import yaml
with open('.github/workflows/android-build.yml', encoding='utf-8') as f:
    yaml.safe_load(f)
print('WORKFLOW_YAML_PARSE_PASS')
PY
echo '== 4/4 Build script syntax =='
bash -n scripts/fetch_and_build_android.sh scripts/verify_apk.sh scripts/frontend_check.sh scripts/host_native_check.sh scripts/verify_source.sh scripts/bootstrap_stable_diffusion_runtime.sh scripts/collect_android_build_diagnostics.sh
python3 scripts/milestone66_check.py
python3 scripts/milestone69_check.py
python3 scripts/milestone70_check.py
python3 scripts/milestone71_check.py
python3 scripts/milestone72_check.py
python3 scripts/milestone73_check.py
python3 scripts/milestone74_check.py
python3 scripts/milestone75_check.py
python3 scripts/milestone76_check.py
echo "SOURCE_VERIFICATION_PASS: frontend, host-native JNI, CI workflow, runtime bootstrap, native image payload contract and build scripts all passed."

python3 scripts/milestone77_check.py

python3 scripts/milestone89_check.py

python3 scripts/milestone91_check.py
