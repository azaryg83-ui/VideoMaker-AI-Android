#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APK="${1:-$ROOT/app/build/outputs/apk/debug/app-debug.apk}"
if [[ ! -f "$APK" ]]; then
  echo "ERROR: APK not found: $APK" >&2
  exit 2
fi
if ! command -v unzip >/dev/null 2>&1; then
  echo "ERROR: unzip is required to inspect the APK." >&2
  exit 2
fi
CONTENTS="$(unzip -Z1 "$APK")"
for required in \
  "lib/arm64-v8a/libvideomaker_native.so" \
  "assets/web/index.html" \
  "assets/web/manifest.json"; do
  if ! grep -Fxq "$required" <<< "$CONTENTS"; then
    echo "ERROR: APK missing expected entry: $required" >&2
    exit 3
  fi
done
if ! grep -q 'com.videomakerai.app' <<< "$CONTENTS"; then
  echo "WARNING: application package metadata not found by basic ZIP listing; use apkanalyzer/aapt for package validation." >&2
fi
sha256sum "$APK"
stat -c 'APK_SIZE_BYTES=%s' "$APK"
echo "APK_STRUCTURE_PASS: ARM64 JNI library and WebView assets are present."
