# Milestone 60 — Project Persistence Round-trip Fix

## What changed
- Project JSON schema bumped from version 4 to 5.
- Project save/autosave now preserves multi-frame storyboard shots per scene.
- Preserves scene character assignment and character variant references.
- Preserves scene notes.
- Saves production configuration: visual style, negative prompt, AI profile/size, steps, sampler, frame-planning pace/minimum, voiceover WPM and pause margin.
- Import and local autosave restoration apply saved production settings while remaining backward-compatible with older project JSON files that lack this field.

## Why
Earlier project persistence serialized only a subset of scene metadata and omitted the multi-frame storyboard, which could lose work when exporting/importing or restoring autosave. This milestone closes that data-loss gap.

## Scope / limitations
- AI diffusion generation remains not integrated natively on-device.
- Export is still JSON project format with embedded assets, not a ZIP package.
- Android runtime testing has not been performed.
