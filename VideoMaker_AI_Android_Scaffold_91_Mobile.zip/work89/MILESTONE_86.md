# Milestone 86 — Model Library Search and Sorting

- Added a searchable model-library field matching model filename and extension.
- Added sorting by name, file size (ascending/descending), and format.
- Filtering and sorting refresh the list while preserving the storage summary and model actions.
- Android-native model inference remains not integrated; this is library management only.
- Version: 0.53-build-candidate (versionCode 53).
