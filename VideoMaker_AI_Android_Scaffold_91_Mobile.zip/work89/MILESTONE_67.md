# Milestone 67 — Reproducible AI Runtime Pinning

- Centralized the stable-diffusion.cpp commit pin in `SDCPP_RUNTIME_PIN.txt`.
- Runtime bootstrap now fetches/checks out the pinned commit, initializes submodules, and refuses to record a mismatched revision.
- Android build script cross-checks its pin against the central pin file before fetching/building.
- This reduces API drift and makes runtime integration reproducible across future milestones.
- Android SDK/NDK build and on-device inference are not claimed as tested here.

- Android app version advanced to `0.37-build-candidate` / versionCode 37.
