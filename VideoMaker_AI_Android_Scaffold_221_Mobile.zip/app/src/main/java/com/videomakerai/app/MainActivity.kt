package com.videomakerai.app

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Base64
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import android.app.ActivityManager
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedInputStream
import java.security.MessageDigest
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.speech.tts.TextToSpeech
import android.media.MediaPlayer
import android.content.ContentValues
import android.provider.MediaStore
import java.util.Locale
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.SynchronousQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.RejectedExecutionException

class MainActivity : Activity() {
    private var nativeLibraryLoaded = false
    private val modelIntegrityVerificationActive = AtomicBoolean(false)
    private val modelImportActive = AtomicBoolean(false)
    private val modelFileOperationLock = Any()
    private val nativeGenerationExecutor = ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, SynchronousQueue<Runnable>(), { r -> Thread(r, "VideoMakerNativeGeneration").apply { isDaemon = true } })
    private val imageRenderExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "VideoMakerImageRender").apply { isDaemon = true } }
    private val imageRenderActive = AtomicBoolean(false)
    private external fun nativeStatus(): String
    private external fun nativeRuntimeInfo(): String
    private external fun nativeGenerateSmokeTest(modelPath: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String
    private external fun nativeGenerateImagePayload(modelPath: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String
    companion object {
        init { try { System.loadLibrary("videomaker_native") } catch (_: Throwable) { } }
    }
    private lateinit var webView: WebView
    private var localTts: TextToSpeech? = null
    private var localTtsReady = false
    private var savedSegmentPlayer: MediaPlayer? = null
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 701
    private val modelPickerRequest = 702
    private val modelExtensions = setOf("gguf", "safetensors", "ckpt", "pt", "pth", "onnx")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nativeLibraryLoaded = try { nativeStatus().isNotBlank() } catch (_: Throwable) { false }
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // This editor is bundled in app assets. Keep file access enabled only for the
        // packaged editor and block navigation away from that trusted origin.
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) webView.settings.safeBrowsingEnabled = true
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = params.acceptTypes.firstOrNull()?.takeIf { it.isNotBlank() } ?: "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, params.acceptTypes.filter { it.isNotBlank() }.toTypedArray())
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (e: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    Toast.makeText(this@MainActivity, "Nu pot deschide selectorul de fișiere.", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            private val trustedEditorPrefix = "file:///android_asset/web/"
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                // Prevent the JavaScript bridge from being exposed to arbitrary pages.
                return !url.startsWith(trustedEditorPrefix)
            }
            @Deprecated("Deprecated on newer Android versions")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return !url.startsWith(trustedEditorPrefix)
            }
        }
        localTts = TextToSpeech(this) { status ->
            localTtsReady = status == TextToSpeech.SUCCESS
            val engine = localTts
            if (localTtsReady && engine != null) {
                engine.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                    override fun onStart(utteranceId: String) { }
                    override fun onDone(utteranceId: String) {
                        runOnUiThread { webView.evaluateJavascript("window.onLocalTtsFileResult && window.onLocalTtsFileResult(${JSONObject.quote(utteranceId)}, true, '');", null) }
                    }
                    override fun onError(utteranceId: String) {
                        runOnUiThread { webView.evaluateJavascript("window.onLocalTtsFileResult && window.onLocalTtsFileResult(${JSONObject.quote(utteranceId)}, false, 'TTS synthesis error');", null) }
                    }
                    override fun onError(utteranceId: String, errorCode: Int) {
                        runOnUiThread { webView.evaluateJavascript("window.onLocalTtsFileResult && window.onLocalTtsFileResult(${JSONObject.quote(utteranceId)}, false, ${JSONObject.quote("TTS error code $errorCode")});", null) }
                    }
                })
            }
            runOnUiThread { webView.evaluateJavascript("window.onLocalTtsReady && window.onLocalTtsReady(${localTtsReady});", null) }
        }
        webView.addJavascriptInterface(NativeBridge(), "VideoMakerNative")
        setContentView(webView)
        val recoveredTempFiles = cleanupInterruptedModelImports()
        if (recoveredTempFiles > 0) Toast.makeText(this, "Recuperare spațiu: $recoveredTempFiles fișiere temporare eliminate.", Toast.LENGTH_LONG).show()
        webView.loadUrl("file:///android_asset/web/index.html")
    }

    private fun notifyImageRender(state: String, current: Int, total: Int, message: String) {
        val js = "window.onNativeImageRenderUpdate&&window.onNativeImageRenderUpdate(${JSONObject.quote(state)},$current,$total,${JSONObject.quote(message)});"
        runOnUiThread { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) { } }
    }

    private fun renderImageScenesNative(planJson: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) throw IllegalStateException("Exportul în Downloads necesită Android 10 sau mai nou")
        val plan = JSONObject(planJson)
        if (plan.optString("format") != "VideoMakerAI_RenderPlan") throw IllegalArgumentException("Plan de render invalid")
        val output = plan.optJSONObject("output") ?: throw IllegalArgumentException("Setări export lipsă")
        val dims = output.optJSONArray("dimensions") ?: throw IllegalArgumentException("Dimensiuni export lipsă")
        var width = dims.optInt(0, 0); var height = dims.optInt(1, 0)
        if (width <= 0 || height <= 0) throw IllegalArgumentException("Dimensiuni invalide")
        // First native render pass is deliberately bounded for Android phones.
        val scale = minOf(1.0, 1280.0 / maxOf(width, height), kotlin.math.sqrt(921600.0 / (width.toDouble() * height)))
        width = (width * scale).toInt().coerceAtLeast(2) and -2
        height = (height * scale).toInt().coerceAtLeast(2) and -2
        val fps = output.optInt("fps", 30).coerceIn(1, 30)
        val scenes = plan.optJSONArray("sceneDraft") ?: throw IllegalArgumentException("Planul nu conține scene")
        if (scenes.length() == 0) throw IllegalArgumentException("Nu există scene de imagine în draft")
        val imageSources = ArrayList<Pair<ByteArray, Int>>()
        var totalFrames = 0
        for (i in 0 until scenes.length()) {
            val scene = scenes.optJSONObject(i) ?: continue
            val duration = scene.optDouble("durationSeconds", 0.0)
            if (!duration.isFinite() || duration <= 0.0) continue
            val source = scene.optString("imageSource", "")
            if (!source.startsWith("data:image/")) throw IllegalArgumentException("Scena ${i + 1}: prima versiune render acceptă imagini Data URL. Atașează imaginea direct în scena draft.")
            val comma = source.indexOf(','); if (comma < 0) throw IllegalArgumentException("Scena ${i + 1}: imagine invalidă")
            val bytes = Base64.decode(source.substring(comma + 1), Base64.DEFAULT)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("Scena ${i + 1}: imagine invalidă sau nedecodabilă")
            val frames = (duration * fps).toInt().coerceAtLeast(1)
            totalFrames += frames
            if (totalFrames > 1800) throw IllegalArgumentException("Render limitat la maximum 60 secunde în această versiune")
            imageSources.add(bytes to frames)
        }
        if (imageSources.isEmpty()) throw IllegalArgumentException("Nu există imagini valide și durate renderizabile")
        notifyImageRender("start", 0, totalFrames, "Encoder H.264 pregătit · ${width}×${height} · $fps FPS · fără audio")
        val temp = File(cacheDir, "vm_render_${System.currentTimeMillis()}.mp4")
        var codec: MediaCodec? = null; var muxer: MediaMuxer? = null
        var muxerStarted = false; var videoTrack = -1; var framesDone = 0; var outputUri: Uri? = null; var outputPublished = false
        try {
            val codecInfo = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.firstOrNull { info ->
                info.isEncoder && info.supportedTypes.any { it.equals("video/avc", true) } && try { info.getCapabilitiesForType("video/avc").videoCapabilities.isSizeSupported(width, height) } catch (_: Exception) { false }
            } ?: throw IllegalStateException("Nu există encoder H.264 compatibil cu ${width}×${height}")
            val caps = codecInfo.getCapabilitiesForType("video/avc")
            val color = when {
                caps.colorFormats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) -> MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar
                caps.colorFormats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar) -> MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
                else -> throw IllegalStateException("Encoder H.264 fără YUV420 planar/semi-planar buffer input")
            }
            val format = MediaFormat.createVideoFormat("video/avc", width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, color); setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps); setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            }
            codec = MediaCodec.createByCodecName(codecInfo.name); codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); codec.start()
            muxer = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val bufferInfo = MediaCodec.BufferInfo(); var outputEos = false
            lateinit var drainEncoder: (Boolean) -> Boolean
            drainEncoder = { waitForOutput ->
                var eosSeen = false
                while (true) {
                    val outIndex = codec!!.dequeueOutputBuffer(bufferInfo, if (waitForOutput) 10000 else 0)
                    when {
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!waitForOutput) break else break }
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (muxerStarted) throw IllegalStateException("Encoder output format changed de două ori")
                            videoTrack = muxer!!.addTrack(codec!!.outputFormat); muxer!!.start(); muxerStarted = true
                        }
                        outIndex >= 0 -> {
                            val out = codec!!.getOutputBuffer(outIndex)
                            if (out != null && bufferInfo.size > 0 && muxerStarted && bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                                out.position(bufferInfo.offset); out.limit(bufferInfo.offset + bufferInfo.size); muxer!!.writeSampleData(videoTrack, out, bufferInfo)
                            }
                            if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) eosSeen = true
                            codec!!.releaseOutputBuffer(outIndex, false)
                            if (eosSeen) break
                        }
                    }
                }
                eosSeen
            }
            val frameBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(frameBitmap); val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            fun feedFrame(bitmap: Bitmap, frameIndex: Int) {
                canvas.drawColor(Color.BLACK)
                val scaleFit = minOf(width.toFloat()/bitmap.width, height.toFloat()/bitmap.height)
                val drawW = (bitmap.width*scaleFit).toInt(); val drawH=(bitmap.height*scaleFit).toInt()
                val dstRect=Rect((width-drawW)/2,(height-drawH)/2,(width+drawW)/2,(height+drawH)/2)
                canvas.drawBitmap(bitmap,Rect(0,0,bitmap.width,bitmap.height),dstRect,paint)
                val yuv=argbBitmapToYuv420(frameBitmap,color)
                var inputIndex=-1
                while(inputIndex<0){ inputIndex=codec!!.dequeueInputBuffer(10000); if(inputIndex<0) drainEncoder(false) }
                val input=codec!!.getInputBuffer(inputIndex) ?: throw IllegalStateException("Encoder input buffer indisponibil")
                input.clear(); if(yuv.size>input.remaining()) throw IllegalStateException("Buffer YUV insuficient")
                input.put(yuv); codec!!.queueInputBuffer(inputIndex,0,yuv.size,frameIndex*1_000_000L/fps,0)
                drainEncoder(false)
            }
            imageSources.forEach { (bytes, count) ->
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                val sample = calculateImageSampleSize(bounds.outWidth, bounds.outHeight, width, height)
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: throw IllegalStateException("Imaginea nu mai poate fi decodată în render")
                try { repeat(count) { feedFrame(bitmap,framesDone); framesDone++; if(framesDone%maxOf(1,fps)==0) notifyImageRender("progress",framesDone,totalFrames,"Render ${framesDone}/${totalFrames} cadre") } } finally { bitmap.recycle() }
            }
            var inputEos=false
            while(!inputEos){ val idx=codec!!.dequeueInputBuffer(10000); if(idx>=0){codec!!.queueInputBuffer(idx,0,0,framesDone*1_000_000L/fps,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputEos=true} else drainEncoder(false) }
            while(!outputEos) outputEos=drainEncoder(true)
            frameBitmap.recycle()
            if(!muxerStarted || !temp.exists() || temp.length()<1024) throw IllegalStateException("Encoderul nu a produs un MP4 valid")
            val values=ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME,"VideoMakerAI_render_${System.currentTimeMillis()}.mp4");put(MediaStore.Downloads.MIME_TYPE,"video/mp4");put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VideoMakerAI/Renders");put(MediaStore.Downloads.IS_PENDING,1) }
            val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values) ?: throw IllegalStateException("Nu s-a putut crea fișierul MP4 în Downloads")
            outputUri=uri
            contentResolver.openOutputStream(uri)?.use { out -> temp.inputStream().use { it.copyTo(out) } } ?: throw IllegalStateException("Nu s-a putut scrie fișierul MP4")
            values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);contentResolver.update(uri,values,null,null);outputPublished=true
            notifyImageRender("done",framesDone,totalFrames,"MP4 salvat în Downloads/VideoMakerAI/Renders · ${width}×${height} · $fps FPS · fără audio")
        } finally {
            try { codec?.stop() } catch (_: Exception) { }; try { codec?.release() } catch (_: Exception) { }
            try { muxer?.stop() } catch (_: Exception) { }; try { muxer?.release() } catch (_: Exception) { }
            if(outputUri!=null&&!outputPublished) try { contentResolver.delete(outputUri!!,null,null) } catch (_: Exception) { }
            temp.delete()
        }
    }


    private fun calculateImageSampleSize(sourceWidth: Int, sourceHeight: Int, targetWidth: Int, targetHeight: Int): Int {
        if (sourceWidth <= 0 || sourceHeight <= 0) return 1
        var sample = 1
        while (sourceWidth / (sample * 2) >= targetWidth && sourceHeight / (sample * 2) >= targetHeight) sample *= 2
        return sample.coerceAtLeast(1)
    }

    private fun argbBitmapToYuv420(bitmap: Bitmap, colorFormat: Int): ByteArray {
        val w=bitmap.width; val h=bitmap.height; val pixels=IntArray(w*h); bitmap.getPixels(pixels,0,w,0,0,w,h)
        val frameSize=w*h; val out=ByteArray(frameSize+frameSize/2); val planar=colorFormat==MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar
        var yIndex=0; var uIndex=frameSize; var vIndex=frameSize+frameSize/4
        for(y in 0 until h) for(x in 0 until w){ val c=pixels[y*w+x]; val r=(c shr 16) and 255; val g=(c shr 8) and 255; val b=c and 255
            out[yIndex++]=(((66*r+129*g+25*b+128) shr 8)+16).coerceIn(0,255).toByte()
            if(y%2==0&&x%2==0){ val u=((( -38*r-74*g+112*b+128) shr 8)+128).coerceIn(0,255); val v=(((112*r-94*g-18*b+128) shr 8)+128).coerceIn(0,255)
                if(planar){out[uIndex++]=u.toByte();out[vIndex++]=v.toByte()}else{out[uIndex++]=u.toByte();out[uIndex++]=v.toByte()} }
        }
        return out
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == modelPickerRequest) {
            if (resultCode == RESULT_OK && data?.data != null) importModelUri(data.data!!)
            else runOnUiThread { webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Import anulat.');", null) }
            return
        }
        if (requestCode != filePickerRequest) return
        val callback = fileChooserCallback ?: return
        fileChooserCallback = null
        if (resultCode != RESULT_OK || data == null) {
            callback.onReceiveValue(null)
            return
        }
        val uris = data.clipData?.let { clip ->
            Array(clip.itemCount) { index -> clip.getItemAt(index).uri }
        } ?: data.data?.let { arrayOf(it) }
        callback.onReceiveValue(uris)
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun localTtsStatus(): String = if (localTtsReady) "ready" else "initializing-or-unavailable"

        @JavascriptInterface
        fun speakLocalSegment(text: String, language: String, voicePreference: String, tone: String): String {
            if (!localTtsReady || localTts == null) return "TTS_NOT_READY"
            val engine = localTts ?: return "TTS_NOT_READY"
            val lang = language.trim().lowercase().let { if (it == "auto" || it == "other" || it.isBlank()) "ro" else it }
            val locale = when (lang) {
                "zh" -> Locale.CHINESE; "ja" -> Locale.JAPANESE; "ko" -> Locale.KOREAN
                "ar" -> Locale("ar"); "la" -> Locale("la"); "uk" -> Locale("uk")
                else -> Locale(lang)
            }
            val availability = engine.setLanguage(locale)
            if (availability == TextToSpeech.LANG_MISSING_DATA || availability == TextToSpeech.LANG_NOT_SUPPORTED) return "LANGUAGE_UNAVAILABLE:$lang"
            val voices = engine.voices?.filter { it.locale.language == locale.language }.orEmpty()
            val preferred = voicePreference.lowercase()
            val selected = voices.firstOrNull { v ->
                val name = v.name.lowercase()
                if (preferred.contains("feminin")) name.contains("female") || name.contains("woman") || name.contains("femin")
                else if (preferred.contains("masculin")) name.contains("male") || name.contains("man") || name.contains("mascul")
                else false
            } ?: voices.firstOrNull()
            if (selected != null) try { engine.voice = selected } catch (_: Exception) { }
            val t = tone.lowercase()
            engine.setPitch(if (t.contains("grav") || t.contains("autoritar")) 0.85f else if (t.contains("energ")) 1.12f else 1.0f)
            engine.setSpeechRate(if (t.contains("calm") || t.contains("lent") || t.contains("mister")) 0.88f else if (t.contains("energ")) 1.08f else 1.0f)
            engine.speak(text.take(4000), TextToSpeech.QUEUE_FLUSH, null, "vm-preview-${System.currentTimeMillis()}")
            return "SPEAKING"
        }

        @JavascriptInterface
        fun synthesizeLocalSegmentToFile(text: String, language: String, voicePreference: String, tone: String, segmentId: String): String {
            if (!localTtsReady || localTts == null) return "TTS_NOT_READY"
            val engine = localTts ?: return "TTS_NOT_READY"
            val lang = language.trim().lowercase().let { if (it == "auto" || it == "other" || it.isBlank()) "ro" else it }
            val locale = when (lang) {
                "zh" -> Locale.CHINESE; "ja" -> Locale.JAPANESE; "ko" -> Locale.KOREAN
                "ar" -> Locale("ar"); "la" -> Locale("la"); "uk" -> Locale("uk")
                else -> Locale(lang)
            }
            val availability = engine.setLanguage(locale)
            if (availability == TextToSpeech.LANG_MISSING_DATA || availability == TextToSpeech.LANG_NOT_SUPPORTED) return "LANGUAGE_UNAVAILABLE:$lang"
            val voices = engine.voices?.filter { it.locale.language == locale.language }.orEmpty()
            val preferred = voicePreference.lowercase()
            val selected = voices.firstOrNull { v ->
                val name = v.name.lowercase()
                if (preferred.contains("feminin")) name.contains("female") || name.contains("woman") || name.contains("femin")
                else if (preferred.contains("masculin")) name.contains("male") || name.contains("man") || name.contains("mascul")
                else false
            } ?: voices.firstOrNull()
            if (selected != null) try { engine.voice = selected } catch (_: Exception) { }
            val t = tone.lowercase()
            engine.setPitch(if (t.contains("grav") || t.contains("autoritar")) 0.85f else if (t.contains("energ")) 1.12f else 1.0f)
            engine.setSpeechRate(if (t.contains("calm") || t.contains("lent") || t.contains("mister")) 0.88f else if (t.contains("energ")) 1.08f else 1.0f)
            val safeId = segmentId.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.take(48).ifBlank { "segment" }
            val utteranceId = "vm-audio-$safeId-${System.currentTimeMillis()}"
            val folder = File(filesDir, "voice_segments").apply { mkdirs() }
            val output = File(folder, "$safeId.wav")
            if (output.exists()) output.delete()
            val result = try { engine.synthesizeToFile(text.take(4000), Bundle(), output, utteranceId) } catch (_: Throwable) { TextToSpeech.ERROR }
            if (result != TextToSpeech.SUCCESS) return "SYNTHESIS_FAILED:$result"
            return "QUEUED:$utteranceId"
        }

        @JavascriptInterface
        fun getSavedVoiceSegmentPath(segmentId: String): String {
            val safeId = segmentId.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.take(48)
            val file = File(File(filesDir, "voice_segments"), "$safeId.wav")
            return if (file.exists() && file.isFile) file.absolutePath else "NOT_FOUND"
        }

        @JavascriptInterface
        fun playSavedVoiceSegment(segmentId: String): String {
            val safeId = segmentId.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.take(48)
            val file = File(File(filesDir, "voice_segments"), "$safeId.wav")
            if (!file.exists() || !file.isFile) return "NOT_FOUND"
            return try {
                savedSegmentPlayer?.release()
                savedSegmentPlayer = MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setOnCompletionListener { mp -> try { mp.release() } catch (_: Exception) {}; if (savedSegmentPlayer === mp) savedSegmentPlayer = null }
                    prepare()
                    start()
                }
                "PLAYING_SAVED_WAV"
            } catch (e: Exception) { try { savedSegmentPlayer?.release() } catch (_: Exception) {}; savedSegmentPlayer = null; "PLAY_ERROR:${e.message ?: "unknown"}" }
        }

        @JavascriptInterface
        fun exportSavedVoiceSegment(segmentId: String): String {
            val safeId = segmentId.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.take(48)
            val source = File(File(filesDir, "voice_segments"), "$safeId.wav")
            if (!source.exists() || !source.isFile) return "NOT_FOUND"
            return try {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, "$safeId.wav")
                    put(MediaStore.Downloads.MIME_TYPE, "audio/wav")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VideoMakerAI/VoiceSegments")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return "EXPORT_FAILED:insert"
                contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } } ?: return "EXPORT_FAILED:stream"
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                "EXPORTED_TO_DOWNLOADS"
            } catch (e: Exception) { "EXPORT_FAILED:${e.message ?: "unknown"}" }
        }

        private data class WavParts(val fmt: ByteArray, val data: ByteArray, val formatCode: Int, val channels: Int, val sampleRate: Int, val bitsPerSample: Int)
        private fun readWavParts(file: File): WavParts? {
            val bytes = file.readBytes()
            if (bytes.size < 44 || String(bytes, 0, 4, Charsets.US_ASCII) != "RIFF" || String(bytes, 8, 4, Charsets.US_ASCII) != "WAVE") return null
            var pos = 12; var fmt: ByteArray? = null; var data: ByteArray? = null
            while (pos + 8 <= bytes.size) {
                val id = String(bytes, pos, 4, Charsets.US_ASCII)
                val size = (bytes[pos+4].toInt() and 255) or ((bytes[pos+5].toInt() and 255) shl 8) or ((bytes[pos+6].toInt() and 255) shl 16) or ((bytes[pos+7].toInt() and 255) shl 24)
                val start = pos + 8; if (size < 0 || start + size > bytes.size) return null
                if (id == "fmt ") fmt = bytes.copyOfRange(start, start + size)
                if (id == "data") data = bytes.copyOfRange(start, start + size)
                pos = start + size + (size and 1)
            }
            val f = fmt ?: return null; val d = data ?: return null
            if (f.size < 16) return null
            fun u16(i:Int)= (f[i].toInt() and 255) or ((f[i+1].toInt() and 255) shl 8)
            fun u32(i:Int)= (f[i].toInt() and 255) or ((f[i+1].toInt() and 255) shl 8) or ((f[i+2].toInt() and 255) shl 16) or ((f[i+3].toInt() and 255) shl 24)
            return WavParts(f,d,u16(0),u16(2),u32(4),u16(14))
        }
        private fun writeMergedWav(output: File, firstFmt: ByteArray, audio: ByteArray) {
            val riffSize = 4 + 8 + firstFmt.size + 8 + audio.size
            output.outputStream().use { out ->
                fun le32(v:Int){ out.write(byteArrayOf(v.toByte(),(v shr 8).toByte(),(v shr 16).toByte(),(v shr 24).toByte())) }
                out.write("RIFF".toByteArray(Charsets.US_ASCII)); le32(riffSize); out.write("WAVE".toByteArray(Charsets.US_ASCII))
                out.write("fmt ".toByteArray(Charsets.US_ASCII)); le32(firstFmt.size); out.write(firstFmt)
                out.write("data".toByteArray(Charsets.US_ASCII)); le32(audio.size); out.write(audio)
            }
        }
        @JavascriptInterface
        fun mergeSavedVoiceSegments(segmentIdsCsv: String): String {
            val ids = segmentIdsCsv.split(',').map { it.trim().filter { c -> c.isLetterOrDigit() || c == '-' || c == '_' }.take(48) }.filter { it.isNotBlank() }
            if (ids.isEmpty()) return "NO_SEGMENTS"
            val folder = File(filesDir, "voice_segments")
            val parts = mutableListOf<WavParts>()
            for (id in ids) { val f=File(folder,"$id.wav"); if (!f.exists()) return "MISSING_SEGMENT:$id"; val p=readWavParts(f) ?: return "INVALID_WAV:$id"; parts.add(p) }
            val base=parts.first()
            if (base.formatCode != 1) return "UNSUPPORTED_FORMAT:only PCM WAV is supported"
            if (parts.any { it.formatCode != base.formatCode || it.channels != base.channels || it.sampleRate != base.sampleRate || it.bitsPerSample != base.bitsPerSample || !it.fmt.contentEquals(base.fmt) }) return "FORMAT_MISMATCH:segments must have identical PCM format"
            if (parts.any { it.bitsPerSample !in listOf(8,16,24,32) }) return "UNSUPPORTED_FORMAT:PCM bit depth"
            val total = parts.sumOf { it.data.size.toLong() }; if (total > Int.MAX_VALUE - 44) return "TOO_LARGE"
            val audio=ByteArray(total.toInt()); var offset=0; parts.forEach { it.data.copyInto(audio,offset); offset+=it.data.size }
            val out=File(folder,"merged_voiceover.wav")
            return try { writeMergedWav(out,base.fmt,audio); "MERGED:${out.absolutePath}:${ids.size}" } catch(e:Exception){ "MERGE_FAILED:${e.message ?: "unknown"}" }
        }
        @JavascriptInterface
        fun analyzeMergedVoiceoverActivity(): String {
            val file=File(File(filesDir,"voice_segments"),"merged_voiceover.wav")
            val p=readWavParts(file) ?: return "NOT_FOUND_OR_INVALID"
            if(p.formatCode!=1 || p.bitsPerSample !in listOf(8,16,24,32) || p.sampleRate<=0 || p.channels<=0) return "UNSUPPORTED_FORMAT"
            val bytesPerSample=p.bitsPerSample/8; val frameBytes=bytesPerSample*p.channels
            if(frameBytes<=0 || p.data.size<frameBytes) return "EMPTY_AUDIO"
            val windowFrames=maxOf(1,p.sampleRate/20); val totalFrames=p.data.size/frameBytes
            fun sampleAt(offset:Int):Double {
                val raw=when(p.bitsPerSample){
                    8 -> (p.data[offset].toInt() and 255)-128
                    16 -> ((p.data[offset].toInt() and 255) or ((p.data[offset+1].toInt() and 255) shl 8)).toShort().toInt()
                    24 -> { val v=(p.data[offset].toInt() and 255) or ((p.data[offset+1].toInt() and 255) shl 8) or ((p.data[offset+2].toInt() and 255) shl 16); if(v and 0x800000!=0) v or -0x1000000 else v }
                    else -> (p.data[offset].toInt() and 255) or ((p.data[offset+1].toInt() and 255) shl 8) or ((p.data[offset+2].toInt() and 255) shl 16) or (p.data[offset+3].toInt() shl 24)
                }; val scale=when(p.bitsPerSample){8->128.0;16->32768.0;24->8388608.0;else->2147483648.0}; return raw/scale
            }
            val active=mutableListOf<Pair<Int,Int>>(); var start=-1; var frame=0
            while(frame<totalFrames){ val end=minOf(totalFrames,frame+windowFrames); var sum=0.0; var count=0
                for(f in frame until end) for(ch in 0 until p.channels){ sum+=sampleAt(f*frameBytes+ch*bytesPerSample).let{it*it}; count++ }
                val rms=if(count>0) kotlin.math.sqrt(sum/count) else 0.0; val speechLike=rms>0.012
                if(speechLike && start<0) start=frame
                if(!speechLike && start>=0){ active.add(start to frame); start=-1 }
                frame=end
            }; if(start>=0) active.add(start to totalFrames)
            val merged=mutableListOf<Pair<Int,Int>>(); for(a in active){ if(merged.isNotEmpty() && (a.first-merged.last().second).toDouble()/p.sampleRate<0.18){val last=merged.removeAt(merged.lastIndex);merged.add(last.first to a.second)}else merged.add(a)}
            val arr=org.json.JSONArray(); merged.forEach{(a,b)->arr.put(org.json.JSONObject().put("start",a.toDouble()/p.sampleRate).put("end",b.toDouble()/p.sampleRate).put("duration",(b-a).toDouble()/p.sampleRate))}; return arr.toString()
        }

        @JavascriptInterface
        fun playMergedVoiceover(): String {
            val file = File(File(filesDir, "voice_segments"), "merged_voiceover.wav")
            if (!file.exists() || !file.isFile) return "NOT_FOUND"
            return try {
                savedSegmentPlayer?.release()
                savedSegmentPlayer = MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setOnCompletionListener { mp -> try { mp.release() } catch (_: Exception) {}; if (savedSegmentPlayer === mp) savedSegmentPlayer = null }
                    prepare()
                    start()
                }
                "PLAYING_MERGED_VOICEOVER"
            } catch (e: Exception) { try { savedSegmentPlayer?.release() } catch (_: Exception) {}; savedSegmentPlayer = null; "PLAY_ERROR:${e.message ?: "unknown"}" }
        }
        @JavascriptInterface
        fun pauseMergedVoiceover(): String { return try { val p=savedSegmentPlayer; if(p!=null && p.isPlaying){p.pause();"PAUSED_MERGED_VOICEOVER"}else "NOT_PLAYING" } catch(e:Exception){"PAUSE_ERROR:${e.message ?: "unknown"}"} }
        @JavascriptInterface
        fun resumeMergedVoiceover(): String { return try { val p=savedSegmentPlayer; if(p!=null && !p.isPlaying){p.start();"RESUMED_MERGED_VOICEOVER"}else "NOT_PAUSED" } catch(e:Exception){"RESUME_ERROR:${e.message ?: "unknown"}"} }
        @JavascriptInterface
        fun seekMergedVoiceover(seconds: Double): String { return try { val p=savedSegmentPlayer ?: return "NOT_PLAYING"; val ms=(seconds.coerceAtLeast(0.0)*1000.0).toInt().coerceAtMost(p.duration); p.seekTo(ms); "SEEKED_MERGED_VOICEOVER:$ms" } catch(e:Exception){"SEEK_ERROR:${e.message ?: "unknown"}"} }
        @JavascriptInterface
        fun getMergedVoiceoverDurationSeconds(): Double { return try { val f=File(File(filesDir,"voice_segments"),"merged_voiceover.wav"); if(!f.exists()) 0.0 else MediaPlayer().run { setDataSource(f.absolutePath); prepare(); val d=duration/1000.0; release(); d } } catch(_:Exception){0.0} }

        @JavascriptInterface
        fun exportMergedVoiceover(): String {
            val source=File(File(filesDir,"voice_segments"),"merged_voiceover.wav"); if(!source.exists()) return "NOT_FOUND"
            return try {
                val values=ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME,"voiceover_merged.wav"); put(MediaStore.Downloads.MIME_TYPE,"audio/wav"); put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VideoMakerAI"); put(MediaStore.Downloads.IS_PENDING,1) }
                val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values) ?: return "EXPORT_FAILED:insert"
                contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } } ?: return "EXPORT_FAILED:stream"
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING,0); contentResolver.update(uri,values,null,null); "EXPORTED_MERGED_WAV"
            } catch(e:Exception){ "EXPORT_FAILED:${e.message ?: "unknown"}" }
        }
        @JavascriptInterface
        fun stopLocalTts() { try { localTts?.stop() } catch (_: Exception) { }; try { savedSegmentPlayer?.stop() } catch (_: Exception) {}; try { savedSegmentPlayer?.release() } catch (_: Exception) {}; savedSegmentPlayer = null }
        @JavascriptInterface
        fun renderImageScenesMp4(renderPlanJson: String): String {
            if (!imageRenderActive.compareAndSet(false, true)) return "RENDER_BUSY"
            return try {
                imageRenderExecutor.execute {
                    try {
                        renderImageScenesNative(renderPlanJson)
                    } catch (e: Throwable) {
                        notifyImageRender("error", 0, 0, e.message ?: "Render error")
                    } finally {
                        imageRenderActive.set(false)
                    }
                }
                "RENDER_STARTED"
            } catch (e: Exception) {
                imageRenderActive.set(false)
                "RENDER_START_FAILED:${e.message ?: "unknown"}"
            }
        }

        @JavascriptInterface
        fun getImageRenderStatus(): String = if (imageRenderActive.get()) "RENDER_RUNNING" else "RENDER_IDLE"

        @JavascriptInterface
        fun getCapabilities(): String {
            val info = JSONObject()
            info.put("nativeShell", true)
            info.put("diffusionEngine", false)
            info.put("nativeBridgeLibraryLoaded", nativeLibraryLoaded)
            info.put("nativeBridgeStatus", if (nativeLibraryLoaded) nativeStatus() else "native-library-not-loaded")
            info.put("nativeRuntimeInfo", if (nativeLibraryLoaded) nativeRuntimeInfo() else "JNI library unavailable")
            info.put("status", "android-shell-jni-boundary")
            info.put("manufacturer", Build.MANUFACTURER)
            info.put("model", Build.MODEL)
            info.put("androidVersion", Build.VERSION.RELEASE)
            info.put("sdk", Build.VERSION.SDK_INT)
            info.put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown")
            val cpuInfo = try { File("/proc/cpuinfo").readText() } catch (_: Exception) { "" }
            val cpuFlags = Regex("(?im)^\\s*(Features|flags)\\s*:\\s*(.+)$").findAll(cpuInfo)
                .map { it.groupValues[2].lowercase().split(Regex("\\s+")) }.flatten().toSet()
            info.put("cpuDotprod", cpuFlags.contains("asimddp") || cpuFlags.contains("dotprod"))
            info.put("cpuFp16", cpuFlags.contains("fphp") || cpuFlags.contains("asimdhp"))
            info.put("cpuNeon", cpuFlags.contains("asimd") || cpuFlags.contains("neon"))
            info.put("cpuFeatureDetection", if (cpuFlags.isEmpty()) "unavailable" else "read-from-proc-cpuinfo")
            info.put("webViewFilePicker", true)
            val activityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            info.put("totalRamBytes", memoryInfo.totalMem)
            info.put("availableRamBytes", memoryInfo.availMem)
            info.put("lowMemory", memoryInfo.lowMemory)
            info.put("ramThresholdBytes", memoryInfo.threshold)
            info.put("availableModelStorageBytes", android.os.StatFs(filesDir.absolutePath).availableBytes)
            info.put("engineStatus", "not-integrated")
            info.put("modelImportSupport", true)
            info.put("modelsStoredPrivately", true)
            info.put("modelImportFormats", "gguf,safetensors,ckpt,pt,pth,onnx")
            val runtime = Runtime.getRuntime()
            info.put("appMaxHeapBytes", runtime.maxMemory())
            info.put("appUsedHeapBytes", runtime.totalMemory() - runtime.freeMemory())
            info.put("appFreeHeapBytes", runtime.freeMemory())
            info.put("processId", Process.myPid())
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                info.put("thermalStatus", powerManager.currentThermalStatus)
                info.put("thermalStatusLabel", thermalLabel(powerManager.currentThermalStatus))
            } else {
                info.put("thermalStatus", -1)
                info.put("thermalStatusLabel", "unsupported")
            }
            info.put("note", "Native shell diagnostics available; AI engine not integrated")
            return info.toString()
        }

        @JavascriptInterface
        fun engineStatus(): String = if (nativeLibraryLoaded) nativeStatus() else "native-library-not-loaded; diffusion-runtime-not-integrated"

        @JavascriptInterface
        fun nativeInferenceSmokeTest(modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String {
            if (!nativeLibraryLoaded) return "ERROR: native bridge unavailable"
            val model = safeModelFile(modelFileName)
                ?: return "ERROR: invalid model filename or model path outside private library"
            if (!model.exists() || !model.isFile) return "ERROR: model file not found in app-private models folder"
            val requestError = validateNativeGenerationRequest(prompt, width, height, steps, threads)
            if (requestError != null) return "ERROR: $requestError"
            return try { nativeGenerateSmokeTest(model.absolutePath, prompt, width, height, steps, seed, threads) }
            catch (e: Throwable) { "ERROR: ${e.message ?: "native call failed"}" }
        }

        @JavascriptInterface
        fun getThermalStatus(): String {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "unsupported"
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            return thermalLabel(powerManager.currentThermalStatus)
        }

        @JavascriptInterface
        fun nativeGenerateImagePayloadAsync(callbackId: String, modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int) {
            val safeCallbackId = callbackId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64)
            if (safeCallbackId.isBlank()) return
            if (!nativeLibraryLoaded) {
                deliverNativeGenerationResult(safeCallbackId, "NOT_READY|native library not loaded")
                return
            }
            val model = safeModelFile(modelFileName)
            if (model == null || !model.exists() || !model.isFile) {
                deliverNativeGenerationResult(safeCallbackId, "ERROR|invalid model filename or model path outside private library")
                return
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val thermal = (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus
                if (thermal >= PowerManager.THERMAL_STATUS_SEVERE) {
                    deliverNativeGenerationResult(safeCallbackId, "THERMAL_BLOCKED|phone thermal status is severe; cool the device before generating")
                    return
                }
            }
            val requestError = validateNativeGenerationRequest(prompt, width, height, steps, threads)
            if (requestError != null) {
                deliverNativeGenerationResult(safeCallbackId, "ERROR|$requestError")
                return
            }
            val safeWidth = width
            val safeHeight = height
            val safeSteps = steps
            val safeThreads = threads
            try {
                nativeGenerationExecutor.execute {
                    val result = try {
                        this@MainActivity.nativeGenerateImagePayload(model.absolutePath, prompt.take(4000), safeWidth, safeHeight, safeSteps, seed, safeThreads)
                    } catch (e: Throwable) {
                        "ERROR|${e.message ?: "native generation failed"}"
                    }
                    deliverNativeGenerationResult(safeCallbackId, result)
                }
            } catch (_: RejectedExecutionException) {
                deliverNativeGenerationResult(safeCallbackId, "BUSY|an image generation is already running; wait for it to finish")
            }
        }

        private fun deliverNativeGenerationResult(callbackId: String, payload: String) {
            runOnUiThread {
                val quotedId = JSONObject.quote(callbackId)
                val quotedPayload = JSONObject.quote(payload)
                webView.evaluateJavascript("window.onNativeGenerationResult && window.onNativeGenerationResult($quotedId,$quotedPayload);", null)
            }
        }

        @JavascriptInterface
        fun nativeGenerateImagePayload(modelFileName: String, prompt: String, width: Int, height: Int, steps: Int, seed: Long, threads: Int): String {
            if (!nativeLibraryLoaded) return "NOT_READY|native library not loaded"
            val safeName = modelFileName.replace("/", "").replace("\\", "")
            val model = File(modelsDirectory(), safeName)
            if (!model.exists() || !model.isFile) return "ERROR|model file not found in app-private models folder"
            val requestError = validateNativeGenerationRequest(prompt, width, height, steps, threads)
            if (requestError != null) return "ERROR|$requestError"
            return try { this@MainActivity.nativeGenerateImagePayload(model.absolutePath, prompt, width, height, steps, seed, threads) }
            catch (e: Throwable) { "ERROR|${e.message ?: "native generation failed"}" }
        }

        @JavascriptInterface
        fun requestModelImport() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                try { startActivityForResult(intent, modelPickerRequest) }
                catch (e: Exception) { webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Selector de fișiere indisponibil.');", null) }
            }
        }

        @JavascriptInterface
        fun listModels(): String = modelListJson()

        @JavascriptInterface
        fun verifyModelIntegrity(callbackId: String, fileName: String) {
            val safeCallbackId = callbackId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64)
            if (safeCallbackId.isBlank()) return
            val model = safeModelFile(fileName)
            if (model == null || !model.exists() || !model.isFile) {
                deliverModelIntegrityResult(safeCallbackId, fileName, "INVALID_FILE", "Fișierul model nu este găsit în biblioteca privată.")
                return
            }
            val reserved = synchronized(modelFileOperationLock) {
                !modelImportActive.get() && modelIntegrityVerificationActive.compareAndSet(false, true)
            }
            if (!reserved) {
                deliverModelIntegrityResult(safeCallbackId, model.name, "BUSY", "O altă verificare SHA-256 este în desfășurare. Așteaptă să se termine.")
                return
            }
            Thread {
                val result = try {
                    synchronized(modelFileOperationLock) {
                    if (!model.exists() || !model.isFile) return@synchronized "INVALID_FILE" to "Modelul nu mai există în biblioteca privată."
                    val sidecar = File(modelsDirectory(), model.name + ".sha256")
                    val expected = if (sidecar.exists()) sidecar.readText().trim().lowercase() else ""
                    if (!expected.matches(Regex("[a-f0-9]{64}"))) {
                        "NO_CHECKSUM" to "Nu există o amprentă SHA-256 validă salvată la import."
                    } else {
                        val digest = MessageDigest.getInstance("SHA-256")
                        model.inputStream().use { input ->
                            val buffer = ByteArray(1024 * 1024)
                            while (true) {
                                val read = input.read(buffer)
                                if (read < 0) break
                                digest.update(buffer, 0, read)
                            }
                        }
                        val actual = digest.digest().joinToString("") { "%02x".format(it) }
                        if (MessageDigest.isEqual(expected.toByteArray(Charsets.US_ASCII), actual.toByteArray(Charsets.US_ASCII)))
                            "MATCH" to "Integritate confirmată: SHA-256 coincide cu amprenta de la import."
                        else "MISMATCH" to "ALERTĂ: amprenta SHA-256 nu coincide. Fișierul poate fi modificat sau deteriorat. Nu îl folosi."
                    }
                    }
                } catch (e: Exception) {
                    "ERROR" to ("Verificare nereușită: " + (e.message ?: "eroare de citire"))
                }
                deliverModelIntegrityResult(safeCallbackId, model.name, result.first, result.second)
                modelIntegrityVerificationActive.set(false)
            }.apply { isDaemon = true; name = "VideoMakerModelIntegrity" }.start()
        }

        private fun deliverModelIntegrityResult(callbackId: String, modelName: String, code: String, message: String) {
            runOnUiThread {
                val id = JSONObject.quote(callbackId)
                val name = JSONObject.quote(modelName)
                val status = JSONObject.quote(code)
                val text = JSONObject.quote(message)
                webView.evaluateJavascript("window.onNativeModelIntegrityResult && window.onNativeModelIntegrityResult($id,$name,$status,$text);", null)
            }
        }

        @JavascriptInterface
        fun copyModelSha256(fileName: String): String = synchronized(modelFileOperationLock) {
            val model = safeModelFile(fileName) ?: return@synchronized "INVALID_FILE"
            if (modelIntegrityVerificationActive.get() || modelImportActive.get()) return@synchronized "BUSY"
            val sidecar = File(modelsDirectory(), model.name + ".sha256")
            val checksum = if (sidecar.exists() && sidecar.isFile) sidecar.readText().trim().lowercase() else ""
            if (!checksum.matches(Regex("[a-f0-9]{64}"))) return@synchronized "NO_CHECKSUM"
            runOnUiThread {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("SHA-256 ${model.name}", checksum))
                Toast.makeText(this@MainActivity, "SHA-256 copiat în clipboard", Toast.LENGTH_SHORT).show()
            }
            "COPIED"
        }

        @JavascriptInterface
        fun deleteModel(fileName: String): String = synchronized(modelFileOperationLock) {
            if (modelIntegrityVerificationActive.get() || modelImportActive.get()) {
                return@synchronized JSONObject().put("deleted", false).put("code", "BUSY")
                    .put("message", "O verificare SHA-256 este în desfășurare. Așteaptă să se termine înainte de ștergere.")
                    .put("models", modelListJson()).toString()
            }
            val file = safeModelFile(fileName)
            if (file == null || !file.exists() || !file.isFile) {
                return@synchronized JSONObject().put("deleted", false).put("code", "INVALID_FILE")
                    .put("message", "Fișierul model nu este găsit sau numele nu este valid.")
                    .put("models", modelListJson()).toString()
            }
            val deleted = try { file.delete() } catch (_: SecurityException) { false }
            var checksumDeleted = false
            if (deleted) {
                val sidecar = File(modelsDirectory(), file.name + ".sha256").canonicalFile
                if (sidecar.parentFile == modelsDirectory().canonicalFile && sidecar.isFile) {
                    checksumDeleted = try { sidecar.delete() } catch (_: SecurityException) { false }
                }
            }
            JSONObject().put("deleted", deleted).put("code", if (deleted) "DELETED" else "DELETE_FAILED")
                .put("checksumDeleted", checksumDeleted)
                .put("message", if (deleted) "Model șters din spațiul privat al aplicației." else "Nu am putut șterge fișierul model. Am păstrat amprenta SHA-256.")
                .put("models", modelListJson()).toString()
        }

        @JavascriptInterface
        fun showMessage(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(180), Toast.LENGTH_SHORT).show() }
        }
    }



    private fun validateNativeGenerationRequest(prompt: String, width: Int, height: Int, steps: Int, threads: Int): String? {
        if (prompt.isBlank()) return "prompt is empty"
        if (prompt.length > 4000) return "prompt exceeds 4000 characters"
        if (width !in 256..512 || height !in 256..512) return "image dimensions must be between 256 and 512 pixels"
        if (steps !in 1..20) return "steps must be between 1 and 20"
        if (threads !in 1..6) return "threads must be between 1 and 6"
        return null
    }

    private fun safeModelFile(fileName: String): File? {
        if (fileName.isBlank() || fileName == "." || fileName == ".." ||
            fileName.contains("/") || fileName.contains("\\") ||
            !fileName.matches(Regex("[A-Za-z0-9._() -]{1,180}"))) return null
        val dir = modelsDirectory().canonicalFile
        val candidate = File(dir, fileName).canonicalFile
        if (candidate.parentFile != dir) return null
        return candidate
    }

    private fun modelsDirectory(): File = File(filesDir, "models").apply { if (!exists()) mkdirs() }

    /** Remove only temp artifacts created by this app's model import pipeline. */
    private fun cleanupInterruptedModelImports(): Int {
        val dir = modelsDirectory()
        val candidates = dir.listFiles()?.filter { file ->
            file.isFile && (file.name.startsWith(".import-") && file.name.endsWith(".tmp") || file.name.startsWith(".") && file.name.endsWith(".sha256.tmp"))
        } ?: emptyList()
        var removed = 0
        for (file in candidates) {
            try { if (file.delete()) removed++ } catch (_: Exception) { }
        }
        return removed
    }

    private fun modelFormatCheck(file: File): String {
        val ext = file.extension.lowercase()
        if (!file.exists() || !file.isFile || file.length() <= 0) return "empty-or-missing"
        val head = ByteArray(8)
        val count = try { file.inputStream().use { it.read(head) } } catch (_: Exception) { return "unreadable" }
        return when (ext) {
            "gguf" -> if (count >= 4 && String(head, 0, 4, Charsets.US_ASCII) == "GGUF") "signature-ok" else "signature-mismatch"
            "safetensors" -> {
                if (count < 8) "signature-mismatch" else {
                    val headerLen = java.nio.ByteBuffer.wrap(head, 0, 8).order(java.nio.ByteOrder.LITTLE_ENDIAN).long
                    if (headerLen in 2..(file.length() - 8) && headerLen <= 100L * 1024 * 1024) "header-length-ok" else "signature-mismatch"
                }
            }
            "pt", "pth", "ckpt" -> if (count >= 2 && ((head[0].toInt() and 0xff) == 0x50 && (head[1].toInt() and 0xff) == 0x4b || (head[0].toInt() and 0xff) == 0x80)) "container-signature-ok" else "signature-mismatch"
            "onnx" -> if (file.length() >= 16) "protobuf-file-size-ok-unverified" else "signature-mismatch"
            else -> "unsupported"
        }
    }

    private fun modelGenerationReadiness(file: File): String {
        val format = file.extension.lowercase()
        val signature = modelFormatCheck(file)
        if (signature == "empty-or-missing" || signature == "unreadable" || signature == "signature-mismatch") return "invalid-file"
        if (format == "gguf") return "not-diffusion-checkpoint: GGUF is not supported by this image-generation bridge"
        if (format == "onnx") return "unverified-onnx: model graph and runtime compatibility must be confirmed"
        if (format == "safetensors") return "pipeline-component: a single file may be only one component of a diffusion pipeline"
        if (format in setOf("pt", "pth", "ckpt")) return "legacy-checkpoint: compatibility and safety are not guaranteed"
        return "unsupported-format"
    }

    private fun modelListJson(): String {
        val dir = modelsDirectory()
        val engineLinked = try { nativeLibraryLoaded && nativeRuntimeInfo().contains("stable-diffusion.cpp C API linked") } catch (_: Throwable) { false }
        val files = dir.listFiles()?.filter { it.isFile && !it.name.startsWith(".") && !it.name.endsWith(".sha256") }?.map { f ->
            val checksumFile = File(dir, f.name + ".sha256")
            val checksum = if (checksumFile.exists()) checksumFile.readText().trim().takeIf { it.matches(Regex("[a-fA-F0-9]{64}")) } else null
            JSONObject().put("name", f.name).put("sizeBytes", f.length()).put("extension", f.extension.lowercase())
                .put("sha256", checksum ?: JSONObject.NULL).put("formatCheck", modelFormatCheck(f))
                .put("generationReadiness", modelGenerationReadiness(f))
                .put("candidateForNativeDiffusion", f.extension.lowercase() in setOf("safetensors", "ckpt", "pt", "pth") && modelFormatCheck(f) !in setOf("signature-mismatch", "empty-or-missing", "unreadable"))
                .put("engineLinked", engineLinked)
        } ?: emptyList()
        val stat = android.os.StatFs(filesDir.absolutePath)
        val totalModelStorageBytes = files.sumOf { it.getLong("sizeBytes") }
        return JSONObject().put("models", org.json.JSONArray(files)).put("count", files.size)
            .put("totalModelStorageBytes", totalModelStorageBytes)
            .put("totalAppStorageBytes", stat.totalBytes)
            .put("freeAppStorageBytes", stat.availableBytes).put("storagePath", "app-private/models")
            .put("engineIntegrated", engineLinked).put("nativeStatus", if (nativeLibraryLoaded) nativeStatus() else "native-library-not-loaded").toString()
    }

    private fun importModelUri(uri: Uri) {
        val importReserved = synchronized(modelFileOperationLock) {
            !modelIntegrityVerificationActive.get() && modelImportActive.compareAndSet(false, true)
        }
        if (!importReserved) {
            runOnUiThread { webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Un import de model este deja în desfășurare. Așteaptă să se termine.');", null) }
            return
        }
        webView.evaluateJavascript("window.onNativeModelImportStatus && window.onNativeModelImportStatus('Import în curs; copierea se face în spațiul privat al aplicației…');", null)
        Thread {
            var status = "Import eșuat."
            try {
                val name = queryDisplayName(uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in modelExtensions) throw IllegalArgumentException("Format neacceptat. Acceptăm: GGUF, SafeTensors, ONNX, CKPT/PT/PTH.")
                // Quick source signature/header check before copying; ONNX is size-only because protobuf has no fixed magic.
                val sourceCheck = try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val head = ByteArray(8); val read = input.read(head)
                        when (ext) {
                            "gguf" -> if (read >= 4 && String(head, 0, 4, Charsets.US_ASCII) == "GGUF") "signature-ok" else "signature-mismatch"
                            "safetensors" -> if (read >= 8) {
                                val len = java.nio.ByteBuffer.wrap(head, 0, 8).order(java.nio.ByteOrder.LITTLE_ENDIAN).long
                                if (len in 2..100L*1024*1024) "header-length-ok" else "signature-mismatch"
                            } else "signature-mismatch"
                            "pt", "pth", "ckpt" -> if (read >= 2 && (((head[0].toInt() and 0xff)==0x50 && (head[1].toInt() and 0xff)==0x4b) || (head[0].toInt() and 0xff)==0x80)) "container-signature-ok" else "signature-mismatch"
                            "onnx" -> if (read >= 8) "protobuf-file-size-ok-unverified" else "signature-mismatch"
                            else -> "unsupported"
                        }
                    } ?: "unreadable"
                } catch (_: Exception) { "unreadable" }
                if (sourceCheck == "signature-mismatch" || sourceCheck == "unreadable") throw IllegalArgumentException("Fișierul nu pare valid pentru extensia .$ext (verificare antifișier greșit).")
                val dir = modelsDirectory()
                val available = android.os.StatFs(filesDir.absolutePath).availableBytes
                val declaredSize = try {
                    contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
                    } ?: -1L
                } catch (_: Exception) { -1L }
                val maxModelBytes = 6L * 1024 * 1024 * 1024
                val storageReserveBytes = 256L * 1024 * 1024
                val usableForImport = (available - storageReserveBytes).coerceAtLeast(0L)
                if (declaredSize > maxModelBytes || (declaredSize > 0 && declaredSize > usableForImport))
                    throw IllegalArgumentException("Import refuzat: păstrează minimum 256 MB spațiu liber; modelul depășește spațiul sigur disponibil (limită 6 GB).")
                // Preserve existing models: choose a unique final name and copy to a temporary file first.
                var finalName = name
                var target = File(dir, finalName)
                var suffix = 1
                while (target.exists()) {
                    val stem = name.substringBeforeLast('.', name)
                    val extension = name.substringAfterLast('.', "")
                    finalName = if (extension.isNotBlank()) "$stem ($suffix).$extension" else "$name ($suffix)"
                    target = File(dir, finalName)
                    suffix++
                }
                val temp = File(dir, ".import-${System.currentTimeMillis()}-$finalName.tmp")
                val digest = MessageDigest.getInstance("SHA-256")
                var total = 0L
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        BufferedInputStream(input).use { buffered ->
                            FileOutputStream(temp).use { output ->
                                val buffer = ByteArray(1024 * 1024)
                                while (true) {
                                    val read = buffered.read(buffer)
                                    if (read < 0) break
                                    total += read
                                    val currentAvailable = android.os.StatFs(filesDir.absolutePath).availableBytes
                                    if (total > maxModelBytes || total > usableForImport || read > (currentAvailable - storageReserveBytes).coerceAtLeast(0L)) {
                                        throw IllegalArgumentException("Import oprit: modelul depășește limita sau spațiul liber.")
                                    }
                                    digest.update(buffer, 0, read)
                                    output.write(buffer, 0, read)
                                }
                                output.fd.sync()
                            }
                        }
                    } ?: throw IllegalStateException("Nu pot deschide fișierul ales.")
                    if (declaredSize >= 0 && total != declaredSize) throw IllegalStateException("Dimensiunea copiată nu corespunde fișierului sursă.")
                    if (!temp.renameTo(target)) throw IllegalStateException("Nu pot finaliza importul atomic al modelului.")
                } finally {
                    if (temp.exists()) temp.delete()
                }
                val sha256 = digest.digest().joinToString("") { "%02x".format(it) }
                val checksumTemp = File(dir, ".$finalName.sha256.tmp")
                val checksumTarget = File(dir, "$finalName.sha256")
                try {
                    FileOutputStream(checksumTemp).use { checksumOutput ->
                        checksumOutput.write((sha256 + "\n").toByteArray(Charsets.UTF_8))
                        checksumOutput.fd.sync()
                    }
                    if (!checksumTemp.renameTo(checksumTarget)) {
                        throw IllegalStateException("Nu pot salva fișierul de verificare SHA-256.")
                    }
                } catch (checksumError: Exception) {
                    checksumTemp.delete()
                    checksumTarget.delete()
                    target.delete()
                    throw IllegalStateException("Import anulat: nu am putut salva verificarea SHA-256; modelul a fost șters pentru a evita o bibliotecă incompletă.", checksumError)
                }
                status = "Model importat și verificare format ($sourceCheck): $finalName (${formatBytes(target.length())}). SHA-256: $sha256. ONNX este doar verificat ca fișier suficient de mare, nu validat semantic. Motorul de inferență nu este încă integrat."
            } catch (e: Exception) { status = e.message ?: "Import eșuat." }
            finally { modelImportActive.set(false) }
            val finalStatus = status
            runOnUiThread { webView.evaluateJavascript("window.onNativeModelImportStatus(${JSONObject.quote(finalStatus)}); window.refreshNativeModels && window.refreshNativeModels();", null) }
        }.apply { isDaemon = true; name = "VideoMakerModelImport" }.start()
    }

    private fun queryDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "model.bin"
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "model.bin"
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L*1024*1024 -> "%.2f GB".format(bytes/(1024.0*1024*1024))
        bytes >= 1024L*1024 -> "%.1f MB".format(bytes/(1024.0*1024))
        else -> "$bytes bytes"
    }

    private fun thermalLabel(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "none"
        PowerManager.THERMAL_STATUS_LIGHT -> "light"
        PowerManager.THERMAL_STATUS_MODERATE -> "moderate"
        PowerManager.THERMAL_STATUS_SEVERE -> "severe"
        PowerManager.THERMAL_STATUS_CRITICAL -> "critical"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "emergency"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "shutdown"
        else -> "unknown"
    }

    override fun onBackPressed() {
        // Route Android Back (including the system back gesture) through the editor's
        // logical navigation: wizard -> project editor -> Home -> exit Activity.
        if (webView.url?.startsWith("file:///android_asset/web/") == true) {
            webView.evaluateJavascript("window.handleAppBack && window.handleAppBack()") { handled ->
                if (handled != "true") runOnUiThread { super.onBackPressed() }
            }
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        nativeGenerationExecutor.shutdownNow()
        imageRenderExecutor.shutdownNow()
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        webView.destroy()
        super.onDestroy()
    }
}
