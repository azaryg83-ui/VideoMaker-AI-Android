# Scaffold 230 — diagnostic fix for project creation

## Confirmed issue in Scaffold 229
The project-creation handler catches exceptions and writes the error to `homeStatus`, but `homeStatus` is inside `homeLanding`. During the new-project wizard, `homeLanding` is hidden, so any exception is invisible to the user. This makes the app appear to do nothing after pressing **Începe proiectul**.

## Change
Added a visible `projectStartStatus` message area inside the wizard. The handler now reports progress and exposes the exact caught exception in the wizard. This is a diagnostic repair, not a claim that the underlying exception is already resolved; the next on-device attempt will reveal the error if creation still fails.
