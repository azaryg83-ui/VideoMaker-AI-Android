from pathlib import Path
html=Path('app/src/main/assets/web/index.html').read_text()
gradle=Path('app/build.gradle.kts').read_text()
checks={
 'bulk add tags control exists':'projectBulkAddTags' in html and 'Adaugă etichete selectate' in html,
 'bulk add preserves existing tags':'[...before,...additions]' in html,
 'deduplicates tags':'new Set([...before,...additions])' in html,
 'tag length capped 24':'slice(0,24)' in html,
 'per-project tag cap 8':'slice(0,8)' in html,
 'no selection guarded':'Selectează mai întâi proiecte.' in html,
 'empty input guarded':'Nu ai introdus etichete valide' in html,
 'version code 96':'versionCode = 96' in gradle,
 'version name 0.97':'0.97-build-candidate' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} PASS')
if not all(checks.values()): raise SystemExit(1)
